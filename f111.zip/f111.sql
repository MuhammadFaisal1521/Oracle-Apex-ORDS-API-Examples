prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>8582476076175954
,p_default_application_id=>111
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ELEVATEORDG'
);
end;
/
 
prompt APPLICATION 111 - Elevate
--
-- Application Export:
--   Application:     111
--   Name:            Elevate
--   Exported By:     ELEVATEADMIN
--   Flashback:       0
--   Export Type:     Application Export
--     Pages:                     34
--       Items:                   55
--       Validations:              5
--       Processes:               29
--       Regions:                 92
--       Buttons:                 38
--       Dynamic Actions:         20
--     Shared Components:
--       Logic:
--         App Settings:           1
--         Build Options:          7
--       Navigation:
--         Lists:                  8
--         Breadcrumbs:            1
--           Entries:             10
--       Security:
--         Authentication:         1
--         Authorization:          3
--         ACL Roles:              3
--       User Interface:
--         Themes:                 1
--         Templates:
--         LOVs:                  10
--       PWA:
--       Globalization:
--       Reports:
--       E-Mail:
--     Supporting Objects:  Excluded
--   Version:         24.2.13
--   Instance ID:     8582222801838812
--

prompt --application/delete_application
begin
wwv_flow_imp.remove_flow(wwv_flow.g_flow_id);
end;
/
prompt --application/create_application
begin
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'WKSP_ELEVATEORDG')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Elevate')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'ELEVATE')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'F7144F98AB27CE3AE8B9691219776BF0DF96A4F8866C67BB8F8A60D26B66C311'
,p_bookmark_checksum_function=>'SH512'
,p_compatibility_mode=>'24.2'
,p_flow_language=>'en'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_allow_feedback_yn=>'Y'
,p_date_format=>'DS'
,p_timestamp_format=>'DS'
,p_timestamp_tz_format=>'DS'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_authentication_id=>wwv_flow_imp.id(10561491675533324)
,p_application_tab_set=>1
,p_logo_type=>'T'
,p_logo_text=>'Elevate'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'Release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_runtime_api_usage=>'T'
,p_security_scheme=>wwv_flow_imp.id(10568241230533330)
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'Elevate'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>6
,p_version_scn=>46398354348531
,p_print_server_type=>'NATIVE'
,p_file_storage=>'DB'
,p_is_pwa=>'Y'
,p_pwa_is_installable=>'Y'
,p_pwa_manifest_display=>'standalone'
,p_pwa_manifest_orientation=>'any'
,p_pwa_apple_status_bar_style=>'default'
,p_pwa_is_push_enabled=>'Y'
,p_pwa_push_credential_id=>wwv_flow_imp.id(10939628118535612)
);
end;
/
prompt --application/user_interfaces
begin
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(111)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:12:&SESSION.'
,p_login_url=>'f?p=&APP_ID.:LOGIN:&APP_SESSION.::&DEBUG.:::'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(10562241822533324)
,p_navigation_list_position=>'SIDE'
,p_navigation_list_template_id=>2467739217141810545
,p_nav_list_template_options=>'#DEFAULT#:js-defaultCollapsed:js-navCollapsed--hidden:t-TreeNav--styleA'
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(10563421947533326)
,p_nav_bar_list_template_id=>2847543055748234966
,p_nav_bar_template_options=>'#DEFAULT#'
);
end;
/
prompt --workspace/credentials/app_111_push_notifications_credentials_2
begin
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(10939628118535612)
,p_name=>'App 111 Push Notifications Credentials (2)'
,p_static_id=>'App_111_Push_Notifications_Credentials_2_'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
end;
/
prompt --application/shared_components/navigation/lists/navigation_menu
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10562241822533324)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>46392740817730
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11001294902711318)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10583406581533340)
,p_list_item_display_sequence=>2
,p_list_item_link_text=>'Products'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ai-innovation-lightbulb'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12055313041507817)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'PREP MANAGEMENT'
,p_list_item_icon=>'fa-ship'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10648852188534399)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Inbound Management'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-arrow-down'
,p_parent_list_item_id=>wwv_flow_imp.id(12055313041507817)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10678518477534546)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Outbound Management'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-arrow-up'
,p_parent_list_item_id=>wwv_flow_imp.id(12055313041507817)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11594182873517496)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Inbound Costs'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-pointer'
,p_parent_list_item_id=>wwv_flow_imp.id(12055313041507817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12058440216632331)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Amazon Management'
,p_list_item_icon=>'fa-plane'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12843957652049973)
,p_list_item_display_sequence=>124
,p_list_item_link_text=>'FBA Inventory Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-desktop'
,p_parent_list_item_id=>wwv_flow_imp.id(12058440216632331)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12789445007964116)
,p_list_item_display_sequence=>125
,p_list_item_link_text=>'ADD AMAZON ASIN'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-edit'
,p_parent_list_item_id=>wwv_flow_imp.id(12058440216632331)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12826691371945157)
,p_list_item_display_sequence=>126
,p_list_item_link_text=>'FBA INBOUND'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-edit'
,p_parent_list_item_id=>wwv_flow_imp.id(12058440216632331)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12110073614149527)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'FBA Outbound'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-send'
,p_parent_list_item_id=>wwv_flow_imp.id(12058440216632331)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'18'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12057270599585838)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'PREP SETUP'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11656618970899542)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Prep Cost Setup'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-wrench'
,p_parent_list_item_id=>wwv_flow_imp.id(12057270599585838)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12011471598452135)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Accounts Setup'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-pointer'
,p_parent_list_item_id=>wwv_flow_imp.id(12057270599585838)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10918025187535374)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(10568107730533330)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11388952412962493)
,p_list_item_display_sequence=>10010
,p_list_item_link_text=>'Monthly Profit Analysis'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dollar'
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/navigation_bar
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10563421947533326)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>46218173572415
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10916274640535373)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Install App'
,p_list_item_link_target=>'#action$a-pwa-install'
,p_list_item_icon=>'fa-cloud-download'
,p_list_text_02=>'a-pwaInstall'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10916520712535373)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'&APP_USER.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10939365218535610)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Settings'
,p_list_item_link_target=>'f?p=&APP_ID.:20000:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-gear'
,p_parent_list_item_id=>wwv_flow_imp.id(10916520712535373)
,p_required_patch=>wwv_flow_imp.id(10932927889535606)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10917037545535373)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(10916520712535373)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10917492148535373)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Sign Out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(10916520712535373)
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/page_navigation
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10781400690534610)
,p_name=>'Page Navigation'
,p_list_status=>'PUBLIC'
,p_version_scn=>46218173560093
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10781832390534610)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Products'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-ai-innovation-lightbulb'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10782288946534610)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Inbound Shipment'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-cart-arrow-down'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10782678309534611)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Shipping Orders'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-plane'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10783093611534611)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Inbound Management'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-calendar-arrow-down'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10783407639534611)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Outbound Management'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-calendar-arrow-up'
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/application_configuration
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10919190354535374)
,p_name=>'Application Configuration'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(10566240772533329)
,p_version_scn=>46218173570552
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10919575878535374)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Configuration Options'
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&APP_SESSION.::&DEBUG.:10010::'
,p_list_item_icon=>'fa-sliders'
,p_list_text_01=>'Enable or disable application features'
,p_required_patch=>wwv_flow_imp.id(10566240772533329)
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/user_interface
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10919825844535374)
,p_name=>'User Interface'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(10566610449533329)
,p_version_scn=>46218173570552
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10920282855535375)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Theme Style Selection'
,p_list_item_link_target=>'f?p=&APP_ID.:10020:&APP_SESSION.::&DEBUG.:10020::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'Set the default application look and feel'
,p_required_patch=>wwv_flow_imp.id(10566610449533329)
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/activity_reports
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10920572950535375)
,p_name=>'Activity Reports'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_version_scn=>46218173570552
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10920900639535375)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:10030:&APP_SESSION.::&DEBUG.:10030::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'View application activity metrics'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10921342611535375)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Top Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:10031::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>'Report of page views aggregated by user'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10921759148535375)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Application Error Log'
,p_list_item_link_target=>'f?p=&APP_ID.:10032:&APP_SESSION.::&DEBUG.:10032::'
,p_list_item_icon=>'fa-exclamation'
,p_list_text_01=>'Report of errors logged by this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10922133142535375)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Page Performance'
,p_list_item_link_target=>'f?p=&APP_ID.:10033:&APP_SESSION.::&DEBUG.:10033::'
,p_list_item_icon=>'fa-file-chart'
,p_list_text_01=>'Report of activity and performance by application page'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10922552705535375)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Page Views'
,p_list_item_link_target=>'f?p=&APP_ID.:10034:&APP_SESSION.::&DEBUG.:RR,10034::'
,p_list_item_icon=>'fa-file-search'
,p_list_text_01=>'Report of each page view by user including date of access and elapsed time'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10922989872535375)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Automations Log'
,p_list_item_link_target=>'f?p=&APP_ID.:10035:&APP_SESSION.::&DEBUG.:RR,10035::'
,p_list_item_icon=>'fa-gears'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from apex_appl_automations a, apex_automation_log l',
'where a.automation_id = l.automation_id',
'and l.application_id = :APP_ID'))
,p_list_text_01=>'Report of automation executions and messages logged by this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/access_control
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10923240106535375)
,p_name=>'Access Control'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_version_scn=>46218173570552
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10923627825535376)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10041:&APP_SESSION.::&DEBUG.:RP::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Set level of access for authenticated users of this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10924021985535376)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Access Control'
,p_list_item_link_target=>'f?p=&APP_ID.:10040:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>'Change access control settings and disable access control'
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/lists/user_settings
begin
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10936526357535608)
,p_name=>'User Settings'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(10932927889535606)
,p_version_scn=>46218173572414
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10936945967535608)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Push Notifications'
,p_list_item_link_target=>'f?p=&APP_ID.:20010:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-bell-o'
,p_list_text_01=>'Configure whether you want to receive push notifications on this device.'
,p_list_text_02=>'<span class="a-pwaPush--state"></span>'
,p_required_patch=>wwv_flow_imp.id(10932656006535606)
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/shared_components/navigation/listentry
begin
null;
end;
/
prompt --application/shared_components/files/icons_app_icon_32_png
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000002D9494441547801EC546D4B536118BECE5EDDDC26CEB377221CA4445AD80B411FA22F4111598A44E1B77E4244087E902842E853851041DF0341302A0AA2976913';
wwv_flow_imp.g_varchar2_table(2) := '32311329F305CD2D1D676E3BC3BDB41D773A67721E8BE6F1590442EC61F739D7B9EE7BD773EDDE7D1E4DA4B343DCC9D0608757C540A503950E507560190C921E5FC988B14E2C184D406BFB6F11315BA85E702A03D51E2F9C8D8D7F844DE20D2E0F8EDCBB';
wwv_flow_imp.g_varchar2_table(3) := '0FE7854B246C075AC0D8EDFFCE4029253E1C86E8F5C1DFD50DC66C2625FC9B5710F339385A0E114E0D5075E05701B12062657A1AF6B3E7E1BAD809300CE425E672E006FA61696A86A969BF4C51455906844C06E1D919F8AF76A1FAE061B281105941F4E9';
wwv_flow_imp.g_varchar2_table(4) := '63B092292DEB203C0DA03690E238F079017B6FF642E77213EDCCE404D2D35FE068EB00A3D7137E2D1422580D5019888643D0EF6B46FD956B600CC60D3D5144E2E50B682D56D88E9FD8E0A46B219DC2ECADEB484E4D4A4FDB7FA80CEC3E7D066C6B1B5113';
wwv_flow_imp.g_varchar2_table(5) := 'D369440707603B7A0C867A3FE1738B0BF8DAD30DBBAD06D6BA3AC2AB012A031A66B34CDE24F12E00F65C3B34562BD14E065E63B1EF2E3C0D8DD055195110049253039BCA2A55F9C872319B1A1B859088A3F6E42928D38F4201DF1F3EC0DA5000AE863D84';
wwv_flow_imp.g_varchar2_table(6) := '5E4FF2A0595406F80FA3883F7F06A36F17CCD221A308AFC76398BBD103637A0D169753A191E593C8F309F2AC06A80CD44AEF3A371C80CEED265AD9CF5358B8DD0BD6E381DE6422BC349B581A1F03AB0C2BC994065406741A06E6F91984FAEE4094FEDBD8';
wwv_flow_imp.g_varchar2_table(7) := '934170FD8FE0F0D78391728A74F1909AF80877611DF277145EED4E654016306834D00687307EB91369E917D678BD324D42C866B1141C862DBE0ABD544B12DB006A03B28E9661E093868EFB3481141795A962C8F85BE02D1C421E724D91A4BC946540D694';
wwv_flow_imp.g_varchar2_table(8) := '4F7E9FD180D5B1F7981F19C15C30889884BD063DE49C5C534E946D4011775655C1FB23035F2E0B878415BEDCFB5F1B2877A3ADEA2B062A1DF8FF3BB0D5F42BFC4F000000FFFFCC68596700000006494441540300D0DE3630B8E46B140000000049454E44';
wwv_flow_imp.g_varchar2_table(9) := 'AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10564447318533327)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
prompt --application/shared_components/files/icons_app_icon_144_rounded_png
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000090000000900806000000E746E2B800001000494441547801EC5D799814D5B5FFDDEAE9D917B6991E64116447115EDC10881282267F242611C627C2A7BCA7A2E01263DC9E31467D315F5EA23E49C4103F63';
wwv_flow_imp.g_varchar2_table(2) := '5C5834834B5CA3B2A9CC808A20B3B10D8BC332FBC2AC3DDDD35D39A7BA8700998199BAD5D35DDDB7BE3AD5D555F7DE73EEEFFCE6DE7BEEADAED1A036858004028A4012E0A9AC802290628114028A4052F0A9CC8A408A035208280249C1A7322B02290E48';
wwv_flow_imp.g_varchar2_table(3) := '21609A40525A55E6A8414011286A5C199E8A28028507F7A8D1AA081435AE0C4F451481C2837BD46855048A1A5786A7228A40E1C13D6AB4F63D817A005DF57F5F9556B53027BBF286FF1C55B9E027932B17CC9D56B920E78A8A79737E180BC275AD34EA4C';
wwv_flow_imp.g_varchar2_table(4) := '75270C180BC6A407D0F57992B012480744CDBC39E3ABE6CFB9A172C19C672BE6CFDD5A397FAEC7DF1EDFA87BF57274F84AA13BBE868E3CE8FA4742136F8B1810AE6BA0CE5477C280B1604C189B2046CBAA0833C68E314418B73E2550794E4E66C5829CAB';
wwv_flow_imp.g_varchar2_table(5) := 'AAAE9BFB78E5FC9C8FABE6CFADF76962A70EF12274B158001710164E12B5778D803388D112C68CB1630C0358CEF935B7CE87727206749D353457FB8C403A2084539F2674FD7E5DE041409F0D208344ED72081086FA6C1DE21742D3EE77C6EBD374807886';
wwv_flow_imp.g_varchar2_table(6) := '3ED9424E207DD12267C5FC3937575D37679710780BC03412B58704017D3A31E71D6A9576565C977323631F123527141A5202D55C9F33A4B2A56EB380780E428C3D41AF3A0D2D02E384D09FAF6CAECBE761432855858C40E5F37326FA7CFAE72230AE0965';
wwv_flow_imp.g_varchar2_table(7) := '1D54D9DD20402DFE855A827F73F9BC39E7769344FA72480854352F6786063D9FAC1B4262D1AE8A3185802E46699AC8AB9E9773B9A9FC67C8643981B8E5D135FD43D24B833B3AAA3D1210C8F06BFAFBA168892C25D0D1453F4CA6962797104B26517B6421';
wwv_flow_imp.g_varchar2_table(8) := '904C2DD16BEC232BCDB294408E968467C9B889246A8F4C04CE0DFAC832EB2C2350D575390BC9AA1B48D41ED908DC10F49525565A42209AFD4CD285FE942516A942428E00F9EA49ABBA324B08141FEFE796A77FC86BAE145885C000474BFCF55614264DA0';
wwv_flow_imp.g_varchar2_table(9) := 'C0B4B9B8CB0A634254862AB60B04047067C0775DDCECC5256902552FC8F91EE91B47A2761B21A0434C08FA4ECA6A6902E93A54EB037B6E56F84E8A4007162E4CA455F52BEC099FB29A7DC701900C1252044AEC689E4ACAA5CAA0FC6A0F1F025A5C827E89';
wwv_flow_imp.g_varchar2_table(10) := '8C7A29E73B74C10492D1AFF2861901591F4A114887AE08146602C8AA97F5A16902E9004582988128DE62A46A528D806902552FCC7111C00349D46E6F045C8DD7FFC4B41F4D13C8D1EE37ADD4DE78479FF55EAF966DB656A609E4D174F5C88659D4232C9F';
wwv_flow_imp.g_varchar2_table(11) := '8C2F4D13087E8722508411C1B43912BE344D20870349A60D5619230A01A7A6C79935C8348174BFEAC2CC821E69F9FC4298FE31A76902699A6A81BA2582CD6EC83406A609A4FBCDB3D64A7C9BBC5E1C6A69C5BEA666EC6B6CB28790AD6C73B3B7C34A284C';
wwv_flow_imp.g_varchar2_table(12) := '9725D318982790F087BDF635EE76EC2767D4B5B7A39988D4DCD1015B08D9CA36EF6B6A02D7C1B4E72320A369024580ED38D2DA6A9831FE92A9B8E4EA392197F32E9B89F8844443E7F0693330FB8D7771C5FB6B4DC9C5F73C6094D35907E38B0D0FB62590';
wwv_flow_imp.g_varchar2_table(13) := 'DBE733E0CE1C32041924C697101EAA4BF7A2E8D38DF0B4BB31E5C64518F7D0231089013299519B316B36B226047EC0D2EEF39B292222F2D896407E5A8C63043B5B043E0F85F83B7CD8BF650BF6171420293D1DDF7E622932E75C23A78AC87FF8F9E5A8DA';
wwv_flow_imp.g_varchar2_table(14) := '596294E3D7839531BED9EB605B02F505CC9EE61614AF5F87EAA3479039661C2E7DF679244E94FB99B9BFA10105F7DF8D9D6FACE98B2A845C8722503710375554A060FD5AB4363761DC553FC6E42797C23140EEDD4DEE3DBB90BFE46654961463F8D44B31';
wwv_flow_imp.g_varchar2_table(15) := '7AF695A768B7DF5745A0537CA6537772B4A80825F9791042C3D4071FC6F05B6F8788333D596B68A879FB4DE4DD7D27DA8F3560CA4DB760DC2F1F8323C9FE93F98A40867B03075FBB077B3EFB1487F6EC469A2B1B339EF913D2665C16B869F2A8D314C3DE';
wwv_flow_imp.g_varchar2_table(16) := 'C71FC5F6E5CB90909A8AE9BF7F1A9957E700821FA782ED3745A0A00B5BEBEA51485D56434D0D865E78312E59F61C9CC3CE0EDE35F7D151518EAD772CC6C1BCCF2C1B4399B32474B9148108DBDA7DFB51F4C90678DC6E4CFEAF9B30E1D1C72192E51E3668';
wwv_flow_imp.g_varchar2_table(17) := 'DE928F4DB72D42C3E1328CFFD1D5968CA1C8D488DB639A409D217AE98EED484C4BC3F4DF3E81AC9C6B21D5BD50887EE485E7B0F9B187A1FB74630C35EC9625D2632844E816B304EA2A444F9A3459CA4DFE60885EB2E66F481F7C16662C5B0ED931949441';
wwv_flow_imp.g_varchar2_table(18) := '7D90392609745288FE831F61F2134F5B1EA25FBCECCF700E19DA072E345484ED105304A2081DE5C5C52787E84BEE80709A7E1CC6705CED3B6FFD5B882E12ED1FA21B953BC32166081408D13F41D9EE5D9687E8DBFEF44C5486E867E08E713B2608D456DF';
wwv_flow_imp.g_varchar2_table(19) := 'A04274C3DDD61FA29E40B5070EA0706330445F78A325217ACBD62F622244EF09DDA296407E0AA70F7EF9054AB76F437C4A722044BF661EA443F4BF3E8FFC871F3442F44B1F7E0CD11CA2A3075B5412C8DBDA8A9D1B36A0F2D0210C1A351AD369153D4936';
wwv_flow_imp.g_varchar2_table(20) := '446F6C44E1FFDC8B92DC578F87E8A953D5BFFD883A02355755A160DD5A34371EC3285AED9EF2D41FE11834A8077F4BDD27692FDD8B2D34AB5C515460ACA25B11A2B77EBD0D07C8CEEEB5F6CD1D592DD143201DA8282941C9A6CF003ABFE8E7F7E19CBBEF';
wwv_flow_imp.g_varchar2_table(21) := '930ED1EBDE7D1B9B7E763BDAEA6A8FAFA24B85E8349750B1EA15E43F781F3CAD2DB2FE0B7BFEA82090CFEB45697E1EBED9B51329995998FE8767D1EFBB72CFDA18ABE8BF790C5F3DFB0724A4A458B28AEE6F6E46C943F7A370C54B48A0B5B6FE99996127';
wwv_flow_imp.g_varchar2_table(22) := '80AC01B627502B8D4D8AA92BA8ADAC38BE8A1E3F62A4142EBC8AFED59DB48ABEE953648EB5E64944CFC103F882BAC12334A81FE8CAC679DF9D8DA4B4F4809D22F061C7A3ED09545F530D775B1BCEBF7EA111A26BA9A9527EE80CD1EB0FD12AFA8F6915FD';
wwv_flow_imp.g_varchar2_table(23) := '09F927111BD67E88BC3B97A0B9BA0A678F9F80D1D3A6C341B3DFC779435DAE94D161CC6C7B02190F69D12ABAEBDA05900DD18FBEF4C2C921FA22B955749DBAD6FD4FFD0E5F3EF57BB20D98307D06B2274E34CE11259BED0934621675051685E8C5AFADB2';
wwv_flow_imp.g_varchar2_table(24) := '2C44F7D5D4E0EBBBEFC0BEB51F21352303E7939D692E5794D0E65FD5B03D81FE55157367A108D1DB0A77206FC94DA8D9570AD7B0E19830F33B70D264A6390B233457D0AC982650DDFBEF50887E87A5217A154D34E63D700F3C2D2D183DE53F30E2A28BA0';
wwv_flow_imp.g_varchar2_table(25) := '391C41B8A3EF232609A47B3C28FDDD6FF0D5334B91402D83150FBAEB3CFBFDAB5F60072D7538E31330895A9D81E79C137D8C39A546B625902318C278696EE5943A9DF66B074542DBEEBA0D0736AEB72C44F71EFA069F53887E981659FB0D1C84491CA2F7';
wwv_flow_imp.g_varchar2_table(26) := 'EF7F5A3BF8A6AF23F07E0ACDC6BFD0D0B8227694382D607A2BCDFFF4D47E0ED1F316DF8C3A9A93196F5188DE4473459B6E5F8C26B263D8983118FBEDCB109798D02393DA69FA81133A35C11FB69480176C68BA83FE6A0584E1B8339AEFF7A3FC95BF1A21';
wwv_flow_imp.g_varchar2_table(27) := 'BABFC30763155D3644A7D6A36CF933D842B3D5BACF0F7E43C85993CE87E8051998405C0F4D883356215213D896400C683CB542ADB5B580CFC75FBB143FCD5417D2A0B668F54AEB42F4BA3AECF8F94FB1FBEDB7909C9A465DD62C536F086977B7C14975E8';
wwv_flow_imp.g_varchar2_table(28) := 'D2709B5CB4358192E21CE09F22B795147509772842747749313653885EBD7737060D3E0BE77E671612D2D2BAD47FBA8BED4D4DE0315092CD23B4DE13E874A8F4F1BD8C78A7A1B162DDC7C6E78987BA0FDEB33C44AF7E231779F7DE0537397FE47993306A';
wwv_flow_imp.g_varchar2_table(29) := 'EAA5D09C7127AAEDF179C3912346DA8CF878E3D3AE075B1328CDE9A451107070E306F0B2013BE17888FEC7FFB72E44A7AE66F7FF3E8CAF9FFF331C714E9C4B03E5ACB163612887B9ADAAAC8CB20BA49924A039ADD6E7B2358178009A4A24EAF0B4A331EF';
wwv_flow_imp.g_varchar2_table(30) := '339C14A25BF43E1FEF91C3B48A7E0BCAB66C465ABF7E98347B3652641F50A3168C5F1BC3E4B1F3009AE9686B027105B282AF99DBFBEA4AE3DD3B7514A24FB87A2EA62C5D26FD63C1A6FC4DC8BBE35634961FC5E011233171E62C382D78254BF9AE5D6C3A';
wwv_flow_imp.g_varchar2_table(31) := '3283B61B5F6C7AB03D8152A90BC8A056A8BEEC1BF8BC81107DE84DB7CAB983A23A7E05DD965F3F02BFC78B31175C88E1DFFA16A009B97229775365252A0F95A11F8D7DD876BA64EBDDF60462F487D0728446230A070DAA93468FE14BA6C5DFD070FC1574';
wwv_flow_imp.g_varchar2_table(32) := '49C9C9388F9624069C2DF79A974E637CDE0E946EDD0AB6F5ACE4A4CECBB6FED46C6D7DD0789E4BC9A4D9DFF6E626143CFACBD3CE0B05B374F971E22BE806B85C3877D66C24F6CBE8326D6F2FF20466E9E63C78DADDC84A4AB4FDFC4F67FDB5CE93D07F86';
wwv_flow_imp.g_varchar2_table(33) := '56838BFEA2D3A82BE347284A9FF82D6882A8570A6B83AFA06B6BA8C7F0F1133066DA0C708BD6AB42BA49CCE4D9B3E933F0CBABD2C946265037496D77396A08C4A39391A929488D8BC3814F36E09B679EEE91333A1F9EDFB67C1934870313A74DC7608B9F';
wwv_flow_imp.g_varchar2_table(34) := '1ADC4311E2B1BA5A0AD99D1899964A9D6D8F4CB345A2A82110A32D84301C944224DA4313897BFFEF713041F85E57C20FCF1BAFA0A305D1D4F4744CA259E5B4ECECAE929ABAA6D31AD9C12FBFC4315A6E616233C14D1514C199A28A408CB346243A87FECA';
wwv_flow_imp.g_varchar2_table(35) := 'B93B3B482DD1573F5D828ECA0ABE7592182BF3B72D325E419735741826CC9C85F8D4D493D2C87CE970BBB1EBD34F8C888BBB2DA3E521DB64CA8CC4BC51472006B993443CCFC2E17DFEEDB7A065DB56BE650CB08FBEF8176365DE4B4E1E357932465E7C31';
wwv_flow_imp.g_varchar2_table(36) := '345A570B24903FBA8F35A270DD3A34D6D719733D4C1EB649BEE4C82B212A09D4093387CAC35352D0DED282FC871E40F98A97504C9FC57F5B6DFCD394F32E9F69FC76BE33BD159FC78E1E45C1867546B4C5BAD9062BCA8DD432A29A400C7AFF84788CA1F1';
wwv_flow_imp.g_varchar2_table(37) := '4D1C751F45AB5EC1D11DDBD1F9D460B2E49BE7B9FCE3A203E52525D8454B1E0E3A679DACFBF8FD283DB10381A4A14FA6EE696C463A1229CAE2C2F81110A15957750ED3F71171CA76ED34748CCD4803EB645DD12ED6A118E148F164E398F434F0B20787D4';
wwv_flow_imp.g_varchar2_table(38) := 'C5EBD7C2D3CBE7A9BBAAA2B7B50D3B37AE470DAD9771D9AC83757595361AAFC50C81D8793C901D41119A8B1644DDADAD285CBF0E2DD5357CCB94B4D6D5A38888D8D2D8886C2A93CB661DA60AB369A6982250A78FB26929610485ECDCF514D31C50EDFEFD';
wwv_flow_imp.g_varchar2_table(39) := '9DB77AFC595F76C878BB7D87D70B2ECB4565F6387314258C4902B1FFD269E1753475693CB82EFD7A3BCAB66FEFD1EA078F9F8E141460CFD62FE0A4813977595C1697198B12B3046267F333D56329424BA699EBF203FB514A4B0E1D6D6EBED5A5F0E4E0DE';
wwv_flow_imp.g_varchar2_table(40) := '4D9B70B8742F78B6FBC48179971962E0624C1388FD1BA7090AF3D330202101755555D8F6E107A8DAB307BEF676BE6D089F57EDDE8D6DFFF800F5D555184869B9F5E227228D04317C886A02F5C6AFC35292312A2D0DF194E9405121B6BEF72E8A3EFA1805';
wwv_flow_imp.g_varchar2_table(41) := '1FFEC3383F505C8478EAB238CD504A4BC9D44E08280211089D3B3F2138BE5F0646D2003B9BA2AA388F1B093448E673BE369EE692384D677AF5099827902E5AA315401E147354352235056793F0395F8BD6FAFAFD68335B37D304125AF412C82C9876CD27';
wwv_flow_imp.g_varchar2_table(42) := 'E34BD304F2F9CCB3D6AE4047ABDD32BE344D2068BEA8EDC2A29528DDD64BC297A60914EF57762E051E00000367494441545D58B70EB1D90D195F9A26508788E22ECC6604903557C697A60924E235D585C97A2E42F2CBF8D23481CAE2FBD752FDBB9FF7A7';
wwv_flow_imp.g_varchar2_table(43) := '9B6AB70502EEA02F4D196B9A40173EF79C5717F8DC945695296210601FB22FCD1A649A40AC50001BA1365B2320EB432902F915816C4D1E365ED687520472C7A56E2123D4388840B0E9EE0EFAD0B4F952041AF9E28B6E1DFADF4D6B8FBA8CF6AA10FB8E7D';
wwv_flow_imp.g_varchar2_table(44) := '2863B51481028AF59EFD083D90581D230A0179DF4913287BE51BDC8DA9682CA288D123633E0FFAAE4789BB4B244D202E58D7A15A21D86BB3CA679610C875B4660DC1779844EDF640E048D067D2D65A4220B171630731FA76696B54017D8280EED717B3CF';
wwv_flow_imp.g_varchar2_table(45) := 'AC50660981D890EC556BFE2E747D299F2B895C04D847D9AB5F7FC72A0B2D23101B94993AF05E01F1259F2BE915027D9258D0C42FFBC84A65961248D0FA98CFE7B8860C6C20517B642150A9FB9DD7B28FAC34CB5202B161835F7DF5A0F0E9B300FD207F57';
wwv_flow_imp.g_varchar2_table(46) := '1211087C03E1FB9E6BF5EA4AABADB19C406C60D6ABAF6FF73AFC1702622DD4165E0474ACF73A7C17B856BCB92314868484406CE8D097DFACCDF2E0FB74BE9C44EDE141E0C92CAFB8927D112AF52123101B2C72737DAE956B16537746020F5F53D22708B4';
wwv_flow_imp.g_varchar2_table(47) := 'E910D712F6F7B00F42A931A404EA34DCB5F2F5E50E87380710BFA205BC43505BA810380C1D8F10D663B257E6BE162A252796DB27046285835ECE3DE25A99FB98CBA38D04C4D5241F829A2612B54B2040597D42887734217E90E511235CABD63CCA58D3F5';
wwv_flow_imp.g_varchar2_table(48) := '3ED9FB8C409DB5E1269588F426C9F79D1ED15FE8FECB7521EEA2FB2F9114927490A8BD6B04189B426A655ED6819F697E31534BF0F4CF5A917B55E68ADCF7185BF4F1D6E7043AB17E0372738F65AD7AE3D3EC15B94B5D2BD72C24399FC449A0A40BA7188C';
wwv_flow_imp.g_varchar2_table(49) := '38C7680A3FA740603A84B892A6E0AF8A05E1BAC2A8B36F0A63C05830268C0DC9F9AE556B6EC85EB9E6E9CCD5B99F64BEF076D38998F6F5795809D45D651994AC17732B5C2FBDB6CF45E1A76BC59A7CD78ADC8F790A3E1684EB1AA8F39B3B1803C68231E9';
wwv_flow_imp.g_varchar2_table(50) := '0EAF705E8F4802851310A5BB77082802F50E2F95FA140414814E01447DED1D028A40BDC32B7A525B541345208B808CD562148162D5F316D55B11C8222063B51845A058F5BC45F55604B208C8582D461128563D6F51BD15812C0232768A39B9A68A4027E3';
wwv_flow_imp.g_varchar2_table(51) := 'A1BEF5120145A05E02A6929F8CC03F010000FFFFC67C6E7C000000064944415403006F7488A8AD88752E0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10564773576533327)
,p_file_name=>'icons/app-icon-144-rounded.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
prompt --application/shared_components/files/icons_app_icon_192_png
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D49484452000000C0000000C0080600000052DC6C0700001000494441547801EC5D097C15D5B9FFDF25FB42085B20843D8400019445364591BEB6BFFABAA86D5F5FDB5FFB5AAB88881BAD3CB5B65AAD5A91222222B67DF5B5';
wwv_flow_imp.g_varchar2_table(2) := '0F6B9F7DEDAB5A5B65D510228210B2109684402024907DDFEE4DCF37B973320909DC2473E7DE3BF3DDDF9D3B67CE9C39DF77FEDFFCEF9CF39D65EC65DFBCBD8337C6C0AAF7801DFC61042C8C0013C0C2C6E7A2034C00BE0B2C8D0013C0D2E6E7C25B9800';
wwv_flow_imp.g_varchar2_table(3) := '6C7C4680AB407C0F581C017E0258FC06B07AF1990056BF032C5E7E2680C56F00AB179F0960C53B80CB2C116002482838604504980056B43A975922C004905070C08A083001AC68752EB344800920A1E0801510E8594626404F44F8D8520830012C656E2E';
wwv_flow_imp.g_varchar2_table(4) := '6C4F0498003D11E1634B21C004B094B9B9B03D116002F444848F2D858085086029BB7261BD448009E025509CCC9C083001CC69572E9597083001BC048A93991301268039EDCAA5F212012680974005753256BE4F0498007D42C327AC800013C00A56E632';
wwv_flow_imp.g_varchar2_table(5) := 'F6890013A04F68F8841510600258C1CA5CC63E116002F4090D9F300302572B0313E06A08F1795323C00430B579B97057438009703584F8BCA911600298DABC5CB8AB21C004B81A427CDED408989800A6B61B174E270498003A01C9D90427024C80E0B41B';
wwv_flow_imp.g_varchar2_table(6) := '6BAD13024C009D80E46C821301264070DA8DB5D6090126804E40065436AC8CD7083001BC868A139A1101268019ADCA65F21A012680D75071423322C00430A355B94C5E23C004F01A2A4E180C08F457474B10A0AAA51545F50DC8ABAE415665156F57C080';
wwv_flow_imp.g_varchar2_table(7) := '3022AC08B3FEDE4CC198DED4046877BB5150578FB30D0DA8696D459B380E462319A933614458116685023BC2D048F946CB323501E89FACBEADCD684C4D23AF4E6077B6A1D134E5E9AD20A62540A5A8F634B4B72B650E8B8840CAFCEB30EF0BB7E0BA5B6F';
wwv_flow_imp.g_varchar2_table(8) := '0B8A6DE60DCB101A16AEE8AFFE4C5ABE022BFEFC2E3EF3B71D3EDB6E7EE32DCC7B602D4223A314B144023357874C4B007A8C2B16143F1367CD465CD25838C2C2C451E07F2F9D3C899C0FF7A2B5A5592A7BEDAA7B3179ED3AD87C5C06FB90380CFDCCE730';
wwv_flow_imp.g_varchar2_table(9) := '47C853856BB154E3CCB2371101BA9BA4B1DD2523624625C8702007DCE28955B03F0385D947A59A51C387E38617B760D82D5F92714604A252A74B314DAE2E2C65A44902A625407B875B9AC8EE74C870A0065A44833377E74E945FB820551C3D7316166EDE';
wwv_flow_imp.g_varchar2_table(10) := '86B0E4A932CE88407BC9791C79E2C75254AB899D07A62580B45E10046A4B4A902D6EFEC6867AA9ED8CAFFF3B663EF33CECB1B132CE8840FDC7FB917EEF4A549D3D638438BFCB6002F8D1041DEE0E9488EACEB1CCFD70B93B1BEC21A2C1BEF8C99F63CC77';
wwv_flow_imp.g_varchar2_table(11) := 'BE07380C7C72897FF992D77F83FDE29FBFADA9C98FA8182B9A09602CDE529AABB905273EDA8B62D1E05523E3274CC4D2975F43D4BC056A94217B775D1D721F7B18B96F6E97F2E2C74F90613307EC662E5CA096AD51F4C41EDDB903D5151552C5094BAEC7';
wwv_flow_imp.g_varchar2_table(12) := 'B5BFDC0C67C2001AEC3297FE075A4E9E40E63D3F40C991C3F2E209CB6EC2B51B5F96C7660E30010CB66E79C129E4ECDD2D5D9C76BB1DE4E24C7EF4273E7771F62C6AD53FDE43FA836BD0505EAE9C225DAE59790F921F7ED4705D1405FCF0C304300874B7';
wwv_flow_imp.g_varchar2_table(13) := '70CB166666A2202B0B1D1D1D8AD4A861C3B164C326C35D9C1DA287F7F4C6F538F8E20B70BB3ADB1E117143B164FD460CFFE25714DDACF2C30430C0D2ADF50DC8DDB51397847B511597402ECE97B6227CEA3435CA90BDABFC128E3CB406A7DEFF3BD44FC2';
wwv_flow_imp.g_varchar2_table(14) := '8C9958B4651BC2A775F9FED57366DF33017C6CE1BAD2521CDDB5038DF57552D2F4AFFE1BD2C8C5191727E38C0834661DC6BE5577A2FCD449296EDA976F15EED6F5708827808CB4508009E023635335A72427177919FBE0123DBC2446757126FEC71D8091';
wwv_flow_imp.g_varchar2_table(15) := '2E4E51E5BAF8C73790F1C88FD0E221A23324140B1FFB2992EE5C059BD349EA05E53658A599008345B097EB5D2DADC2C5F9218A4FE4CBB37163C70917E73618EEE26C6C40BEF0ED67FDF6D7B2ED119B301A4B366D41CCE2A5B0FA8709A0F31DD054558D6C';
wwv_flow_imp.g_varchar2_table(16) := '51E5A9F67856287B7271CE7BE915E1E21C4D87866DAD678AF0C9EA95283E902965262D5888F99BB722D4227E7E59F03E024C803E8019487445E16964EFD98D164F4FAA742BFAC1C55997918E7D6B56A1B6B4736C91CD66C36C51F59AF6939FC1EE19EA3C';
wwv_flow_imp.g_varchar2_table(17) := '90329AED1A26800E1675BB5C28FAE4004E1DF95454333A07E145884625B9380D772B0A5DCE6D7B05994FFD14ED6DAD4AE9C2A263B0F8E7BFC048D1F886208212C93F0A024C00058681FFB43536E2D8EEDD282B2E96998C9A3E038BB7BC66BC8BB3BA0AD9';
wwv_flow_imp.g_varchar2_table(18) := 'EB1EC2B1BFFC49EA327C4A3296081767E4EC6B641C07BA100862027415C25FA1FA8B1741431AEA6B6BA40AD36FFB2A663DB701F6B838196744A0393F0FFB858BB33437478A9BF22F9FC39C1736C1317C848CE34077049800DDF1F0EE4874E45EC8CB435E';
wwv_flow_imp.g_varchar2_table(19) := 'FA47A29AD139E7D8191A8E458F3F89C4EFDF05435D9C42E38AB7FF827D6BEF479378028843389C21CAB4C689F7AF852D2484A278EB030126401FC0F415ED6A6DC30971E39FCD3F06C1032559ECE831C2C5B915D10B172BC746FD74B4B4E0E4734FE3D357';
wwv_flow_imp.g_varchar2_table(20) := '36C3ED762B6263468EC4D28D9B95698D4A04FF5C110126C015E1E97EB2B9A616393B77A0EAD2457962DCC24558F0F2AB08491C2BE38C08D0ACAD43F7AD42D1DEDD525CE2DC7958B0F955844E9A2CE338706504980057C6479EAD2C2A42F6EE5D686EEA5C';
wwv_flow_imp.g_varchar2_table(21) := '26C42EBC29737EB012298FFF0CB6F00899CE8840C3A7072F9BB535F31BDFC2F4277E0EBBF0F818A18359643001AE62C90E5707CE1C3C88939F1E12D50C97923A825C9CCF6FC488AFDCAE1C1BF623AA39177EF75B643CB60EEAAC2D6578C553CF62F4B7BF';
wwv_flow_imp.g_varchar2_table(22) := '0BD8D99CFDB505237605C4DA4587D6B13DBB50AA991F2B5D9CC2D579854B753FE5AEAF43DE4F1E41CE1BBF97790F1D371E4B5FDA8AA86BE7C9380EF40F0126401F78355C2A47D68E0F5057532D53A47EF936A43DFB82E12ECED6C2021C587D17CE1F3A08';
wwv_flow_imp.g_varchar2_table(23) := 'F53361D94D98FBE21638C724AA51BC1F00024C809EA009D74E597E3E723FDA7B998B73EC9D77C3E89193D53BFE817DF7AF469DE87320556978853283CC42B3B6A8DCBEDA98001A645D6DED3895B10F4579B9103C50CEF8CDC5E999B5F5C986E7D1DEDED9';
wwv_flow_imp.g_varchar2_table(24) := 'D710416D8FF51B0D9F41A60061D21F2680C7B02DB575C8152ECE8AB2524F0CE02F1727CFDA9226B82CA077041340205A73FE3CB277ED445363833802ECE4E2FCFE9D48F9F19386BB389B72B22F9BB5957AEBED4ADBC3219E008A82FCA31B029626002D4C';
wwv_flow_imp.g_varchar2_table(25) := '557CE408F23FCE84CBED7171C6C662C9F3C2C579DBD760E8C8C98E0E5CFAD31F91F1F0835DB3B642C395595B63EF5809183883ACA3BD1D67B76C82153E9625407B73338EEDD98D12E161510D3D2239058BB6FC0AE106BB383B84BBF5F8D34FE0C8AFB7C1';
wwv_flow_imp.g_varchar2_table(26) := '2D8840FAC4899EE5A59B5F317CD696ABB202477FF8008EBFF35752C3F49B2509D0505E816C72717A068F919553BEF815CC7EE14538E2E3E9D0B0ADED5C310EAEB91B6733D2A5CC718B9762DEA65710323649C61911A0EA178D28BD78FC9811E2024286B5';
wwv_flow_imp.g_varchar2_table(27) := '08205C3B174F9C505C9CADAD9D934594C9E18F3C8E712BEF81D12ECE3A71D3A7AFBE1BD5E7CF2937835DB43D667FEF0748A1196411C60EAFB8F4E7B794EA57936668B7A294C97F82880083B3845BD46B0B3233705A343269C506CA8DDE1BA0543396DE40';
wwv_flow_imp.g_varchar2_table(28) := '87C66D2E17CEFFFAD5CE595BAD9D2FC150666D3DB701236FFF3A8C6C7BD088D2E34FFD14475EDB2AAB5F76BB0353E75AA377D9120468ADAB5746716AD7DE1F3B6F01AE7B791B4292C6C3C88F4B54BB68D656DE9FFE578A55676D45CC4C93714604D411A5';
wwv_flow_imp.g_varchar2_table(29) := 'DAEA57446424D26EBC0943C71B8B8B11E5ED4D86250870749770713674BA386DB6CEC9E1A94F3C0D9B30766FA0F82A4E5988B6C7ACADE4CF7E1EFE98B545EF01D8D7E33D00C312123063F90A84C70DF115040197AF2508E052D7BF142ECEA5C2C539D20F';
wwv_flow_imp.g_varchar2_table(30) := '93C32BDF7D1BE90FDE8B46F104A0BBC0E90CC1FC077F8809F73D0443676DB9DD50DF03D02ABC4FA48B4DFC8C4F9D8E298B96C0111A228EACF3B50401C89C23FCE5E2148DED82F5CFE2D0CB2FC22DEAFEA40BCDDA5AB27133E2567C960E0DDBDCB5B5C87D';
wwv_flow_imp.g_varchar2_table(31) := 'F447DDDE03E00C0941EA92A548484D058809B0D6C7120448B9E54B98BD7EA3E12ECEF6B2527CFAC06A14EEDA21EFAAC4B90398B525AF1E7880469466AEBE132559476426D143866096A8F2C48C1A25E3AC16B00401C6ADBAD7D86A86B88B68D656C6EABB';
wwv_flow_imp.g_varchar2_table(32) := '5079BA501C41F9734DFBE6B731FDC9670C9FB555F5FE7B48BF7FB57C0F00C46754D238A48AC66E4854A438B2EED7120430D4BCA227B774FBEFB0FFB17568F134BCC3A2A2B0E8A96791F0CDEF00A2110E833EF23D001B5F80CB33A2D466B363CA9C6B3161';
wwv_flow_imp.g_varchar2_table(33) := 'FE7CD81D0E8334095C314C001D6DA3CCDA7AFC3F91FDFBD7E570EAF88993B078F3AB86CFDAEA6D446998E85C4BBBF1460C9B3451C7520777564C009DEC470BD1F69CB53549D4AF95F77E19FCA26E1AD2D0F33D0043478C409AD02762E8509D4A6C8E6C98';
wwv_flow_imp.g_varchar2_table(34) := '003AD8B1F6C3DDCA42B472D696A85ACCBDE73E4C5EBB0EB6D0501D24789985A87E5D7CEB4D6548434B7D9DBC28696A0A92975E0F479881BA48E9830BF8FA6A26C02010A63AF6D92D2FE1E3679F86BA106DD4F0E158BAE125C47FE15F079173FF2F554794';
wwv_flow_imp.g_varchar2_table(35) := '66FDE63539A4C1E1742275D1628C993913369B057D9C5EC0C804F002A4DE9228C3861F7E08C7DFF97F795A7DEF5758F254196744A0B711A591D131C2C5793362478F364285A095615A023835FF7834E04B4F0B511D5B19369C9F27B39D7EFBD73ADFFB35';
wwv_flow_imp.g_varchar2_table(36) := '244EC61911E839A294648E1C9B8419CB6F466874341D0E68A32520D50BB558AA7166D99B97009A45A2DC9EA98E7A18ADE7B0615A1497DEB595F8BD3B0187430F11DEE5217A95CF8BEA8EF21E00CF88529BCD8649B36661E28205B03B07A74B7B4BE72855';
wwv_flow_imp.g_varchar2_table(37) := '5226C46EDADB04A62D99D668EEC6CEE50CC99803DD943AF653DD870DFB6BD69632A4E1B18791271ABC6A7942434331E3FA1B30624AB21A35A87D5B7317019C4C80416139C08B07775988DD2633682BBF24C30309D0B0E14099B5A58C28ED31A461C8D078';
wwv_flow_imp.g_varchar2_table(38) := 'A4DDFC19448906F840CAD7DB356D4D5D04D0FE99F4963698E3CCFB04B07515ADF14CD1806D44C386D3EF5DD96DD6D69C3BEEF2CBACADCAF7DE45FA836BBA0D69489C3C0529CB6E8433227CC065ECED429A33ADC66BFF4CD438B3ECBBEE12B394C8530EA7';
wwv_flow_imp.g_varchar2_table(39) := 'E6B15D5F74DA13DB8F1DD5B17FFB2BEC7FE2C77221DA88D82158FCDC068CB8F5AB107E4518F5E9504794BEF44BB83D43BB1D760752E65F87B1B367C3A679DAE9A5536B4B93CC2AC466DADBC41A6D801ACDCA0FD2AA5708C83AF61FFF20538D4C49C5A22D';
wwv_flow_imp.g_varchar2_table(40) := 'DB60F4AC2D1AD2D0734469445414662E5F8EB8A4B1523FBD03759595324BED9F898C3449C0B4D48ED47841CA4F9D043562BDB1596F75EC945BBE8459BFD80047FC306FB2D02D4D63D661D09006754429653C2C61B47071AE40786C2C1DFA647335B7A0A6';
wwv_flow_imp.g_varchar2_table(41) := 'A242C99B5A52511A2C954813FD989600D4708B743A1553D1EB83EA342F8B56227BF9A9FC7BF73A36AD1871DDBA4761F870EA8E0E94BDB91D198FFC08EA9006BA1127CE988929A267D711D259AE5E8AA04B54F58512990F61C84F0009477005E242BBA6F7';
wwv_flow_imp.g_varchar2_table(42) := '95EDFBA84FE5651D7B53571D3B56FCD32ED9B405B137DCD4E775BE38417D16F9A2DD71F4F5527D04D200000A9549444154DF405DBD22242414D3975E8F912929003101BEFD54969C97028608F7AA3C3061C0B44F00B295D678C599FB41373AC56BB7DEEA';
wwv_flow_imp.g_varchar2_table(43) := 'D88973E761FEE6AD081D3F419BD4E7611AD2F0C9EA9528D63CAD62E2E290B66205A2478EF4B97C12E06E6F47956729763A1E1A1A423BD36EA62640A8DD8E484FEFACABBD0DD57B77753364CF3A36FDB9A67DFBBB9DB3B622A3BAA5F5F5813AA4A1B6F482';
wwv_flow_imp.g_varchar2_table(44) := '1495200898BA6C39E8354832D2C7819A920BF2C963F6EA0F41696A025001B54F81137FD80E615D652BFBC3FF74AB63CB595BDFF81660232AC0988F70B79EFBD5D66E8B64D9858B33F9DAB9183F772E6C0E03751125AED2547FB4554871CA945FD313202E';
wwv_flow_imp.g_varchar2_table(45) := '2C541AAE5634EEAA77BE0FA58EFDDFFF25B8D0A19C8BF7D7ACADEA2AD02259C7FEEF2D450FFA5117A68A9F30810E0DDD9A6B6B512E305285C6F9A1FEAFCA366A6F374A90BFE45035486B487AE38AB68E3D69F90AF863D656737E1E684469696E8E84267E';
wwv_flow_imp.g_varchar2_table(46) := 'D4A84E17A71F16A6128E27141C3820FF140833F2A449E54C1AB09BB45CDD8A9518190187AD7B55C2EE7062EEBD0F183F6B4B6856F9CE5FB16FEDFD68124F0071A87CC74D4B45F2E2A5F0D7C254E5274FA2DEB3302E6135D622AB45588200E4C71E2D48A0';
wwv_flow_imp.g_varchar2_table(47) := 'DC699E9FB90F3C84F8CF7FC17364CC8E6690153CFF0C0E6DD904B7DBAD087588BE8AE9E2C61F3D7D3AD09DA330EAD3DAD088D3795D4FA231022B228151F2FD29C712042080878585098F505707D2C937B6A34333E497D2F8725316C9BAFF1E14EEDE29C5';
wwv_flow_imp.g_varchar2_table(48) := '448BDEDC59CB6F464CC22819E78F40E14151F5F110923C3FF1022B7FE8E10F99767F08F597CCA4E848F9275B7DBE1827D73F6B882A3D17C922A123C72621F5C6E5081DC4AC2DCA67B0DBF9ACAC6EC31EC645450D36CBA0BA3E8008E07BDCC21D0E8C080F';
wwv_flow_imp.g_varchar2_table(49) := '9782CE64A4A3E2AF7F96C7BA0744CBB2E72259369B0D93675FA3CBACADC1EA4B37FFB98253329B911111087358EA9680B54A2B4C9D20EAB74342BA7A378FBCBA0535BBBAD6EE144974F9BA1B1B90D76391ACD0B070CC5C7623864F9EA48B8CC164D2F3E6';
wwv_flow_imp.g_varchar2_table(50) := 'A7FE92513ACF29188C7E465D6B3902503B737C4C34C8CD4720BBC5BFF401511522CF0C1DEBB1D1225934A4E1FCA18332BBB861C39176F30A441AFC0E32A98026D0DBCD3F3E3A4A560F35494D1FB49BBE84BD1450218130B84A024A724878662EFCFE750A';
wwv_flow_imp.g_varchar2_table(51) := '0E6AABD9B3137BEFBE03DA210D49C9C94859B60CCEF0B041E5ADC7C525D947A1ADF60C0D0DC504810561A247FEC196872509A01A699C303CDD00EA71CEF6DFA1E085E7D0D1DEAE4679BDA76BCE6E7D19077EF18CBCC6617762DA750B31266D968CF357A0';
wwv_flow_imp.g_varchar2_table(52) := 'C3E5466166268A85BF5FD581FE000803F5D88A7B4B1380FEF5E806D092A070E707C85EB716EEBAAEA505AF7663D07BBF9477EB6A1AD491D131A2CAB31C431213AF7639E0E314AE96561CDBBB079734E37CE2C34241D51E1F8B0EF8EC2D4D00D53A448251';
wwv_flow_imp.g_varchar2_table(53) := '1AEF5099E8143AB0E66EB46BC6C5A8697BEED5210D178F1F93A7868F1E8319372D47584C8C8CF357A0B9B60ED9A2915FA7E975A6C66E92C5DC9D7DE1CF04F02043DE21FA47B4799A827565A5C8B86F159A72B33D292EDF958B7F7CED90069BCD864933D3';
wwv_flow_imp.g_varchar2_table(54) := '3079E122D87D3C6BEB726D2E8FA92B2D45CE9E5D6891EF02B329FFFA09C2DD79796A6BC630013476A73AF194D81838C58D4CD12DF5F5C878F821D4EEDD4D8772A3A5164F3EF7340E8B3ABF3AA4215434269585A9A64E858743F0E7E7D289133896B10F2E';
wwv_flow_imp.g_varchar2_table(55) := '4F7B86CA4465A332FA53AF4093CD04E861119A4C3F75482CA8D38C4ED10DFEB1B8D9E9CD8A102E535A24EB907832146948E18B85A948F640B60E77078A3EF90485F442704F0654162A1395CD13C53B0F024C000F10DA1D0D034E164F82584D8759EE9BDB';
wwv_flow_imp.g_varchar2_table(56) := '958EAD7D6B56A1EAEC19997CCCA4C998263AB7F45E984A0AE8478016B43DF1E15E94159F95575119A82C5426191940017FABC204E8C30276510D9A283ACCB44327CE8B8EAD56D1C34B9738EC0E6561AAA4397300BB8DA2FCBAB508AF55AE68EC56575648';
wwv_flow_imp.g_varchar2_table(57) := '3D468A863D95C12ECA222339D00D01264037382E3FA0A1C1BD794C265F730D7CB930D5E59AF41D53575A263C3DBBD0A45904789CF0F2F41C02DE770ED63DC304F0C2F6E433A706243524D5E405870FA3A6A46BFD1C35DEE87DF9A953A2B19B0E9767C944';
wwv_flow_imp.g_varchar2_table(58) := 'D291741D2AFCFC46EB128CF298005E5A2DCAE944B2681C8789AA0F5DE272BB909FB91F65F9C2FFDF39B598A20DDB3A4483FCCCC18328389A25DF48A936764957C3140972414C807E1890E617270F89418CA6715C949787C28F33E16E77F523A7C125551A';
wwv_flow_imp.g_varchar2_table(59) := 'BB1F7D88524D639C74E2C66EFF71F52301FAAF6C205C4153052789C6F170CDC0361A62704CB845DB356BEAFB4AD756D137A13476CBCBA5086AA8934EDCD89590781D6002780D55F784899191A0C6B1EAFFA9AFA941F6CE0FD05859D53DA18E470D97CA45';
wwv_flow_imp.g_varchar2_table(60) := '6377A76CEC926CD2614C64848E52AC9515136010F6A6C6F1A49818D05381B2696D6D458E7812549F3B4787BA6E150585C84DFF10ED9A9EDDC9A2AF8274D05590C53263020CD2E0D121A2711C1B0BB5714C8DD3E3073E46494E0E64EB74103228BFB3C2E3';
wwv_flow_imp.g_varchar2_table(61) := '742AEBB0E888EE6C6D932C6A9073637710C07A2E6502788018CC8EE6D152E3385A788AD47C8A4F1CC7A98C7D70B7F57F6E819A87ABAD0D274463F7C2E942350A24836451835C467260C0083001060C5DF70BA91A4455125A7E453D5351560A6A1C376ADE';
wwv_flow_imp.g_varchar2_table(62) := 'B6A29CF3E287AEC9DDB513D59AC6EEF0B030900C92E545169CC40B0498005E80D49F24B4A25AA26820530395AEABAFAD45F69EDD28D8BF1F2DB5579F64D322D2535ABAA6A9A181B2500697526337D122ABB5298536E88709E003A0C9454A6370B4FFD4B4';
wwv_flow_imp.g_varchar2_table(63) := 'E8EC911DEF8B6A5186E83C3B8EBAB232D04CADF6E616255C969FAF9C3BB2E303505A552DCA831ADADCD85511D177CF04D0174F991B754CA5889EE3088743C651A0A2F4028AF27290B72F1D07DF7D1B87FEF68E122ECACB059DA334EA16E97082F2A086B6';
wwv_flow_imp.g_varchar2_table(64) := '1AC77B7D116002E88B67B7DC6808328DC3A72A1185BB9DBCC201A5A56BA8B14BE12B24E55383448009304800BDB99CAA44D3E38680AA453444999E0EE4CAA49E5BAAE28489A704C5D1BCE449A29799D2D235DEE41D6C69024D5F26808116A1C929344499';
wwv_flow_imp.g_varchar2_table(65) := '6EF26971B1481B1A8799629B26AA4A1447F392890806AA6479514C00CBDF02D6068009606DFB5BBEF44C00CBDF02D6068009606DFB5BBEF40612C0F25833000188001320008DC22A19870013C038AC59520022C0040840A3B04AC621C004300E6B961480';
wwv_flow_imp.g_varchar2_table(66) := '0830018C300ACB0858049800016B1A56CC0804980046A0CC320216012640C09A861533020126801128B38C8045800910B0A6318762815E0A2640A05B88F5F329024C009FC2CB99073A024C8040B710EBE7530498003E8597330F74049800816E21D6CFA7';
wwv_flow_imp.g_varchar2_table(67) := '08F890003ED59B33670474418009A00B8C9C49B022C0040856CBB1DEBA20C004D00546CE245811600204ABE5586F5D106002E802638F4CF83068106002048DA958515F20C004F005AA9C67D020C004081A53B1A2BE408009E00B5439CFA04180091034A6';
wwv_flow_imp.g_varchar2_table(68) := '0A0E45834D4B2640B0598CF5D515012680AE707266C186001320D82CC6FAEA8A001340573839B360438009106C16637D7545404702E8AA1767C60818820013C010985948A022C0040854CBB05E8620C0043004661612A808300102D532AC9721083001F4';
wwv_flow_imp.g_varchar2_table(69) := '8099F3085A049800416B3A565C0F0498007AA0C879042D024C80A0351D2BAE07024C003D50E43C8216012640D09A2E30140F762DFE090000FFFF4F70D8A5000000064944415403006E18E057D4DF2E2D0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10565082400533327)
,p_file_name=>'icons/app-icon-192.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
prompt --application/shared_components/files/icons_app_icon_256_rounded_png
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D49484452000001000000010008060000005C72A86600001000494441547801EC7D07601CC5B9FF6FEE4E92556CE4A262B9E08A09AE6007DCE8FC097985662B01CB10C87BA13A84167A31F51930D560884302C405880BF008';
wwv_flow_imp.g_varchar2_table(2) := 'FF0031C6806D0CB8CBBD774BB22D17D9AA77B76FBE93766F259D644BDA9BDDBBFD4E3BDAD9D9DD6FBEEFF7CDFE76766677C603FE31028C806B11600270ADEBD97046006002E052C008B818012600173B9F4D773702643D1300A1C081117029024C002E75';
wwv_flow_imp.g_varchar2_table(3) := '3C9BCD0810024C0084020746C0A5083001B8D4F16CB6BB11D0AD6702D091E03523E0420498005CE874369911D0116002D091E03523E0420498005CE87436D9DD0898AD670230A3C17146C065083001B8CCE16C2E2360468009C08C06C719019721C004E0';
wwv_flow_imp.g_varchar2_table(4) := '3287B3B9EE46A0AEF54C007511E16D46C045083001B8C8D96C2A235017012680BA88F03623E0220498005CE46C36D5DD0844B29E0920122A9CC608B80401260097389ACD64042221C0041009154E63045C820013804B1CCD66BA1B8186AC67026808194E';
wwv_flow_imp.g_varchar2_table(5) := '67045C800013401D276BBFFF65D2A11BAE4C2FBA2137FBE08DD774397C5D6EF7A231A37AEFCBCB3DA3F0DA5103F68FBDFAACFD63720773702006D237E423F215F98C7C473E245F924FC9B775DCEDFA4D571240E1AF7FDDB370CCE8AB0BF3463D519837FA';
wwv_flow_imp.g_varchar2_table(6) := '631996CBB04706ADA838B5BCB2CA7748ABD2F6F92BFD3B2B82DA564D888D1E686BE0112B839A676950684B38381003E91BF211F98A7C46BE231F922FC9A7E45BF2B10CE46BF2F9C7A132406561CCA81E6E6403571040D198DC418563473F5A9897FB4D61';
wwv_flow_imp.g_varchar2_table(7) := 'DEE863F00536436036201E0370850C8364C8918117772040BE269F4BDFCB32406541882D54360AC68E9E5F3066F4238563AF1A182F503466475C12C0EADCDCC4A231A3FEAD70ECA8C90579A3766A425B0E0D4F02DA79128C54197861042221902A349C2F';
wwv_flow_imp.g_varchar2_table(8) := '049E82E65D210961AB2C47AF14E48DBE98CA54A413623D2DAE08A0686C6E2FE9AC67331243D5F6CFA0895B054497587712EB6F1B02DDE5A3C41F043097CA54D198D1CF5019B34D9B28641CF30450949B9B569437EAB7B28AFF9DA6699BA4B31E94387592';
wwv_flow_imp.g_varchar2_table(9) := '811746C04A043A69020F51192BCC1BFD6DD198DC1BA8EC5999811DB2629A000AF372AFD212B5C51AC45FA061A41D00729EAE44E05CF958F94E30519B5F3866D42F9C8CC089748B4902D83776F405F2E2FF5E3ED3CF9106F695811746403902B2B6391842';
wwv_flow_imp.g_varchar2_table(10) := '7C4E6591CAA472052CC830A60880AA5C456347BFEFD1F0B5BCF8875A603F8B60042C40401B4A65B2306FF4542AA316085426226608403EE30F97D5FD959A866B94A1C31931024D4360AC96145C412F8935ED34FB8E8E09029017FFF508DDF5E1CA9735EC';
wwv_flow_imp.g_varchar2_table(11) := '2B1E9C739311D044CFA0D01685CA6C934FB6F6849391E66802D0005124BB5EE4C5FF1E804419786104620181442AB34579A39F72BAB28E25007AF14202388BBA5E9C0E22EBC708444240DEC01E291C33FA3D2ACB91F63B21CD9104A05D70812F33519B2D';
wwv_flow_imp.g_varchar2_table(12) := '01BA5A065E1881D84540E0FA8C446D269569271AE1480228EAD4E16F923DFFC38980B14E8C403310B85C96E9779A715EB34F39D9131D4700B2F1648254FE5A19786104E20981B13565DB5136398A000AF246DF291B4FEE771442AC0C236015021AEE0F95';
wwv_flow_imp.g_varchar2_table(13) := '71ABE45920C73104509877F50801BC68814D2C8211702C02B28C4F2CBA36D731AFAD3B820042ADA44250579F23F4716CE961C5E20101AFE6D1DE0995F92859D314B18EB8E03292B427A1899E4D519C8F65046218815EA132EF00036C278082EBAEEA070D';
wwv_flow_imp.g_varchar2_table(14) := 'F73A000B5681115087802CF30579B9FDD565183927DB094004BD4F4BD5BC32F0C208B80901AF8066FB9B82B61280EC16192E3D7E850CBC30026E44E00AAB1B049B0AA2AD0420ABFE2F3455613E9E11882704825E8D6AC0B699641B01148E1D75A5B49A6A';
wwv_flow_imp.g_varchar2_table(15) := '0072C50B23E04E048486F38BC6E65E6697F5B611800671A75D4673BE8C80931008427BC02E7D6C2180BD63AE3E55321F0DD16D97DD9C2F23E01804E85A28B82EB77B4B156ACEF9B61080D7E3B9512A2B64E085116004002134ED37B0E1A79C003440F67E';
wwv_flow_imp.g_varchar2_table(16) := 'E006F08F116004C20868B83E746D845394C494134061DED5E748CB4E9581174680110823D0BDE6DA08A72888292700213CD4FAAFC034CE8211882D04E4B5D1ECDE80E65AEA69EE89CD3E4F13CA8D6CB6AE7C2223A012010DCAAF0DA504B0FF9A6B72006D';
wwv_flow_imp.g_varchar2_table(17) := '804A4C392F4620861038BB3837F71495FA2A2500CD13B8541AC7ADFF12045E1881080888CA04ED9711D2A396A4960084C6B3F944CD952C381E10100217A089BF961CAE9400A4A28364E0851160041A4640E935A28C00B4F1E3292F7EFE6FD8F1BC871120';
wwv_flow_imp.g_varchar2_table(18) := '04FAD75C2B148F7AA08B32EA995006FB37AEA18B3F99E21C180146A04104520E6EC83FADC1BD16EF5046009A08F2F3BFC5CE6371F189805F88937E0C682902CA0800506714F8C708C43002C283B824806EE01F23C0089C18010DA79FF8206B8E50580340';
wwv_flow_imp.g_varchar2_table(19) := 'B6352AB3144620DE1110CA6E960A0940630288F772CBF65984C0C95D2B5664A68400C6577701B6B7426196C108B8008176AABA029510C0ED3B97A54AA7F964E0851160044E8C40C2BEA54B5B9DF8B0961FA184007C410F8FFBDF725FB104172190DCDE9B';
wwv_flow_imp.g_varchar2_table(20) := 'A8C25C25045011104A8C510118E7C108A840E044D78C553A282100AF26B8066095C7588E2B105075CD2821804A7F809FFF5D516CD948AB105075CD2821000FB8066055C16039EE4040D535E35101A72729891F015400CD79C40D028D5D33561AA98400BC';
wwv_flow_imp.g_varchar2_table(21) := '41B8B61130A86928F5FB71AC8A43533020CC083B2B0B7B2CC9F2685072D354420095B184BC45BA1EADAAC2C62347917FE830361D2DC196120E4DC1803023EC08C31289A5456E891931555A65FC1040CCA06E91A27B4BCBB0ADE418CA02018B24BA570C61';
wwv_flow_imp.g_varchar2_table(22) := 'B855624998BA1785E859AEA406103DF59D27F9407905F697973B4FB118D78830256C63DC8C16AB6FB50026000B11AD0804B14FDEFD75911DBB75C3808B2EC639578F8AB9F0F32BAE42F6A9DD74538C75FFEB6EC0FFFBFF739584F35E79035DCE0E8F2343';
wwv_flow_imp.g_varchar2_table(23) := 'D812C686321C6931024C002D86302CA0B8A2024168A184F40E19E87AD66024A7A787B663E95F556929D6CD9F87821DDB0DB593D2D230E2D9E7917DED58232DDA91A4D3FAE0F4F14FA34D76C7505684ED2189716883FF59820013802530560BA9303DF3B7';
wwv_flow_imp.g_varchar2_table(24) := 'CDCAAA4E8CB1FF25858558F5D55C1C3B72C4D0BC5DB7EE18FEC614A40C3ACB485319E93C62A4915D453068C439D272043C2D17C1127404AA64979F1EF7B54AD2A331B32E58B70E6B172E80DFD4EADEE3828B7096AC8AFB32326DB1A372EB16ECFAEE1B23';
wwv_flow_imp.g_varchar2_table(25) := 'EF4A1713800182851126000BC1848900008158F905AAFCD8BC681176AC5B6BA8ECF1FA30E48EBBD1F3BE872012ED798DE3F0DC2FB0F0CE7128292A32F4AA79C20A6F73AC45083001B408BED83FB9FCE851AC993717070BF619C6A4B6EF80912F4F42DBCB';
wwv_flow_imp.g_varchar2_table(26) := 'FECD485319D1640D64DB2B13F1D34B2FC0EFAF5299B5EBF26202709DCBC3061FDEB51BABE7CD43D9F1E3466276BF01182A9FF7937AF536D254460207F663C53D7760F3979F837FD147800920FA183B2E072DA861F78A15D8F0D30F0804C32F2BF5BB360F';
wwv_flow_imp.g_varchar2_table(27) := 'FD274C84A74D1B5B742E5DB91C0B6FBB0907366F32F26FD7BD07068E31F53CC4CE93956183159168C960028816B20E95EB2F2BC7866FE6638F6C5CD3554C484EC6F0279F45C7EB6E043C361409D9765234F3032C7AE83E541C2BD1D5428F8B2EC1592FBF';
wwv_flow_imp.g_varchar2_table(28) := '8EC49A6EC0D08EEA5ED65094FFB51C011BBCDD72A55942F310387EE000F2BFFA178E1C2A3604A477EE8A91B2CA9F3AE46CD8F10B961EC7FA271EC5CA77DE966DA8D5573735400EBEE32EF4BCF701D8D50069071676E4C9046007EAAAF394D7D5FE8D9BB0';
wwv_flow_imp.g_varchar2_table(29) := 'E6BB6F515919FE34ABDB88733164D29BF099EFB00A75ABDABD0B3F8DBB05BB7E5C6CE49ADAA10346BEF41ADA5DF6EF461A47A287001340F4B07584E4A0ECE2DBB2F87B6C5DBD2A7C8795D5FCC1B7DD81DE0F3F0E9164CFFB0A258B1660C1B85B71D4D4FB';
wwv_flow_imp.g_varchar2_table(30) := '9033701086BE3E0549BD95CD8DE9081F9D488968EE67028826BA36CBAE2829C19AAFE7E1C0BEBD8626C9E96D3182EEB0FF71B991A632A2F9FDD8356532163F3D1EFECAF047537D7F752DFA3EFD9C6D0D902A3170525E4C004EF28685BA1CD9B3473EEFCF';
wwv_flow_imp.g_varchar2_table(31) := '43A9A9512DEB8CBE183EF9CF68759AB2A9E76A5914387C08AB1FBC17EB3F9E63A45303E4B0C79F42CE0DFF0578BD463A47D420C004A0066765B95017DFDEFC7CACFF61B1ECE2F31BF99E31FA5718F0DC4BF0A4A71B692A23E5EBD7E27BD9C557B066B591';
wwv_flow_imp.g_varchar2_table(32) := '6DDBAEA762E4A4B79076CE30238D236A116002508B775473F3975760A36CE8DBB569A3918F2FB115863DF6243AFDF626D875873DF0C91C2CBCF74E94C91A80AE58B7F32FC4E05727C397D3494FE2750404A29DC404106D8415C92F2D2E9655FEB9387CF0';
wwv_flow_imp.g_varchar2_table(33) := '8091639B8E39B28B4FDE61870E37D25446B48A0A6C7AEE192CFFD364046B3EE2F1C806C8336FB91DBDEF7FD8B606489518383D2F2600A77BE824F43BB8652B567F331F9515E146B5AE4387E1EC37FE84844E9D4F4282F587F8F7EEC1D23FDC86EDDF7C6D';
wwv_flow_imp.g_varchar2_table(34) := '084FA606C889AFA0C3E55719691CB1170126007BF16F51EEC14000DB7FFA099B572E0F77F1098141BFBB057D1E7B0AA255728BE437F7E4633F7C8F05BFBF058776EE304464F7ED876193A7A0D5E96718691CB11F012600FB7DD02C0DAA8ED3A83D5FA370';
wwv_flow_imp.g_varchar2_table(35) := 'D74EE3FCE4366D30E285579071D568234D694412D2DE77FF82EF9F7814556565D07FA75F7935FAFDCF4478650D404FE3F5891150710413800A942DCE23346ACFBCDAA3F664F4EE23EFB06FA395ECEAB338BB931217A4CF8A1FB91F6BFEFEBE713C35400E';
wwv_flow_imp.g_varchar2_table(36) := '7D643CBADC741B84CF67A473C43908300138C71727D64403F6AD5D8B757546ED39FD8AAB31F0C557E16DD7EEC432A2704485EC75583CEE26EC5DB9C290DE26BB2346BEFE265A0F0F0FE765ECE48863106002708C2B1A57245059854D8B1660E7FA75903C';
wwv_flow_imp.g_varchar2_table(37) := '103AD8979088A10F3D862E37DB77872DFEE7675870F71DA00F8D424AC97F3492EFCF5F7F0B099DBBC82D5E9C8C00138093BD53A35BF9E1235823ABFCC58585352940EBACECEA3BECC8F38C349511ADB2125B264EC0D2492F2318A87EE14808818137FE37';
wwv_flow_imp.g_varchar2_table(38) := '4E7FFC2978525255AA137779A93288094015D2CDCCA778C776E4CFFF1A65A5A58684CE43CEC6396F4C414297538D3495117F610196DD350E5B2529E9F926A5B5C6F0679F4766EE35802402F02F2610600270A89BB480861D4B9762930CC19A517B84A8BE';
wwv_flow_imp.g_varchar2_table(39) := 'C3FEEC89672052526CD1FCF8B2255834EE66146FDB6AE4DFA1576F8C905D7C2903CF34D238121B08300138D04FD485B6EE9B79F527E69830D1BE3BACA6A160C6547CFFC803A8308D21D8EBD2CB30E8C5D7E0ED90E1402459A51321C00470228414EF3F56';
wwv_flow_imp.g_varchar2_table(40) := '5484FCB9735172F8B09173879EBDE41DF66D24F71F68A4A98C048F9560ED630F227FDA7BE106485F027E7EF71FD1FDCE7B21121254AA13F779A93490094025DA8DE5259BF68B366CC0DA05DFA1AA2A3C6A4FCF4B2EC5A09726C93B6C87C6CE8EDA3E9A98';
wwv_flow_imp.g_varchar2_table(41) := 'E34759E5DFB374899147EBCC4C8C78E575A45FF20B238D23B18900138003FC169A98E3FB45D8B66675ED3BEC3DF7A1C7DDF7D976873DFCD597F526E6E8347808CE7EFD4F48ECD1D301C8B10A2D458009A0A508B6F0FC481373A465C83BEC6B93917EF1A5';
wwv_flow_imp.g_varchar2_table(42) := '2D94DEBCD38D89395E7CDE9898434851FDF3AEC3194F3C0B8F6CF1979BBCC401024C00363AC8EB1DE20000100049444154F1C89E3DF526E6C8197466A88B2FB15B775B340B141F44DD893992525331ECE909C8CEFB0D6C1936DC1624ECC95475AE1ED519';
wwv_flow_imp.g_varchar2_table(43) := '727E8016D4B067E5CA9A517BAA27E6101298FE637F83BECF3C2FEFB069724BFD52B63A3F346ACF813A13730C9755FED4B386A85748E64823076FFA30FC7D814CE2C5420498002C04F36444E9A3F6ECDEB2D9383C312535F4124DF698EB60CB4B34B28BAF';
wwv_flow_imp.g_varchar2_table(44) := '68D6875874FFDD283B7A04FA4F9F98C39795AD27295D972CAA1E39F8F09EDD4AF37553664C000ABD5D1A61D49E76B2AA3FE2CD3F2365D0590A350967A5959561C3334F60E55FFF8CA02402DAE3F17A31F8F63FD83731472080DD6FBF556FE460D28D83B5';
wwv_flow_imp.g_varchar2_table(45) := '0878AC15C7D21A42E0C0E6CDF546EDE97EC14538EB9537E0938D7EB0E147D5EB2577DC8A9DF24EAB679F1A9A986312DAFDFB7FEA494AD7347270FE03F760DD9C594AF375426676E8C0046029EAF4245F2D508F05FD016CFBF1076C59B5125ACD1D56C83B';
wwv_flow_imp.g_varchar2_table(46) := 'EC903BEE42AFFB1E825D535F45AA5E771C68EFC41CE5EBD762719D9183BD3E1F323BDB33AC59B527E3FB3F134014FD5B79EC18D6CD9F87A2DDBB8D5C52DB77C0B92FBF8EB697D934F55503D5EB3346FF1AFD9E7ECEB689390EFEE313D0C8C1A5A6918353';
wwv_flow_imp.g_varchar2_table(47) := '6477E3808B2EC12936B541184E8BE3081340949C7BA8A000F9F3BEC2B1A3478D1C3AF61B80A16F4C4152AFDE469ACA48A4EAB52FA91568D49E4EBFFD1D206B262AF5A1BCE8B3E2CDCF3D836593272158337230A56775E98ABE175D8CC4B45408E3F528DA';
wwv_flow_imp.g_varchar2_table(48) := 'C3C14A049800AC44D35450F7CB966BBFDF6F48EF774D1EFA4D9868DB1D96AAD77527E648EFD4192327D9376A8FBFE6B3E26DA691838510E835F04C74FBF9CFE1F17943F8699202429138FE6797691EBB32764BBE34F5D5F0279F45C7EB6F845D2FD11CFC';
wwv_flow_imp.g_varchar2_table(49) := 'DF8F40D5EB3253F5BAEBF09118F2DA9BB06BD49E489F15272527A3BF6C186DDFB3875B8A87ED76320144D105E99DBB62A4ACF2A70E391B76FCF4893996BDF58651BDF6C83BEC201A36FCE1C721E405A75C2F59CDDF37EDBD7A9F15A7CBDE87FEF2793FB9';
wwv_flow_imp.g_varchar2_table(50) := '6DBA7295DC9C211380A5DE1786341A176FC86B93E1CBEE68A4A98C449C98E394B618FEDC8BD5C3868BB0AEAAF4A2CF8AD78D7F18AB674C353D2C015D4EEB833EE79E076F52624455D46B1A518DB84C6402B0D4AD9A212D7BE4B910AD5A19DB2A239126E6';
wwv_flow_imp.g_varchar2_table(51) := 'C8ECF3330C7BE32D24CB864895BAE879E99F15EF5EF2939E04AFECE23B63F808E4F4EB07344248615411973F3B8D6202B0137DABF396D5EBBDEFFDB5DEC41C7D2EBF12035E7819DE76EDADCEF1A4E41D9EFB45BDCF8A536ABAF85A67679F940C3E283A08';
wwv_flow_imp.g_varchar2_table(52) := '3001440757E5524313733C7C1FD67C38C3C8DB979088731E78185D6F190721EFB6C60E4511E3B3E2975E303E2BA6AC33723A195D7CB4CDC13E049800ECC3DEB29C1B9A9863846C836873DE8596E5D31441913E2B1642A0A7ECE2EB3174A8D1C5D714997C';
wwv_flow_imp.g_varchar2_table(53) := 'ACF5083001588FA95289C59F373C3147E2A9DD94EAA26716E9B3E2C4A456E877FE85E8C05D7C3A4CA1B5DDFF9800ECF64033F3A737E8421373BCF672AD8939065C7FA37D1373681AF6CFFE7BBDCF8AA98B6FC0C59720A55DDB665ACBA7450B0126002B91';
wwv_flow_imp.g_varchar2_table(54) := '95555C2BC53524CBBFBF08CBEFFE7DFD89399E790E59D7E4A1B1167544E9479F156F7CE609ACF8CB14E89F155356A12EBEF3CE87B755126D362F4862314EE43E41030A2B221E2B84B08C6A04BC260208949757275AFC3FF406DD6DBFC3C1AD5B0CC9C6C4';
wwv_flow_imp.g_varchar2_table(55) := '1C368D29A07F56BCC3F45971AD2E3E43D3E6450295E15192CD18374F1A9F65468009C08C460BE3099EF0EDC96F9A3CA38562AB4F9777C182F7A7D57B83CEEE8939227D566C75175F6545984C133CF15364AB1D6BEF7F46D342FC7D220CA79504102C3D8E';
wwv_flow_imp.g_varchar2_table(56) := 'F54F3C8AFCA9EF1A6FD0797D0918F2877BEC9B982310C09EBF4EA9376A4F34BAF82ACBCC041026590B5DE75A51E112EB5A08AC33DC7C77AA3A7ECC12C1953BB6E3A771B760D78F8B0D79A91D3A60E42BAFA3ED2F7E69A4A98CD03B07346ACFDA597F37B2';
wwv_flow_imp.g_varchar2_table(57) := '1582BAF806221A5D7C956565463E092692351239D26C0498009A0D5DFD13CD8F00C7F7EDAD7F4013538E7EFB3516DE711B8E16EC33CECCA919B5C7AE8939F4770E0AD6AC36740A77F1F532D2AC8C549808C0C78F0056420B26000BE13417CEFDEBD7355B';
wwv_flow_imp.g_varchar2_table(58) := '32BD41B773F224FC30E119F8ABC20D60FD640B7F68D8F0366D9A2DBB2527167FF62916C8DE87E3070E18624E69DF1ED1EEE22B2F0B4F8D9E606A67319488C18853546602B0D013B51E01642F80BF19B5007A836ED57D7763C33F3E3134A33105863DFE94';
wwv_flow_imp.g_varchar2_table(59) := '6D630A18EF1CBCF12A82F2D95F57AC4BEFD3D0E7DCF35BD6C5A70B6B601DA8AC32C652A443CC18D336879621C004D032FC6A9D5DB770966DDD5C6BFF8936F437E88A36846B0F6DBB9E8A9193DE42DA39C34E747A54F6EBA3F66C9D37D790EFF5F9F0B3A1';
wwv_flow_imp.g_varchar2_table(60) := 'C390D3BF3F4494EFC8A5878A8D7C858CF9F81140A260DDC204601D96A0029AECAD1EC68AC4162F5F4EAB1307D9C517E90DBA6EE75F88C1AF4E862FA7D3896544E188D03B07E36E46F1B6AD8674BD8BAF4D4E8E9116CD48B16940D564493C847134F3739B';
wwv_flow_imp.g_varchar2_table(61) := '6C26008B3D9E9E181ED462FBFC794030D8680EF406DD863A6FD079E45DEEAC5BC7A1F7FD0F4324B5E00DBA46736E64A724A4821953EBBD73108D2EBE46B48016D47060EF1EE31033B646620C469CA4321380C5DE686B1AD5A652F6DF1F5FB1ACC11CF437';
wwv_flow_imp.g_varchar2_table(62) := 'E8769ADEA04B4E6F8B11135F41FBFFBCB2C1F3A2B98346ED59FBD883C89FF61EF481388410E839606054BAF81AB3E55851916C04AD0A1D22E4FFB62672959BBC588000138005209A45503B40AAACAAEA697BBFFC5C8FD65A97C88B7EC1B85B71784F78CE';
wwv_flow_imp.g_varchar2_table(63) := '80ECBEFD306CF214B43AFD8C5AC7AADAA0770E7E9455FE3D4B97185926EA5FF1F58A4E179F91518448B1091BC2D417E5F686082AC47D121340145C6CAEAAEEFCEE1B50CBBE918D6C458F34EFDDCFAE1E8DFE135E8457D6008C631546F4770E4AE45D57CF';
wwv_flow_imp.g_varchar2_table(64) := '5645179F9E57DD75BDEABFA96655F758DE6E3E024C00CDC7AEC133D31313420D827440909EA73FF988A2081C3E047A836E9D69DE3B5F622BD0C41C9DFFFB16D8323147551522BD73D0A577EFA877F1854069E05FF1B66DB5AAFF66526DE0949848769A92';
wwv_flow_imp.g_varchar2_table(65) := '4C0051F0087555A525241892377FF6294A655BC0E2DB6F4681E90DBAD0C41CAFBD81D6C3471AC7AA8C50CD64D5FDF7D47AE7C0EBF5D574F10D40B4BBF81AB235505E81ED6BC36F1AB696587A8568E8704E6F01024C002D00AFB153334D230257CAC6C085';
wwv_flow_imp.g_varchar2_table(66) := '0FDD8752539FB6313187ECE76F4C4EB4F619EF1CAC5F6B64919C9A8A01175D0C555D7C46C67522BB57E71B777FDA95956CCFE8CA9477BC0726802879382DC1877611BAF03CF24E36E8BF6E421FBB26E6908F24FB3F9A556FD41EEAE2EB77F125486C9D16';
wwv_flow_imp.g_varchar2_table(67) := '25444E4E6C69F12114ECDC611CDC5E6298626A54357670C4120498002C8131B2909C9464F8E4056FDE3B7CC244648CFA1550271D0A7EF4CEC1A6679FC48A3FBF85A024825096528F1E0306D474F1F94249B6FD93FD8EDB96857B201284071D2586B6E963';
wwv_flow_imp.g_varchar2_table(68) := '71C64E14C7041045AFD0736B4E4A4AAD1C8E9B46F2A9B523CA1BFA3B07DB177E67E4445D7CFDCFBF1019BD7A1B6976460E6CDD8C63478F1A2AE4A42683303412386239024C0096435A5B20BD189466AAC2AE9CF2262A366EA87D5094B7423305D579E7C0';
wwv_flow_imp.g_varchar2_table(69) := 'CE2EBE48E6961E3C886DF9B51BFEB8E53F1252D6A63101588B6744695DD252E141752B3655BD973EF11882470E473CD6D2C440007BDE793B345390BF323CAA4E679BBBF8EADA587EF808D62E5C80603010DA455875494D09C5F95F7411F044573C4B2704';
wwv_flow_imp.g_varchar2_table(70) := '123D1E74952420684386E3870E62E5230F2078CC9A5183A4C87A0B8DDAB3E691FBB176E607C63EAFA7BA8BAF537FFBBAF80C656A229525C7B0865E96F2FB432984D1A9AD539120310B25C4C93FA79AC104A0C833A72426D42281035B3663E583F7468504';
wwv_flow_imp.g_varchar2_table(71) := 'F4517BF6AE5C6158974C5D7C17DBDFC56728242355A5A558F3ED3746971F5DFC44946D64BFBFDCCD8B020498001480AC6741CFB49D4C55DB689040F13F3FC382BBEF8079D49E0E1D3BC2095D7C3A0EB4F69757609DBCF8CD23FE7696D81046B49F831A04';
wwv_flow_imp.g_varchar2_table(72) := '9800D4E06CE442FDDAD9C9C9C63691C08A07EE09BD266C243623A2555561EB4BCF63E9A497110C5457A7494C0F59DDEF396C383CA686484AB733D0C5BF61C1B7289335005D8F8E129348EF4DE8FB791D1D049800A2836BA352E9CDB60CD39B8234C9C7E2';
wwv_flow_imp.g_varchar2_table(73) := 'DB6F46857C2C68F4C406768646EDB9F3766C99FBA5710475F1F53BEF0264C8063F23D1019132D9E097FFD55C98BBFBE8ADC9CC387EDBCF01B037A802134083D0447707BD2464BEE3951E2AC6C2BB7E8F92EF173629E3D295CBB168DCCDB546EDD1BBF852';
wwv_flow_imp.g_varchar2_table(74) := '3BB46F92AC681F7C64EF5EAC9EFF35CCD57EAA11F1CB3ED146BE61F94C000D6313F53DD4D59565AA0904FC5558FCD4E3D837F55D407F53AF212DE4FEC20FA681BE31A830CD42D4A5576F9C1EE5813A1B52A9C1740DD8B7762DD62FFEDEE8EAA363A92644';
wwv_flow_imp.g_varchar2_table(75) := 'CFFD14E7600F024C00F6E06EE49A9D928C53D35221E49F9EB8FAFD69D82089402B0FF7DDEBFB68ADCF14B4EA6F61A2D0BBF872060C003C820E734408FA03D8222FFC9DA661D285B4956C36B785384259172AC104E000A753CB77AF36AD619E5A6CE7E245';
wwv_flow_imp.g_varchar2_table(76) := '5876D738D04CC0661569D49EBA3305253BB08B8F74F6979563DDFC7938601A1E9D6C245BC9663A26DE83D3ED6302708887527C5E9C764A6B247B4DA30AEFD88EEFE5F37DF9C6F5212DF5517B8E9A660A7262171F295B5A7C08F95FFDAB56631FD9463692';
wwv_flow_imp.g_varchar2_table(77) := 'AD740C07FB116002B0DF078606F4F65BDDBB63794909BEBB731C363C3DBEF64C41F4151F75F10D7556171FE4EFD0CE5DC8FF4636F655866735A23B3ED94636CA43787108024C000E7184AE86475ED8FAF3B1D013E57AE7A205F27FF5929898887EB2A12F';
wwv_flow_imp.g_varchar2_table(78) := 'D4C5673EA87AB77DFF6563DFDED5ABB171C98F462326A947CFFA6413D9669F729C732404980022A1E280346A21A78B26922A3F9317BFD3BAF8827E3F36CB2ECC5DA62F1D3DA1C6BE34902D91EC88F7B458B0CF130B4ABA55C753E49DFEB4366DEA7D18B3';
wwv_flow_imp.g_varchar2_table(79) := '5ED606CA8F84BF9BB71B9FAAD232AC99370F070B0A0C55A8AADF5BB669D037104622471C87001380E35C525BA1646A1C942490627A95B7A2AC0CABBF9E8712D30557FB2C755BC70F1CC4EA7973517AACC4C8947425E26A656AD0347672C45108300138CA';
wwv_flow_imp.g_varchar2_table(80) := '1D9195F17904A8018D1AD2F42302C100D62D5A88FD1B37EA49CAD707B76D037DCA5B19A1B18F7456AE1067D8640498009A0C993D2750631AB509D0473314272D649B1BB6AECEC7F69F7E8216A42D4A8D7ED064563B972FC7E6E5CBA0D186CC927422DD48';
wwv_flow_imp.g_varchar2_table(81) := '478ACB24572FB1623C1340AC78AA464FFA68A65BEB3478646F414D120A77EDC4866FBF41A0B27A1E3D3D3D1AEB405515362DF80EFBB66D35C4D3B87DA413E96624722426106002880937D5569206CCE8DDA63568A4217DCF91E283B2216E2E2A4AC2CFE2';
wwv_flow_imp.g_varchar2_table(82) := 'FA3EABD695C78EC93CBEC2A1FD458648D28174219D8C448EC40C024C0031E3AADA8A5203DB69A7B4014D9AA9EF292B2D45BE6C1CA45975F534ABD6C7F71F40FEBCAF5066FAF088F2261D92B8B1CF2A9895CB6102500EB9751952D5BBA7AC09B495DD85BA';
wwv_flow_imp.g_varchar2_table(83) := 'D480EC8F5F2BABE807366FD6935ABCA6414BD62CF8167E295B17467952DEA4839EC6EB6A0462E93F13402C792BAB730315000009294944415482AED4E046E3E8D1FC0314A743641B1DB6AC5A891D4B96188D7494DED4400D8B2463CBCA95861CCA83F2A2';
wwv_flow_imp.g_varchar2_table(84) := '3C29DE54997CBCB310600270963F9AAD4D46AB2474978D83E63B324DB1458D8334EC765305D339742EC9D0CF25D99407E5A5A7F13AB6116002886DFFD5D29E66D1EDDDA64DEDC6C18307B16ADE5CEC5CB614FE06C617300BA163762C5D1A3A871A16F57D';
wwv_flow_imp.g_varchar2_table(85) := 'D58D7D6D4079E869BC8E7D04980062DF87B52C48F27A400D7369A6A1B5E99160DFF6ED58F1C517A17706F66FDA046A280C5454C25F51118AD30B45F43E011D53B0633BE81C5D305DF4249364EB69BC8E8C40ACA53201C49AC74E425FAAAAF7948F0334EE';
wwv_flow_imp.g_varchar2_table(86) := 'A08030CE0804FCA17706B6E6AFC21AD950B8E4B34FB1F4B37F84E25B57E787F6D131FA091E792EC9E82165914C3D9DD7F18380277E4C614BEA2240230FF739A535CC838FD63DA6A16D1AAC9306EF20190D1DC3E9B18F001340ECFBB0510B92641F3D0D3E';
wwv_flow_imp.g_varchar2_table(87) := 'DA37FD14744A4969F4199EAAFA744CDFF474D0609D746EA3C27967CC23E089790BD8809342C0E7F1A083EC29A0EAFCC0766D718624046A30A440714AA37D740C7FC8735290D63B28161394104082402016C189679D132421D0D87C14281ECFB6C6A26D5E';
wwv_flow_imp.g_varchar2_table(88) := '4F62783CB5281AA08400824C005174218B8E47048215154A6E9A6A08409131F15810D82677221084164704A0C818771615B6DA090858AD43A2CFEBB75A6624794A6A00AA8C896420A73102B1884040C4510DC0E70B96C5A213586746C02E0492BC5AFC34';
wwv_flow_imp.g_varchar2_table(89) := '02A61F4F28B50B48CE9711884504545D334A1E01C4CC999510A8884547B0CE8CC08910B07CBFBC5642D78CE582EB0B544200A16C3584078D0F25F03F468011888880C26B451D01800920A2B3399111A8838026B01D8A7E4C008A80E66C1881934640D394';
wwv_flow_imp.g_varchar2_table(90) := 'D596D5118040F51CD7278D021FC808381F816868288488BF1A8016C40AF08F1160044E8880CA6B45590DC0A7694C0027743D1FC008002AAF158F2AC0DBF7E94F93D80555E5C7F93002318A4069CDB5A2447D650420C68FA78B7F9312AB38134640010251';
wwv_flow_imp.g_varchar2_table(91) := 'CA22BFE65A8992F8DA6295110065AB41E3C70002820323D030024AAF11A5042080F9E01F23C008348280DA9BA45202F041FB87B45C938117468011A88F80E60924FC6FFDE4E8A5282580F6D3E7EC06C42AF08F11887104A2A3BE5895F1C1077BA3233BB2';
wwv_flow_imp.g_varchar2_table(92) := '54A504105241689F87D6FC8F1160046A2360C3B5A19C0064570013406DB7F31623104240D3821F87220AFF292780EC94760BA57D3B64E085116004C208ECCCDA53BC24BCA926A69C00C4942955107817FC6304621481A8A82DF08E983F5FC9388066FD95';
wwv_flow_imp.g_varchar2_table(93) := '1300651E0806DF916BEE0D9020F0C2084804FC7E21FE2AD7CA175B082067C61CF90820BE546E2D67C808381381CF3A4D9DB9D30ED56C2100323428B409B4E6C008B81D81A0C02BB0E9671B01749C366B3E20BE00FF18811842C07A55C517D5D782F5924F';
wwv_flow_imp.g_varchar2_table(94) := '46A26D0410524EF8EF0FADF91F23E052046443D81FED34DD5602C89AF6D14A69FC2732F0C208B811814FB2A7CFCCB7D3705B09800C1742DC2BD7C764E08511701302C7E1F7DE63B7C1B61340E6B4999B6535E851BB81E0FC1981132160ED7EEDDEAC0F3F';
wwv_flow_imp.g_varchar2_table(95) := 'DC62ADCCA64BB39D0048E5AC4A3109020B28CE8111887F04C4C2ACE9B3DF72829D8E20003173664040DC2801E1470109022F718D80ACFA7B7EE3140B1D410004063D0A406837C87850065E1881784440966D719D13AAFE3AB88E210052286BDAECD9B226';
wwv_flow_imp.g_varchar2_table(96) := 'F030C53930024E42C00A5D34E09EACE9333FB2429655321C45006454E6F49913340DF4AD006D726004E20201A169AF664F9F65DB1B7F0D81E838022045B3D2DADD0C0DFFA2380746200E10F828E3B4FE773BD10E4712007D321C48ABB852023647065E18';
wwv_flow_imp.g_varchar2_table(97) := '815846E093406AC55895437D37052C471200199033E5D3D2CCE9B3460BE069DAE6C008D8854073F395CFFCFF23CBF05554969B2B23DAE7399600C87079F16B12C0472140DD26014AE3C008C4000295D030563EF33F4465D8C9FA3A9A0074E0B2A6CDFA9B';
wwv_flow_imp.g_varchar2_table(98) := 'E6D146C8ED0D32F0C2083819817C8F2CAB5933664D77B292BA6E314100A46CF6D4D93F9426A40D92B58127E476950CBC30024E42A04ADEF59FCA4C6D373863EA6CE563FB35178898210032B0FBBBEF96CBDAC0788FD7DB4F08F129A5716004A289C049C8';
wwv_flow_imp.g_varchar2_table(99) := '968FFA9825CBE319F2AEFF1835609FC4398E3924A60840472DE36F1F6ECC9C36F3722038121034CA30F8C708A846403EDFCF17016D70D6F459B9B23C6E569DBF15F9C52401E886674D9FB3306BFACC911A82C3006DAA7C3CA8D0F7F19A11880A020215B2';
wwv_flow_imp.g_varchar2_table(100) := '9CC9E7FBE0C8CCE9B32ECCFC60F6F2A8E4A348684C13808E51F6F4398BB3A6CFBE3E1048E82C9FC3FE08A1D9FE99A5AE1BAFE30681ADD292FB03B28CC9C7D0B159F2E623B7637E890B02D0BD90F3FEFB07E473D8C4AC69B37B41D32E93E9933568BBE49A';
wwv_flow_imp.g_varchar2_table(101) := '1746A0C90884CA8ED0DE841097664D9FD55386E7A98C355990834F882B0230E39C3563F617D261B7674F9FDD15223048D3F02820BE05705C065E18814808C8B221CB88C06342136752D9913793DBB2A6CD8CDBD7D2E39600CCDEA5B107B367CC7A5AB617';
wwv_flow_imp.g_varchar2_table(102) := '9C2F49214DD60E7ACA478551B2DDE049791C8D49B842AE95CECA2AF3E3C53E04C8D7E473E97BEDC95059F07B7B51D908959169B39ECA9C3193F6DBA7A1A29C5D410075B194B583AD593366CDC99A3EFBF1ACE9B3AE94E14C193AC92032DB1D6F9598E06F';
wwv_flow_imp.g_varchar2_table(103) := '2B1244475FA2AF6B9247F4109A765A10A22F82DA408F080EF6686208070762207D433E225F91CFC877E443F225F9947C4B3E96817C4D3E97BE976580CA820386E7AA5B4E556CBB92001A03564CFA6745DB773F3E9CF9EECC82F6EF7CB02B7DEACC6D9933';
wwv_flow_imp.g_varchar2_table(104) := '666FEA387DE6DAACF767AFCA98366759C68C994B39381003E91BF211F92A53FA8C7C473E245F924FC9B78DF9DEBCCF2D712600B7789AED64042220C0041001144E6204DC820013805B3CCD7632021110600288000A27B91B013759CF04E0266FB3AD8C40';
wwv_flow_imp.g_varchar2_table(105) := '1D049800EA00C29B8C809B1060027093B7D95646A00E024C007500E14D7723E036EB9900DCE671B697113021C004600283A38C80DB106002709BC7D95E46C084001380090C8EBA1B01375ACF04E046AFB3CD8C400D024C003540F08A117023024C006EF4';
wwv_flow_imp.g_varchar2_table(106) := '3ADBCC08D420C004500304AFDC8D805BAD670270ABE7D96E464022C0042041E08511702B024C006EF53CDBCD08480498002408BCB81B01375BCF04E066EFB3EDAE478009C0F54580017033024C006EF63EDBEE7A0498005C5F04DC0D80DBADFF3F000000';
wwv_flow_imp.g_varchar2_table(107) := 'FFFFA3BC1A11000000064944415403009D123C0095195CF60000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10565337887533328)
,p_file_name=>'icons/app-icon-256-rounded.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
prompt --application/shared_components/files/icons_app_icon_512_png
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000200000002000806000000F478D4FA00001000494441547801EC9D076054C7B9B6DF2DD2AA4B4802D1248A44EF1DDC4BDA4D6E72931BA7FD29F7A6C78E1DF78229A6830177276E499C384EE238769A93F826';
wwv_flow_imp.g_varchar2_table(2) := 'B18D311D2410025524211042420DF5B6ED9F91632309EDEEACB4F59C77D1A273CE7C33F37DCFACF6BC6766CE1CE385AFDEE4E49B0CF819E067809F017E06F819D0D767C008BE488004488004488004744600A000D05D93336012200112200112A000E067';
wwv_flow_imp.g_varchar2_table(3) := '800448800448800474474006CC1E0049816F12200112200112D019010A009D3538C3250112200112D03B81F7E3A700789F03FF27011220011220015D11A000D055733358122001122001BD13F8207E0A800F48F03709900009900009E8880005808E1A9B';
wwv_flow_imp.g_varchar2_table(4) := 'A1920009900009E89DC0A5F829002EB1E01609900009900009E8860005806E9A9A81920009900009E89D40DFF82900FAD2E03609900009900009E8840005804E1A9A61920009900009E89D40FFF82900FAF3E01E09900009900009E8820005802E9A9941';
wwv_flow_imp.g_varchar2_table(5) := '920009900009E89DC0C0F829000612E13E09900009900009E8800005800E1A9921920009900009E89DC0E5F153005CCE84474880044880044840F304280034DFC40C90044880044840EF04068B9F0260302A3C46022440022440021A274001A0F1066678';
wwv_flow_imp.g_varchar2_table(6) := '2440022440027A273078FC14008373E15112200112200112D034010A004D372F83230112200112D03B0157F15300B822C3E324400224400224A0610214001A6E5C86460224400224A07702AEE3A70070CD862924400224400224A0590214009A6D5A0646';
wwv_flow_imp.g_varchar2_table(7) := '0224400224A07702EEE2A7007047876924400224400224A0510214001A6D5886450224400224A07702EEE3A70070CF87A924400224400224A0490214009A6C5606450224400224A077029EE2A700F04488E924400224400224A0410214001A6C54864402';
wwv_flow_imp.g_varchar2_table(8) := '24400224A077029EE3A700F0CC881624400224400224A0390214009A6B5206440224400224A077022AF15300A850A20D09900009900009688C000580C61A94E1900009900009E89D805AFC14006A9C6845022440022440029A224001A0A9E66430244002';
wwv_flow_imp.g_varchar2_table(9) := '2440027A27A01A3F05802A29DA91000990000990808608500068A831190A099000099080DE09A8C74F01A0CE8A9624400224400224A0190214009A694A06420224400224A07702DEC44F01E00D2DDA92000990000990804608500068A421190609900009';
wwv_flow_imp.g_varchar2_table(10) := '9080DE0978173F058077BC684D022440022440029A204001A0896664102440022440027A27E06DFC1400DE12A33D099000099000096880000580061A9121900009900009E89D80F7F1530078CF8C394880044880044820EC095000847D13320012200112';
wwv_flow_imp.g_varchar2_table(11) := '2001BD13184AFC140043A1C63C2440022440022410E6042800C2BC01E93E099000099080DE090C2D7E0A80A171632E12200112200112086B02140061DD7C749E044880044840EF04861A3F05C050C9311F099000099000098431010A80306E3CBA4E0224';
wwv_flow_imp.g_varchar2_table(12) := '400224A07702438F9F0260E8EC989304488004488004C296000540D8361D1D270112200112D03B81E1C44F01301C7ACC4B02244002244002614A8002204C1B8E6E930009900009E89DC0F0E2A700181E3FE62601122001122081B02440011096CD46A749';
wwv_flow_imp.g_varchar2_table(13) := '8004488004F44E60B8F153000C9720F393000990000990401812A00008C346A3CB2440022440027A2730FCF8290086CF90259000099000099040D811A00008BB26A3C32440022440027A27E08BF829007C41916590000990000990409811A00008B306A3';
wwv_flow_imp.g_varchar2_table(14) := 'BB2440022440027A27E09BF829007CC391A590000990000990405811A00008ABE6A2B32440022440027A27E0ABF829007C4592E590000990000990401811A00008A3C6A2AB2440022440027A27E0BBF829007CC792259100099000099040D810A000089B';
wwv_flow_imp.g_varchar2_table(15) := 'A6A2A32440022440027A27E0CBF829007C49936591000990000990409810A000089386A29B2440022440027A27E0DBF829007CCB93A591000990000990405810A000088B66A2932440022440027A27E0EBF829007C4D94E591000990000990401810A000';
wwv_flow_imp.g_varchar2_table(16) := '088346A28B2440022440027A27E0FBF829007CCF94259200099000099040C813A00008F926A2832440022440027A27E08FF82900FC41956592000990000990408813A00008F106A27B2440022440027A27E09FF82900FCC395A592000990000990404813';
wwv_flow_imp.g_varchar2_table(17) := 'A00008E9E6A1732440022440027A27E0AFF82900FC4596E592000990000990400813A00008E1C6A16B2440022440027A27E0BFF82900FCC796259300099000099040C812A00008D9A6A1632440022440027A27E0CFF82900FC4997659300099000099040';
wwv_flow_imp.g_varchar2_table(18) := '8812A00008D186A15B2440022440027A27E0DFF82900FCCB97A593000990000990404812A00008C966A1532440022440027A27E0EFF82900FC4D98E593000990000990400812A00008C146A14B2440022440027A27E0FFF82900FCCF9835900009900009';
wwv_flow_imp.g_varchar2_table(19) := '9040C811A00008B926A1432440022440027A271088F829000241997590000990000990408811A00008B106A13B2440022440027A271098F8290002C399B590000990000990404811A00008A9E6A0332440022440027A2710A8F8290002459AF590000990';
wwv_flow_imp.g_varchar2_table(20) := '000990400811A00008A1C6A02B2440022440027A2710B8F8290002C79A359100099000099040C810A0000899A6A0232440022440027A2710C8F8290002499B7591000990000990408810A000089186A01B2440022440027A2710D8F8290002CB9BB59100';
wwv_flow_imp.g_varchar2_table(21) := '0990000990404810A000088966A0132440022440027A2710E8F82900024D9CF591000990000990400810A000088146A00B2440022440027A2710F8F8290002CF9C359200099000099040D009500004BD09E800099000099080DE0904237E0A806050679D';
wwv_flow_imp.g_varchar2_table(22) := '244002244002241064021400416E00564F0224400224A07702C1899F022038DC592B09900009900009049500054050F1B372122001122001BD130856FC1400C122CF7A49800448800448208804280082089F55930009900009E89D40F0E2A700081E7BD6';
wwv_flow_imp.g_varchar2_table(23) := '4C02244002244002412340011034F4AC98044880044840EF0482193F054030E9B36E122001122001120812010A80208167B52440022440027A2710DCF8290082CB9FB593000990000990405008500004053B2B75389DE8B4DBD16AB5A2A5C78A66BEC940';
wwv_flow_imp.g_varchar2_table(24) := '679F01F9D9EF167F03FC36D02F8160474E0110EC16D049FD568703ED361BEABBBA51D9DE818AB676548A77557B27CEB4B78BFD36BEDBC8A042070CCE88CF7D754727E467BF426C97B7B689ED8EDEBF0DF93762733875F2ADC030834D800220D82DA0F1FA';
wwv_flow_imp.g_varchar2_table(25) := '6DE24AFF9C38E1173635A3B4A515551D1D68ECEEEEBDF2973D00DD0E3B646F80C631303C12F89080134EC8CFBD7C77891E00D913502FFE26E4DF86FC1B296A6E8614C9FCBBF810994637821F160540F0DB40B31EC86EFD53CD2D68105F6EBCA6D16C3333';
wwv_flow_imp.g_varchar2_table(26) := '301F13B00BD12C4572594B1B3A44AF998F8B677124F021010A800F5170C397046A3BBB705674EDF788AE7F5F96CBB248402F043AEC36C8E101396C4601ADBD560F8588280042A11534E483ECB694DD98D59D9DECDAD750BB3294E01090BD017268A04C0C';
wwv_flow_imp.g_varchar2_table(27) := '9FC97934C1F182B56A95000580565B3648719DEFE8EC9DEC17A4EA592D096892809C1C58D5DE0129083419A0EE820A8D80290042A31D34E1458DB8EA97E3FD9A0886419040881168B65A7B27D086985B74278C0950008471E38592EB6DE2CBE98218F7F7';
wwv_flow_imp.g_varchar2_table(28) := 'D627A3D90C534404DFE1CEC062F1B6E93FB43788ADDEB7C10083415F6F11BA573F755DDD9C18E815B1D0340E15AF280042A525C2D80F79DF728DE2C9DF12178789D3A663C655D760F60D1FC1ECEB6FC4ACEB6EE03B9C185C7F0366DFF811CCF9F87F60E6';
wwv_flow_imp.g_varchar2_table(29) := '8D1F45E6B2E5484949F5FA136C16E26FEE776FC60DAFFE09D7FFF6755CFFEB5775F5BEEEA55770EDF32F62C93D0F60DA273E89A4A828183C5094F300AADA3BC149811E4031598900058012261AB92370A1ABD3E3B8BFC168C4F8E93330EBAAAB91366B16';
wwv_flow_imp.g_varchar2_table(30) := '12468D446C5222A2E3E3F80E370642C445C5C4C0121981E89868449823D0DADAE2EE2372595AD2B8F158F6E05AA47DEEF3308AF24C898930258DD0D5DB9C9282C8F1E948124238FDE6DB307FE7E398F3C94F418AE4CB80F53920EF0E9077D9F439C4CDB0';
wwv_flow_imp.g_varchar2_table(31) := '22103ACE5200844E5B84A5277252925CCAD79DF346931993975F81B1336622429C38DCD9322D7C0838C565E8C5D3A751B6770F3A5B5B951D9F74E5D558B06E2362C467423993C60D0D111188989C85B41FDE814577DD8788A868B7115FECE9019711768B';
wwv_flow_imp.g_varchar2_table(32) := '88890A0428001420D1C4350139F62FBB255D5B006366CE44EAE83488E15D77664C0B23024EAB15B5C78FA134F718BA6C5625CF0D2613667DE1CBC8BCEF4198C7A52BE5D19D91F8238915C268E64D5F147F2F0697E1F7D8ED68116DE0D28009214B20941C';
wwv_flow_imp.g_varchar2_table(33) := 'A30008A5D608435FBAED0EB7E39196E818A44D98108691D1655704ACED1D283B780015E5E570CA6E0057867D8E47899E9F2B366EC3D86F7E07F26AB74F1237072190FAA9CF2079D2E44152DE3F243A5F60E53303DE87C1FF874C800260C8E898512EFAD3';
wwv_flow_imp.g_varchar2_table(34) := 'ED61A5BFB48C0C4444461296460874D7D4A078F72E34D4D52947346ACE5C2C7BF429C4CC5FA09C47EF86C6C4448C14DCDC7190BD00EED299168A0442CB270A80D06A8FB0F2460A801ED103E0CA69A3C98484941457C93C1E46049C363B1A4B4B71F2D041';
wwv_flow_imp.g_varchar2_table(35) := 'B4777529792EBBFCA77EFC9398B3722D2233D80BA404AD8F51C2D4697DF62EDFE432DB9733E111EF08500078C78BD67D08D8453F648FC3DEE748FF4D73442422E3E2FB1FE45ED811B07575A32A2F17657979B089B1679500A2E2E2B0E0BB3FC0845B6F87';
wwv_flow_imp.g_varchar2_table(36) := '312949250B6D061068ABAB1D70A4FFAE9C80DBFF08F7429D40A8F94701106A2D1246FEC81E009B9B3160738419A6612C1013462834EB6ACFC58B28DBB31B55151570B89DED710941C2C85158BC7603523EF339C064BA94C02D65028D6FFC09452FFDC2AD';
wwv_flow_imp.g_varchar2_table(37) := 'BDD0DF8A2DE2B61826EA980005808E1B7FB8A13B3D7CFD180CE2CBDF60186E35CC1F0C02E2ECD27CE62CF2F7ED439317B7F8652C5B81254FFC04D1B3E706C3EBB0AFD3D1DC8CB2873723E799A7E1F030BF4606AB3A0953DAF21D6C02A1573F0540E8B589';
wwv_flow_imp.g_varchar2_table(38) := '763CE2B93F3CDB52F4EAD415E4E3D4D16CF4F4742BC5608A8CC4CCCF7F01531F58C52E7F2562971BF59414A360C35A94EFDE7579E22047F8E73508141EF28A00058057B8684C02DA26606B6B47F9FE7D282F2E527EF25C6C4A2A16DD7C2BC67DEB7B3058';
wwv_flow_imp.g_varchar2_table(39) := 'A2B40DC81FD109C1D5F2EEDBC8DEB40ED585F9FEA881658600815074810220145B853E9140100874D6D5A1F4D041D45DB8A05CFBA869D3B170CD3A247EFC9300877BE0F54B9CFC6B7EF71B1CD9B10DEDF5755E67670612180E010A80E1D0635E12D00201';
wwv_flow_imp.g_varchar2_table(40) := '39DE5F51814271E5DFDCDCA41CD1E41B3F86B9DB1E41D4D4E9CA7968788980BDA11E45ABEEC389975E849C507B29855BDA23109A1151008466BBD02B12080801A7D586CA9C23283E9A03ABE22D7E91313158F8DD1F20F3AE7B4597BF25207E6AAD928EA3';
wwv_flow_imp.g_varchar2_table(41) := 'D9C879F03E54E61ED35A688C278C085000845163D15512F025819ED65694EDDB83F367CF7AB89FE352AD491919587CCF0348F9DC4D60973FBC7F892EFFC63FBF8E9C1D5BD15C79D6FBFCCC11960442D5690A80506D19FA45027E24D051538382DDEFA2A1';
wwv_flow_imp.g_varchar2_table(42) := 'B151B996F4C54B307FE55AC887D52867A2E187049C562BCEFCE449E43CFF2CBA9A9B3F3CCEDD5F70FD00001000494441540D120816010A80609167BD241004024E9B0D8D858528387800DD3D3D4A1E1861E8BDC56FDADA8D88983051290F8DFA137074B4';
wwv_flow_imp.g_varchar2_table(43) := 'E3C4FD77A3E46F6F00A217A07FEAE07B0683E71BFD0CA26D06CFCDA3A14320743D3186AE6BF48C0448C097041CED1DA81263CEA70A0B6057586446D66D898BC7E2FB5762DCB7BF0F83D92C0FF1ED2581B6FD7B71F8E6EFE24251815A4E71E29FFDD56F60';
wwv_flow_imp.g_varchar2_table(44) := 'D6FF7E1B91911E1EA465502B9256243018010A80C1A8F01809688C406743038AF6BE872A31DEAF1A5ADAB41958B67E1312AFBD41350BEDFA10707677E1FC2F7E8A233BB7A1D5C3BAFE1F648B4D49C5B2FB5662CC57BE8694A5CBE034BAFF8AE64A801F90';
wwv_flow_imp.g_varchar2_table(45) := '0BDDDFA1EC99FB4F57287B4EDF4880049408349596A278DF5EB4B6B72BD9435C8166DE702366AE5C0DCB8C596A7968D58F805D9CF04BB76F45C1ABAFC0A6F8F4C4E4CC2C2C5CF51012A4E0321A61B444C1E970F62B973B24E04B021400BEA4C9B2482094';
wwv_flow_imp.g_varchar2_table(46) := '08889347EDC91328C9CB43B718FB5771CD24BAF9E77EF5EB987CE77D308F4A53C9429B0104BA4B4B70ECA155A838B04FF9EE8AF4C54B31FFA14D889A3EE3C3D21C6D6D1F6E73235C0984B6DF1400A1DD3EF48E048644C026AEF64BF7ECC6E99212711252';
wwv_flow_imp.g_varchar2_table(47) := 'BB8A8C4D48C4B2759B90F6FFBE01F0297E43E27EF1EF6FE0F07D77E362C569A5FC26A311F3BFF91D4C5FB711A6D4D47E799C8AEB32F4CBC41D12F08200058017B0684A02214F409CEB3BABAB5124BAFC1BC4B8BFAABF63E62DC0D2479F44ECC2C5AA5968';
wwv_flow_imp.g_varchar2_table(48) := 'D78780A3A519671FDF89A33F790A5D5D9D7D525C6F268C198B651BB660E417BE0C184D83188AC61CE4280F850F8150F7940220D45B88FE91802A01BB030DA5A75078E430DA15BB8F6597FF8C4F7D1A331F5C0BF3D871AA35D1AE0F811E71B55FB065038A';
wwv_flow_imp.g_varchar2_table(49) := 'FFF97F7028DE5D316EC1C2DEF17E0AAE3E20B919700214000147CE0A49C0F704EC3D569CCBC946F98913B02A8EF7478B2EFFF9DFBB19E36FF9118CF1F1BE774A0725B6671FC6B18D0FA13AEFB852B4066135F593FF89E9F73D8888C999628F3FDA2510FA';
wwv_flow_imp.g_varchar2_table(50) := '915100847E1BD14312704BA0A7B11125EFEE42D5B94A38C488BF5BE37F27CAEEE7C56BD621F93FFF0B72D63FF8F29A40DDEF7E8D036B1F444BF579A5BC4631DEBFE8F6BB31E1D63B604C4C52CA432312F027010A007FD265D924E067022D95E77072CF1E';
wwv_flow_imp.g_varchar2_table(51) := 'B4B4B52AD524AF40275D7703963CFE34A266CD015FDE13B0D7D7E1D4FA35C8FDE58B8A720B489D3809576CDB89111FFF0FEF2B648EB024100E4E530084432BD147121840C069B7A32E2F0F25A20BDA6AB70D481D7CD71C158D395FFB1F64DE79AFE8F24F';
wwv_flow_imp.g_varchar2_table(52) := '18DC8847DD12E8CACBC5890D6B5171E8805BBBBE8993AEBD1E73D6AC47F4ECB97D0F739B04824E800220E84D400748C03B02D6E66671023A88F2D253B02BAE2B9F387A0C96DC7117D2FEDFD7618888F0AE425AF712B8F87F7F43F6C35B5027B8F71EF0F0';
wwv_flow_imp.g_varchar2_table(53) := '9FECF29FF395AF61F2ADB7C33C66AC076B266B8B4078444301101EED442F49A09740476D2D4A0F1F426D4D4DEFBECA7FA3A7CFC0BC556B1177CDF52AE6B41940C069B3A2EAE7CFE3E8534FA0F362E380D4C17723456FCB927B5762F4D7FF17C6D8B8C18D';
wwv_flow_imp.g_varchar2_table(54) := '789404824C800220C80DC0EA494095405349090AF6ED454B6BAB6A16647DEC13982DC69E2D995394F3D0F012015BF57914DC77170A5E7B150EA7E352829BADD4C959B8E2F1A79120BAFEDD983149C304C225340A80706929FAA95B020EAB159539392839';
wwv_flow_imp.g_varchar2_table(55) := '7942B9CB3F2A214174F9DF8D4977DC0343A445B7EC8613B87C8A5FCEAAFB71BEA850A91839C172DA7F7E06F3366D4344C604A53C3422816012A00008267DD64D021E0858DBDA512AAEFACF9FA9509E719E3C29138B1F588DA48F71C6B907BC83263B85E0';
wwv_flow_imp.g_varchar2_table(56) := 'AA7BE565E43CBA132D35D583DA0C3C68898BC3829B7F88F4EF7C1FC6A4A481C9DCD71581F0099602207CDA8A9EEA8C40EB9933C87F77172E36AA8D3B4B3C13972EEB1DEF8F9EBF50EEF2ED2501476B0B4E3FB603C75FFA057A3AD41EC69338665CAFE04A';
wwv_flow_imp.g_varchar2_table(57) := 'F9F4E7C0DE162F81D33CA8042800828A9F9593C0E5049C561BEA0B0A50927B0CDD3DDD971B0C72C46C3261F617BF8C296B377249DF41F8A81C924BFAE6DD7F37CADE7D47B9B765FCBCF958B4E351C4F0190A2A887561134E41520084536BD157CD137074';
wwv_flow_imp.g_varchar2_table(58) := '75E14CCE11948971679BDDAE14AF25360E4BD6ACC398FFFD0E60E49FB412B401462DFF7C1387EFBF0B75156A4FF193AB27CEFCC297307DFD669892530694C65D12080F02FCB6088F76A2973A20206FF12B78FB6D5C38AFB6B4AC443266F65C2CDFB61371';
wwv_flow_imp.g_varchar2_table(59) := '4B57C85DBEBD24E0686F43D50BCF22FBC74FA253F1EE8A8491A3B0ECDE9518F73FDF6697BF97BCB56F1E5E11520084577BD15B2D127038D15C518153070FA2BDBB4B294283E8F2CFFAC8C73063E51A44666629E5A1517F02B6CAB338F5F01614FCF135D8';
wwv_flow_imp.g_varchar2_table(60) := 'ADD6FE892EF6464E9B8E790FAC42C27537B0B7C505231E0E1F021400E1D356F4548B04EC0E9CCF3D8AA2A339E8B2A99D8422A2A331FF9BDFC1A43BEF8569C4082D52F17B4C5DF927716CFD1A9CCD3EAC5C57E6D5D762CEEA75889A314B390F0DF54520DC';
wwv_flow_imp.g_varchar2_table(61) := 'A2A50008B716A3BF9A2160BB7811657BDF43A5B8FA570D2A212505CBD66D42EA7F7F01721C1A7C794DA0E1F55771E8C17BD174BE4A29AFC968C4A25B6EC364D1DB624A4955CA4323120807021400E1D04AF45173043ACF9D43D1A143A86F68508E2D63F9';
wwv_flow_imp.g_varchar2_table(62) := '1558FCE433889E334F390F0D2F11B03736E0CCA3DB71F4E72FA047B1CB3F313D03CBD76F7EFFB1C9978AE216090C4220FC0E19C3CF657A4C02614CC009D41515A3E0C861B477B42B05126189C29C9BBE88A9F7AE145DFEC94A7968D49F407751214E6EDE';
wwv_flow_imp.g_varchar2_table(63) := '8092B7FE09283E402963C59558B0EA21C42C5AD2BF30EE91804608500068A4211946E813B0B777E0DCA183385D701236C59350ACE8725E70CBAD18FDADEFC120C6FE433FCAD0F3B0F5BD777174CB06D416E62B39671056D3FFEBBF31E58E7BB8A4AF60C1';
wwv_flow_imp.g_varchar2_table(64) := '1F3502E1684501108EAD469FC38E40F7C526141FD8872A31EE2C3A0194FC4F9E30118BD76D44E2473FA1644FA3010484C8AA79F99738B46D13DAEAEB06240EBE1B1111812577DE8BF4EFDF02637CFCE0463C4A021A214001A091866418A14BA0B9E20C0A';
wwv_flow_imp.g_varchar2_table(65) := 'DEDB8DD696162527E515E8E4EB6FC4C2479E44249FE2A7C46CA091ADA61AA7D6AFC189DFFC4A7955BF919333B162C76342707D7C6071DC27010F04C2339902203CDB8D5E870101B9A4EF85E3B9283E96831EBB4DC9E388D838CCFFF6F79079F7FD30C4C4';
wwv_flow_imp.g_varchar2_table(66) := '28E5A1517F029D870F224F9CFC2BC4EFFE29AEF726DFF851CC5EB31E96A9D35D1B3185043446800240630DCA70428380B5B51515470EA3A2AC0C4ED115ADE25572460696DE7B3F523FFF4570495F1562036CEC7634FCE135643FBA1D0D672A06240EBE6B';
wwv_flow_imp.g_varchar2_table(67) := '125DFE724D85C9B7DC0673DAE8C18D7894043C1008D7640A80706D39FA1DB2043A6B2EE0D49EF7502BBAA1559D940F9599BB7A1D62B8A4AF2AB27E764E6B0FCE3EF314727FFA1CBA14875AA2E213B0E49E0730F20B5F86219ABD2DFD8072471704280074';
wwv_flow_imp.g_varchar2_table(68) := 'D1CC0C322004EC0E349696E1E481FD68ED525CD2573836F3739FC78C2D3B10313E43ECF1C75B02B6F355C8BBE70E14FFFDAF70288EF88F9E361D2B1E7F1AF1575FEB6D75B427810104C2779702207CDB8E9E871001478F15E7C4787F59DE71389C0E25CF';
wwv_flow_imp.g_varchar2_table(69) := 'A21392B0EC81D518F7DD9BC155FD30A457EBAEB791FDC0DDA83D55A294DF0803A67FE6B398B5612BCC63C62AE5A1110968958051AB81312E120814016B73334ADF7B175515A7A17A059A9A35058B57AF45FC35D705CA4D4DD5E3ECEE46EDAF7E819CA71E';
wwv_flow_imp.g_varchar2_table(70) := '476B7DBD526CD1090998FF835B30FEDBDFE72D7E4AC468A442209C6D2800C2B9F5E87B70093881E6D3A791BF6F2F2E2A8E3B1B0C064CBEF22ACC5DB30151B3E706D7FF30ADDD5E5F87D2471E46DE6F5F86B5AB53298AE4F40C2CBAFF41A47CE673304444';
wwv_flow_imp.g_varchar2_table(71) := '28E5A11109689D000580D65B98F1F98580D3E1405D413E4A7273D1AD38DE6F369B31E76BFF83CC956B611A39D22F7E69BDD0AEE242E48AF1FE8ABDEF298EF603190B1661FEE6ED885EB058EB78185FC0098477851400E1DD7EF43E0804E492BEE5FBF6A1';
wwv_flow_imp.g_varchar2_table(72) := 'BCB8487DBC3F3E1ECBD66F46DA57BEC65BFC86D86617FFFC071C7CE01E34D65E502AC1603008C1F50D4CDBB005A6D454A53C3422013D11A000D0536B33D6E111105DFEEDB57528125DFEF575B5CA65A5CF5F80E58F3C89187125AA9C89861F127088E195';
wwv_flow_imp.g_varchar2_table(73) := 'B34F3F819C179E83558CFD7F98E0662361541A96DEF300467FE5EB80C9E4C6924924307402E19E930220DC5B90FE07868038F9379DA940C9C1FD686B6B55AAD3688EC0B4FFF814A63EF810CCE3D395F2D0A83F016B59294A766C45F1DFDF80D361EF9FE8';
wwv_flow_imp.g_varchar2_table(74) := '626FF4EC3998FFC02A245C7F23207A01C0170990C0A004280006C5C2832470898053DEE2977304C54773D063B35D4A70B3159D908885DFBF1919B7DE01635C9C1B4B26B922D07EF80072D6AF41A560EFCAA6EF7183D899FA918F61D6836B61993E53ECF1';
wwv_flow_imp.g_varchar2_table(75) := '8704FC4920FCCBA60008FF3664047E24606F6A42F9FEBDA83A7B56B9961163C761C9A6AD18F1A9CF8057A018D2EBC2AF5EC4E1F56BD15A5FA794DF6C3462E1777F800977DD0763D208A53C342201BD13A000D0FB2780F1BB24D0515D8DFC7DFB50DFD8E8';
wwv_flow_imp.g_varchar2_table(76) := 'D26660C2C4ABAEC1A2279F81256BEAC024EE2B10B05FA841D9960DC8FBEDAF61537C8642527A06966FD88AE4CFDDA450034D48C03704B4508A510B41300612F02501A7CD8EBAFC7C141E3C88CE6EB5257D23626230EF2B5F45D63D0FF0297E436C8CCEDC';
wwv_flow_imp.g_varchar2_table(77) := 'A3C8DBBC1EE57BDF532AC120ACA4E09ABFEA21442F5C24F6F8430224E00D010A006F68D156F304EC1D1D382F4E44A78B8BC415A8DA92BE09A3C760D16D7762D4D7BF09436424F8F29280B8D26F7AF3AF38F6F016D4979E52CA6C301830435CF167FEE84E';
wwv_flow_imp.g_varchar2_table(78) := '44644C50CA432312F01D016D944401A08D7664143E20D02DBAFA8BF6EEC53931DEEF542C6FF4B41958B87E33E2AFBD5E3107CDFA11B0DB51F5D36791FDD4E3686F6EEA97E46A27CA62C13231D63F4E8CF91BE3E25D99F138099080070214001E00315907';
wwv_flow_imp.g_varchar2_table(79) := '04C4D9BEA9B414F97BF628DFE2678001533FF569CCDEFE2822C418B40E28F93C44EB990A143E70170AFEF8BAF2AA7EA332A760E9CE27107FE3477DEE0F0B240155025AB1A300D04A4B328E2111708AF1FE9ADC6328399107AB5DED163F4B7C2216DD7E27';
wwv_flow_imp.g_varchar2_table(80) := '26DCF223AE2B3F24EA40FB9E77716CC31A9CCBCF572E21F3E3FF81D9EB36C29299A59C8786244002AE095000B866C3148D13B0B677E0F4BE3D3873BA1C4E310EAD126EEAC44958B27215467CFC93801887065F5E11705AADA8FDEDCBC87EE2513457572B';
wwv_flow_imp.g_varchar2_table(81) := 'E58D8C89C1826F7D07937EF0439852B8A4AF12341AF99180768AA600D04E5B32125502A2CBBFF3FC799CDAB31B750D0DAAB990B16809E63CB411D1F3172AE7A1E125028ED6569C797C27F27EF50BF474745C4A70B3159B9C8A45F73C80D49BBE0C8325CA';
wwv_flow_imp.g_varchar2_table(82) := '8D2593488004BC254001E02D31DA873501A7CD868653C5C83F7C18AD8A272183C180D9377DB1F7A132E6B4D1611D7FB09CEF292EC2B1DB6FC1A95D6F2B8FF78F9D3507CB1E7B0A71CBAF0896DBAC97042E23A0A50314005A6A4DC6E29680A3A70767B38F';
wwv_flow_imp.g_varchar2_table(83) := 'A0EC643EEC8AEBCAC7262763F99AF518F3ADEF815DFEF0FE2586565ADE7C03D96B1F44638D5A97BFC960C4CC2FC473A0FB00001000494441547C0933376E8569E448EFEB640E122001250214004A986814EE04ACF5F5287E77176A44D7BF53F11A346DC6';
wwv_flow_imp.g_varchar2_table(84) := '4C2C165DFEBC021D5AEB3B5A5B50FDDC8F91FDCC336817DB2AA54427A760C16DB763DC37BE054314BBFC5598D1269004B455170580B6DA93D10C42A0B5F22C0A0E1E444B5BDB20A9971F321A8D987AE347317BED06444E9976B9018F78246015CC4F6DDF';
wwv_flow_imp.g_varchar2_table(85) := '8AFCBFFC09765B8F477B693032730A16DFFF20467CE25380C9240FF14D0224E0470214007E84CBA2834BC0E970A2EE782E8A8E64A3ABA75BC999C8480BE67EE39BEF3F54263149290F8DFA13E83C7E0C796B56E26CCE11C5BE1660C2B21598B36E23A2E6';
wwv_flow_imp.g_varchar2_table(86) := 'CCEB5F18F74820840868CD150A00ADB528E3E925606B69C5E98307505E560687E269282E7524966DDA8A915FFC0A38DE0FEF5F62BCBFE1955FE3801CEFAFBDA094DF643463C1F76EC654D1DBC25BFC9490D188047C468002C067285950A810E8A8AD45C9';
wwv_flow_imp.g_varchar2_table(87) := 'A183A8539C7426FD9EB87C05963EF614A266CF95BB7C7B49C02E4EF815DBB7E0D84B2FC26EB52AE51E313E1D4B57AD46EA673F0F0A2EF015F204B4E7200580F6DA54BF113981A653A750B86F1F5A15279D19232331F3BF6F42D6FDAB61E2223343FAECF4';
wwv_flow_imp.g_varchar2_table(88) := '1416A0E0E1CD38B57B97625F0B306EF112CC7D6015E2565C35A43A9989044860F804280086CF9025840001477737CE651F46F1893CE5A7F8C5252661D10F6EC5B8EFFC00068B2504A2083F175AF7BC8BA39BD7A346880015EF0DC268FA273F8DE9F73E88';
wwv_flow_imp.g_varchar2_table(89) := 'C8C95CD257E0E04F9810D0A29B14005A6C559DC5646B6BC3E90307505559A91C79F2B8F158B4691B923EF149E53C34EC43C0E1C0855FFE0CD9DB36A3B5B1A14F82EB4DB3D184453FBA13E9B7DE0E637CBC6B43A690000904840005404030B3127F116817';
wwv_flow_imp.g_varchar2_table(90) := '27FDFC77DF45BDE24948FA31E5639FC0C2A79E41241F2A237178FDB69E3D83A2350F20EF77BF15BD2D62DC45A184E4F40CACD8F2F0FBB7F829D8D38404428B8036BD316A332C46A575024EAB0DF5454528397A14AAB7F859626230FFEBFF8B09B7DE0143';
wwv_flow_imp.g_varchar2_table(91) := '54B4D611F925BE8E83FB91B765032A8F1D552A5F76F94FBCEA1ACC5BB31E5173E72BE5A1D1BF09881E937F6FF11709F8850005805FB0B2507F12B07574F69E80CA0AF2D1A3F808DFF8D163B0F0AEFB30F22B5F83C16C065F5E12105DFE175FFB1D721EDD';
wwv_flow_imp.g_varchar2_table(92) := '8E46D103A092DB683261D64D5F42D6ED77C13C3E5D250B6DFA1030984D70287EBEFB64E3A61F0868B5480A00ADB6AC46E3EAACAFC7895DEFA0FA9CFA78FFB839F3B078E356C45DC119E743F95838AD56543EF518727EFE02BADAD456538C8D8DC5D2BBEF';
wwv_flow_imp.g_varchar2_table(93) := 'C3986F7D1786D8B8A154ABFB3CDD4D4D4200D875CF8100FC478002C07F6C59B22F09389C682E2F47E1FE7DE8E9EE522E79EA673E87995BB7C33C6EBC721E1A5E22D073AA180577DD86A27FBCA97C8BDFE8AC2958F2E85388BFEEC64B05714B9D80E86DA9';
wwv_flow_imp.g_varchar2_table(94) := 'FBEDCB38FAD01AF53CB4F42301ED164D01A0DDB6D54E64E20BF1BC5CD237F718AC369B525C51F109587AF7FD98F0FD5B008EA52A31EB6FE444EB5BFF40F686B5385F56DA3FC9D59EC10039C172D6862D8848CF7065C5E36E08D81BEA717ADB26E4BEFC4B';
wwv_flow_imp.g_varchar2_table(95) := 'F4283E43C14D714C2201B7042800DCE26162B009F4886ED0F2BD7B5179BA5CD99591132662C9AAB548BCF1A3E00A73F0FAE5ECEC40CD8B3F45CE8F9F447B83DA2D7E96B8382CF8DF6F63C22D3F82316904F8F29E4077613E4EAE5F83D2BDEF014EB5BB2B';
wwv_flow_imp.g_varchar2_table(96) := 'BCAF8539BC25A0657B0A002DB76E38C726BEFF3ACE55E1D4E143A8ABAF538E2463F112CC1157A09C71AE8CAC9FA15DB03EBDF3619CFCFDEF60ED567B8052C2E83158247A5B52BFF065182223C197F704DADE7B17391BD7A1B6F494F79999830486488002';
wwv_flow_imp.g_varchar2_table(97) := '6088E098CD8F0444977F6D5121F2C5C9BF4D71D299D96CC6BCAF7E03D3D66D8669E4283F3AA7DDA2BBF24F20FBCEDB5076609FF2787FFADC7958BCF371C42E5BA15D30FE8CCC6EC7B91F3F8143DB36A3BDE9A23F6B62D94322A0ED4C1400DA6EDFB08B4E';
wwv_flow_imp.g_varchar2_table(98) := '2EE97BE6C0015414162A3FC52F263109CBD66DC228210060E447DAEB461782ABE90FBFC791B50FA2458C41ABE437194D9879D397306DD3C33025A7A864A1CD0002B67395285E7D3F8AFEF686F2677D4011DC25816111E0B7E5B0F031B32F09585B5A50B2';
wwv_flow_imp.g_varchar2_table(99) := '770F6A2ED4882B50A752D169D36660E9C33B11B370B1923D8DFA13703436A2EAD9A7DEBFC5AFB3B37FA28BBDD894542CBAED768CFBE677B8A6820B469E0E771EDA8F5C31DE7FF678AEF8AC7BB2667AB00868BD5E0A00ADB77098C4D77AE60CF2DFDD85E6';
wwv_flow_imp.g_varchar2_table(100) := 'E666258F4D2633A67DE463982DC6FB2332262AE5A1517F02F216BFE21D5B50F85771052A7A01FAA70EBE377AC64C2CBAFF41247EFC93E0044B78FF129C1B5E7F1587766CC3C5AA73DEE7670E12F021010A001FC26451DE1370F6F4A036F7188A7272D0AD';
wwv_flow_imp.g_varchar2_table(101) := '788B5F746C2C167CF7FBC8B8F35E3E54C67BE4BD39DA0F1FE8BD023DE7C515E8A4ABAEC6AC35EB61993DB7B70CFEE71D016757272A9F7804C77EF63CAC1D1DDE65A675100868BF4A0A00EDB771C846686B6EC1E9234770BABC5C790C3465CC582CDDBC1D';
wwv_flow_imp.g_varchar2_table(102) := '233EF339F00A14DEBFEC7654BFF802F6AF5F8B66D1FDAF5280D964C2826F7D17590F3EC45BFC54800D62D353568A13F7DC81A27FFD43ADCBDF608041F4720D52140F9180CF085000F80C250BF28640477D3D8AF7ED419D18EF57CD37F99A6B31FFF11F23';
wwv_flow_imp.g_varchar2_table(103) := '72EA34D52CB4EB43C07EBE0AA7B76F41FEEF7FA77C9F79D2B8742C59F510526FFA529F92B8E90D811671D2CFDDB00617CACB94B2190C0664CC9E8DF4C54B608441290F8D7C4F400F251AF51024630C220131E6D9AF76BB034D454528D8F31EDABABAFA25';
wwv_flow_imp.g_varchar2_table(104) := 'B9DA315B2C98F3852F21F39E95ECF27705C9C3F1AEDC1C9CDCB619A57B76AB5D818AF2C62F5986F92B57236EF915628F3FDE12707676A2E6A7CF22FB274FA2B9AE4E297B645C1CA65D7D0DC6644D45CAA851309AF815AD048E464322C04FD790B031930A';
wwv_flow_imp.g_varchar2_table(105) := '01A7D3D1EF4AD321C6F8AB8E1F4371413EEC8A2B9D25A68EC4A2DBEEC4E86F7E1730F3297E2ADC07DA34BFF9371C1327FFDAD292814983EE1B0C06CCF8CFCF60DABD0F206272E6A0363CE89E80A3B91925DB36E1E41F5E835D7541A591A33073C515484C';
wwv_flow_imp.g_varchar2_table(106) := '4D85BCF0371A4D42ACB107004179E9A352A33EC26494C1206017E3CD0E71A2773A9CB08AF1FEB2DDEFE25C4585B22BA9132761C196ED48B8E123CA79687889805308AE9A679E42CED38FA3ADA5E552829BAD0821B216FFE82E8C974BFAC6C5BBB164922B';
wwv_flow_imp.g_varchar2_table(107) := '027241A5A3B7DF82B3470E8913B82BABFEC7D384D09A7AE595B0C45F62EEB4DBFA09E8FE39B84702C3274001307C862CC10501ABE802B5355DC4859327902FC6FB1BC555910BD3CB0E4FFFE47F62FEA34F21627CFA65693CE09980F574198A56DD8F136F';
wwv_flow_imp.g_varchar2_table(108) := 'FC59B9B725559C8456EC780C491FFF0FCF15D0E2720262B8ABF18FBFC7A18756E362ED85CBD30739628A8844E6FCF99820DE2663FFAF63299E07C9C2430120A0972AFA7FE2F41235E30C080187F842AC2C2941656929BA15C7FBA3C418E8E2EFDD8CF49B';
wwv_flow_imp.g_varchar2_table(109) := '6F83212A2A207E6AAD92B6DDEFE0D8E6F53877E2B85268B29379D27537608EBCC56FDA0CF0E53D014753132A1FDD8E633FFF197A3ADA950A88898BC3D4A54B2185976C03A54C3422011F12A000F0214C16753981C6FA3AE55BFC12478FC56231EE3CE2B3';
wwv_flow_imp.g_varchar2_table(110) := '9F074C26F0E51D01674F371A5E7919D94F3C86E6F3E795329B2C16CCFECAD79029BAFDCD69A395F2D0A83F016BC569146E7A0845EFBC0587ECB6EF9F3CE8DE88D163304388AE84B4B441D379309804F4533705807EDA3A64233508CFC6CF9D8F45DB7620';
wwv_flow_imp.g_varchar2_table(111) := '7AC972B1C71F6F0938DADB70F6F19D38F6D22F60EDEA54CA1E3F22194BEF5D89D15FFF5FB0B74509D96546ED870FE2C87D77E27C41FE6569831D30886EFE09B3E760CAB2E53047460C66C26324103002C680D5C48A48601002461830F3F35FC08CCDDB60';
wwv_flow_imp.g_varchar2_table(112) := '1AC5ABA14110793CD4535C849377DF8E927777294F3A1B3D6D3A163FF204E2AEB8CA63F934188480CD860BBFF8198E6C5C8776C527569A22233165C9528C9E3A15069371904279281408E8C9077E0AF5D4DA21166B6C4A0A963DB81A63BFF53DC0640E31';
wwv_flow_imp.g_varchar2_table(113) := 'EFC2C01D8703CD7F7F0347D6ADC285B367941C9657A0333EFD59CCDAB00566D10DAD948946FD08D8AACFA364C31AE4BDFA5B5815BBFCE39393314774F98F1837AE5F59DC21816012A00008267D1DD79D96998545ABD721EEAA6B0183017C7947C0D1D68A';
wwv_flow_imp.g_varchar2_table(114) := 'EA9F3D8763CFFD041D8A775744258DC0C2EFDD82F1DFBB19C6F804F0E53D81AEDCA3C8DFBC1E67B28F286536180C18999E81292BAE84252E56290F8D8249405F755300E8ABBD831FADF8429C74D53598BD711B2C9C713EA4F6B0559D43F9230FE3E41F5F';
wwv_flow_imp.g_varchar2_table(115) := '87D56A552A6344C6042CBE6F25923FF3597082A512B2CB8C5AFEF57F38B275236A1597F4359A4CC898390B93162F418425F2B2F2788004824D800220D82DA0A3FA232322B0E07FBE85AC0756C39894A4A3C87D176A87B8F2CCBEEB369C3E7450A95083B0';
wwv_flow_imp.g_varchar2_table(116) := 'CA983B0F0BB6EE40F4FC85628F3FDE12900B2A553EF5188E3CF608BA5A5B95B247C7C563E6D5D760F4B469ECE05222161A467AF3C2A8B780196F7008C4A78CC4D2CD0F23F58B5F018CFCD879DB0AF224D4F09B5FE1C8C6B568553C0999C415E8AC2F7F15';
wwv_flow_imp.g_varchar2_table(117) := 'D3366F876944B2B755D25E10E8910B2A3D70378ADEFC9BF2EDAC23C68CC5B4ABAE46AC18F71745F08704429600BF8943B669B4E358FA824558B2F33144CF9EAB9DA0021889BDAE16679F7C14C77EFD127A14BBFC6385E05AFCA33B31E61BDF04841008A0';
wwv_flow_imp.g_varchar2_table(118) := 'BB9AA9AA7DEF7B38B6691DCE29DEE227031F9B9985294B97C112132D77F90E2B02FA739602407F6D1ED088E578FFB435EB60E2223343E2DE75EC280A37AFC7A9B7FE09A7D3A954C69859B3B1E8810791F0D14F28D9D3A83F01D9DB52FBF22F71E4D11D68';
wwv_flow_imp.g_varchar2_table(119) := 'A9AEEE9FE8622FC212852C71E24F9F370FBCC5CF05241E0E3902140021D724DA7128569CF4277EF33B3044F16A6828ADDAB6EB2DE4AC5F8DEA9262A89DFA81AC1B3F8A99ABD7C3326BCE50AAD47D1E674F0F4E3FBC09C7C5708BEA824AD14923306DF972';
wwv_flow_imp.g_varchar2_table(120) := 'A48C1FAF7B7EE10C408FBE1BF51834630E0C81E8941498C43B30B569A716A7B507E79F790A07773C8C0E71425289CC6C3062D12DB761D2DDF7C39898A892853603087417E6E3F86D3F40D9BEBD03525CEFA6A56760E6955721969F73D7909812B2042800';
wwv_flow_imp.g_varchar2_table(121) := '42B669C2DF3183D104881313F8522660AB3C8B72D1E55FF0C69FC555BFDA757FD2B87158BA7E1392FFF3BFC0D7100888A195A6BFFD054737AE439DE0AF5282D168C4A4F90B3061F16298798B9F0AB210B7D1A77B1400FA6C77461D82043A0F1FC4896D9B';
wwv_flow_imp.g_varchar2_table(122) := '507EF89038F9AB3998B16419E6AF5A87D8C54BD532D0AA1F01474B33AA9E791A39CF3F83B6A68BFDD25CED44C6C460FA555763D4E4C930180CAECC789C04429E000540C837111DD43C01870317FFF43A8EEDD88AFAD3E54AE19A44EFCAACCF7C1653EE5B';
wwv_flow_imp.g_varchar2_table(123) := '8988899394F2D0A83F01B9A46FD1960D28FCEB9FE150BCBB2221391933AFBD0EF1A9A9FD0BE35E5813D0ABF314007A6D79C61D12049C5D5DA87A62278E3EFF2CDADBDB957CB2444561D11D7763EC0F6E8531364E290F8DFA13E838B81FD9B7DF8AAABCE3';
wwv_flow_imp.g_varchar2_table(124) := '6ABD2DE24A3F6DD2E4DEFBFB2DD19CD4DA9F26F7C295000540B8B61CFD0E7B023D052771F2BE3B50F0AF7F2A2F32939635052B1E7D6A6EC9F6000010004944415412891FF958D8C71F8C009C361B6A7FF9731CDABA11AD6D2D4A2E44582CC89C331713E6';
wwv_flow_imp.g_varchar2_table(125) := 'CF87D16C56CA43A37022A05F5F2900F4DBF68C3C580444977FEB3FDEC4B1AD9B50535AAAE485C160C0E46BAFC7AC87368A2EFFC94A7968D49F80BDF6022A1EDED4FB143F9B62977F4C7C3CA62E5F81D4AC2C8EF7F7C7C93D0D10A000D040233284F021E0';
wwv_flow_imp.g_varchar2_table(126) := 'ECEC40ED4B3F47F6334FA1A5A15EC971735434E67EE56B987CC73D30A570EC5909DA00A36ED1DB7262E34328DDB7577941A5E4F1E99871DDF588E32D7E03686A6B57CFD15000E8B9F5197B4009D8EBEB717AFB567105FA0A6C8AF7F7278D4AC3D27BEEC7';
wwv_flow_imp.g_varchar2_table(127) := 'A8AFFD0F0CA22B3AA00E6BA4B296DDBB70F8C1FB5157A6D8DB22E2CE983E03990B17C11C1121F6F84302DA2460D466588C8A04428B4057F621E4DD752BCA0E1D509B7426DC1F3B733616EE7C1CB1575C25F6F8E32D01674F37CE3FF908B2B76F4197D856';
wwv_flow_imp.g_varchar2_table(128) := 'C96F8A88C4D42BAFC6989933C578BF49250B6DC29A80BE9D37EA3B7C464F02FE2520279D5D7CED773822C6FBEB450F804A6D729199999FFE2C666EDA0653EA48952CB41940C05A711A450FAD42FEFFBD09BB536D41A5C451A330FB9A6B9094360A7C9180';
wwv_flow_imp.g_varchar2_table(129) := '1E085000E8A19519635008D8EBEB50F5E32770FC173F475767A7920FD1234660C1F76FC1B81FFC1086A828A53C34EA4FA063FF5E9CD8B201E78EE7F64F70B16730183072E224642E5E8AA8442EA3EC0293260FEB3D280A00BD7F0218BF5F0858CB4EA164';
wwv_flow_imp.g_varchar2_table(130) := 'DB2614FEE34D581D76A53A52266762F1BD2B912CAEFE214E4A4A9968748980B8D26FF8C3EF7178E736349CABBC74DCCD96EC6D99387F01262F5C8888288B1B4B269180F608500068AF4D19519009B4EF7D0FD90FDC837305F94A9EC8C564272F5D86F99B';
wwv_flow_imp.g_varchar2_table(131) := '1F46D4FC854A7968D49F80A3A31D659BD621F7A7CFC3DAD5D53FD1C55E745C3C665C732D464D9AE4C28287B54D80D15100F03340023E22E0ECEE46FDCF9FC7916D9BD1A6B8AA9FD96CC6DCAFFF0F32D76D863131C9479EE8AB98EEC20214DC7F37CA0FEC';
wwv_flow_imp.g_varchar2_table(132) := '535E502971E4284CBDF22AC42527EB0B16A325813E042800FAC0E026090C9580EDEC199CDEBE05B9AFFD5EB9CB3F61F4182C115DFEA3BEF2F5A156ABEF7CA2CBBFE9EF6F207BD37A542BDEE227818D9F31439CFCAF44546C8CDCE55BA70418364001C04F';
wwv_flow_imp.g_varchar2_table(133) := 'C190091820FFB9CEEEB4DB00A7C3B58146523A8F66A370C7D6DE2B50A7E24D7E63E72DC082956B1077F5B51AA110D8309C9D9DA87EE1191C7DF627E8B8D8A054B97C8A5FE6A2C518377D26E4D8BF52A6201B3985C871E782C1607097CC3412704B8002C0';
wwv_flow_imp.g_varchar2_table(134) := '2D1E26BA2320BF7BDC7DFDD8AD5638BB7BDC1511F669ADFFF83B8E6ED9881A7105EA548C26EB231FC38C550F2172CA54C51C34EB4BC0D1D88092AD1B70F24F7F80DD66ED9BE4723B266904A62D5986D4091320742BC2E2E5E9E42F0271F7F717163106CD';
wwv_flow_imp.g_varchar2_table(135) := '49562C0918E57F7C93C05008C82F1F83F8127295D7D16385F5DC5957C9617DBCF7297E4F3D8E434F3C8A8E8E76A55822CD662CBAF5764CBAEB3E18E3E294F2D0A83F81CE6339387EF7ED389B7DA47F829BBDB48C09BD93FD6252C26BBC5F5EFD3B157B94';
wwv_flow_imp.g_varchar2_table(136) := 'DC84CF241270498002C0251A267822603088D3BFC1B595C3DA034747876B83304DE9292AC4A9871E44C19B7F55FE7A4E9E3011CBB66C47F2273F1DA65107D76DB9A052E36F5F46CEE6F5A8BF50A3E48CECE69F30672E32E492BE6693529E503272DAED90';
wwv_flow_imp.g_varchar2_table(137) := '22C0954FE2CFCF55128F7B20C0E4F7095000BCCF81FF0F81803CF79BDC7C0B75D65E80438CD50EA1E8D0CC22BA64DBDE7D1B27766CC1991379CA3E4E5A7125E6AD598FA8D97395F3D0F01201C7C58B38F3D80E1CFDF54BE854149411111198B66C05464F';
wwv_flow_imp.g_varchar2_table(138) := '9922C6FBE527F55279E1B22505803B5FC3332A7711312DD0042800024D5C63F5998CAE3F424E8703768D0800674F0FEA7FFB2BE43EF1181AABAB955AD16C8EC49C9BBE84CC7B57C23C769C521E1AF52760AD2847C196F538B5EB6DC8CF53FFD4C1F71246';
wwv_flow_imp.g_varchar2_table(139) := 'A661D6F5372261CCE8C10DC2E4A8C36673EBA9C14009E01690CB44267C40C0F8C1067F9380B7040C3020C2CD9790B860D68400703437E1ECCEADC87D595C81767729618A8A8DC3A23BEEC4E86F7D974BFA2A11BBDCA86DF73B3878D7EDA8CE3F7979E220';
wwv_flow_imp.g_varchar2_table(140) := '470C428C8ECECCC2D4A54B61898B1DC422BC0E79123CFCF20EAFF60C456FF9190AC55609139FE4B9DF28FF73E3AFBD536D829C9B22829AD495730479F7DC8192BD7B94C7FBD3A64CC3F2471E47C20D1F0DAAEFE15AB95388ACEA679EC2919D0FA3ABAB53';
wwv_flow_imp.g_varchar2_table(141) := '290CF9D8DEC9F3E62163EE3C982C914A7942DDC8E16109694F7F7BA11E5FB0FC63BD970850005C62C12D2F09C8F17FF936B8C8276F8BB3298ED9BA2822788745F76BCB1B7F44EE8EADA8AB3AA7E487C16040E635D762F6C62D88C898A8948746FD09D8CE';
wwv_flow_imp.g_varchar2_table(142) := '55A27CCB46E4BFF167D8EC6ACF50884D48C4B4ABAF45EAA4C9104DD0BFC030DE7358DD0F0150008471E38688EB140021D210E1EA86C9E8EAF42F237286E51080A3B919D53F7B16D9CF3F87D696161988C777644C2CE67FF5EB9874F703308A1392C70C34';
wwv_flow_imp.g_varchar2_table(143) := 'B88C40A7E86D39BE793DCA8F1C52EE6D491E3306D3AFB906714989979517EE07EC3DEE879BA4F80EF71803EF3F6BEC4B8002A02F0D6E7B4DC06C70FD11923D00DDADAD5E9719CC0CB62A7105FAF026E4FFF94FB0CB950C159C19317A3416DF750F52FFDF';
wwv_flow_imp.g_varchar2_table(144) := '3760888850C8419381049ADEFC2BB2B76C40E3998A814983EE4BD999316316B2965F0173A436BAFCFB06EAB43B60F330819602A02F316E0F85807128999887043E201061945FC51FEC5DFEBBA3BEEEF283217AA4F3E03E1CBDEB769CCE3DA67C053A6EE6';
wwv_flow_imp.g_varchar2_table(145) := '2C2C78F851C45E7135F8F29E80530C119DDDB611D94F3D812E0F27BC0F4A3747C762EA8A2B3066C6744D75F97F105FEF6F213E7BDADA7B375DFD1761E4D7B72B36AE8EF3787F02FC04F5E7C13D2F09584C2618C43F57D95AEBEB0187C35572481C77CAA7';
wwv_flow_imp.g_varchar2_table(146) := 'F8BDFC4B1CDEBA09CDAD6A5DFE6611F7ECCF7F1133B6ED8469E4A8908823DC9CE8292942FEEA0750FCDE6E21B8647F91E7089246A561E68AE548125DFF9EADC3D7C269B5A2530C45B98A405EFD5B4C4657C93C4E024A04F80952C244235704E45588D1CD';
wwv_flow_imp.g_varchar2_table(147) := 'CCABAEB636D81A8408705540908FDBABCFE3DC8F9F40DE6F5F468FF8D255712766443216DC7C2BC67CFB7B3098D9E5AFC26CA04DDBAEB7705C08AEEAA282814983EE1BC4D151191390B97C05A29392C49EB67F1C4294F6B8E911B108011AC91E002F3F04';
wwv_flow_imp.g_varchar2_table(148) := '341F488002602011EE7B45C020ACDD0D03387ABAD175FAB4B00ABD9F9E937928DEB115456FFD1376B96881828B695953B0E8BE9548E292BE0AB40631B1DB512BC4D691C71F4593EA92BE6633262F5C84498B17C31C864BFA0E42C1E3A19EAE2ED8DC3C49';
wwv_flow_imp.g_varchar2_table(149) := '539EFCCD14001E39D2C03D010A00F77C98AA4040F602B83293B732B59796B84A0EDAF17671D23FBA6E35AA8A0A957C904267F2B2E598BD712BA2E62D50CA43A3FE041CCD4D28DDF810F27EF54BD8AC6A4F898C8E89C10C31DE9F3A7162FFC234BED7DDDE';
wwv_flow_imp.g_varchar2_table(150) := 'EE56945A44F7BFC94DCF9BC6F10C293C66BA9C0005C0E54C78C44B02F26AC47516279A4F09011022F300E4A4B3DA679FC2E1C776A2B5A3C3B5DB7D52E417EDBC6F7E1B990F6D823151FBDDCF7D42F7D96657EE51E4DD7B074E1F3EA83EDE9F361AD3AFBB';
wwv_flow_imp.g_varchar2_table(151) := '01712347FACC8F7029A8530C9DB9EB95B2184DE1120AFD0C6102140021DC38E1E29A458C47BAF3B5E574199C1E56357397DF5769D6F252946FDF8C137FF98BDBEED5BEF5258A93D0B2550F61E417BED2F730B75509882EFFC63FFF01471EDE8CBA736A0B';
wwv_flow_imp.g_varchar2_table(152) := '2A1945D776FAAC3998227A5C22A32CAA3569CAAEB3D3BD3875D7EBA629103E0B86050D46800260302A3CE615018BC908775F481D8D8D70B4BBFF42839F5F1DFBF7A268C73671057A080E710DAA52DDD879F3317FCD3AC45E71958A396D0610703437E3DC';
wwv_flow_imp.g_varchar2_table(153) := 'D38F23F7A7CFA34B6C0F481E7437222AAA77BC7FECD4A930EA64BC7F2008B90640A787BF17777F6F03CBE33E09B8224001E08A0C8F2B1388341A6176331E69B5D9D17DAE12417989A187E63FBE869C1D5B5173A642EDD42F6299FEF1FFC0CCD5EB103939';
wwv_flow_imp.g_varchar2_table(154) := '2B286E877BA5B60B3528D8BC0E85FF7853794125B9A4EFAC6BAE454A4606DCDC590AADBFEC2DCD6ED74490435266A39C95A27512BE8B8F250D4E800260702E3CEA05018B1802906F57591CE2B4DB9C7F02509C69EFAA1C6F8F3BDADB50294EFCD92F3C87';
wwv_flow_imp.g_varchar2_table(155) := 'AEEE6EA5EC51160B96DC7E37D2C5DB101BA7948746FD09B489DE96EC3B7E88EA93A2CDFB27B9DC4BCB9880E9D75E0B4B1C9977D6D5C16EB3BA641525FEDE8C42A4BA346002092812A00050044533F704A23D74D7D61C3A084747BBFB427C98DA230447C9';
wwv_flow_imp.g_varchar2_table(156) := 'AAFB51B47B9772977FF2A4C958BAE331247DEC133EF4443F45C905956A7FF50B646FDF8A56C52E7FA3E83D4A9F390B13162D8699CB28030E279A45EF89AB4F8DBCEE8F8B30EBB983C4151A37C799E48A0005802B323CEE1581780F0BE2D417E6C35A55E5';
wwv_flow_imp.g_varchar2_table(157) := '5599433276D8D1FA8FBF236FFB16549614AB1521AEA6262D5B8EF90F6D84256BAA5A1E5AF523601727ADB29D5B71FC955FC3DAD3DD2FCDD54E54740CA65F7535C64E9F0ED104AECC7475DCD6D38396A6269731CB2BFF780A25977C98E01D010A00EF78D1';
wwv_flow_imp.g_varchar2_table(158) := 'DA05814893D1ED3C0088579BB82A17BFFCF6E36C6F47DD4B2F22F799A7715174A3AA5464B65830F7F35F44E6036B601A95A6928536030874179CC4C9CDEB717ADF5EA80EF3248E198B69575F8DF8D4D401A5E97BB7BBA9096D6E1E032CE7DBC498CDFA86';
wwv_flow_imp.g_varchar2_table(159) := 'E465F434774D8002C0351BA67841C0242EE1623D7C31D51ECB811C97F7A25865537B6303CAB76D44EEABAFA04B5C45A9648C4D1A81A577DF87B46F7D1706210454F2D0A63F8166D1DB72E0FE7B505B7AAA7F829BBD31995998BA7809A238DEDF9F92E8FE';
wwv_flow_imp.g_varchar2_table(160) := '6F13C2D509D7CF4590E3FF86FEB9B8470243264001306474CC389040426404DC7D39359695A2E7EC9981D986BDDF957304C7EFFA11CA73B295CB1A9D35054B1F7902B1575DAB9C8786970838446F4BD58F9F40CE938FC16AB75D4A70B365165DD799E2C4';
wwv_flow_imp.g_varchar2_table(161) := '9F3E771E8C621CDB8DA92E93E41C8AA6FA5AB7B1B3FBDF2D9E411279C81D010A00777498E61501F9E5E46E7DF28E8B17D1927FD2AB32DD193BC55873CB1F7E8F63DB36A1A1F6823BD30FD38C4623A67EEC1398B57507CCA21BFAC3046E2813B00A2157B2';
wwv_flow_imp.g_varchar2_table(162) := 'E92114FCED0DB7CBD5F62D3026210153AFB812A91919109D457D93B8FD6F02B6E68B68134300FFDEBDEC97D960448C87C9B69765E2011270438002C00D1C26794720429C5CE518A5BB5CB5B9C7DC252BA73944977FCD0BCF20FBE72FA04D5C8DAA648C4E';
wwv_flow_imp.g_varchar2_table(163) := '48C002D1DD3FE1F6BB61E42D7E2AC82EB369DFBFB75770551ECFBD2CCDD581E4B4D19871D535884F497165C2E382405BCD05B7822A56F49AC8BF3161CA1F450234734F8002C03D1FA67A4940F602B8CBD2585A0A6BE55977261ED3ACA7CB50B67D0BF2FF';
wwv_flow_imp.g_varchar2_table(164) := 'F657D81D0E8FF6D220253D030BEF5B89E4FFFE0278098A21BD1AFEF02A72766E437395DA92BE06830119B3E72073F90A9875BAA4AF2A684757172ED454BB19FD0792222320EF02502D937624E08900058027424CF78A809C0760125FFCAE3275B734A161';
wwv_flow_imp.g_varchar2_table(165) := 'CF6E57C91E8F77BCFB36B2C5787F45DE71B75F967D0BCA58B010F3B73F8698854BFA1EE6B62201474B334A1F7A10477FFA3CBAC5894A255B84BCC54F74F1B3DFF90000100049444154F98F9932154613BF663C31EB3E770E2D6E1E4E6510057812D7C284';
wwv_flow_imp.g_varchar2_table(166) := '3FFD0870C71301FE657A22C474AF08C859CA0911116EF39C7AE34F702A9E483E28C8D9D18EDA9F3D87C33BB7A34D71553FB3D98CB95FFE2AA66D7A18C6C4C40F8AE26F2F0874E51EC58907EFC3E923879573258E48C6F4155720212D0D90672EF0E58E80';
wwv_flow_imp.g_varchar2_table(167) := 'D36E47FD990AB78256DE61E34E58BB2B9F6924E08A0005802B323C3E2402F2FB7E8425D26D5EF96098662F7A016C62C8E0ECE38FE0C4EBAFC1EAB0BB2DFB83C4D894915874C7DD48FBC63701373D12E06B70024E279AFEF2471CDDB115B5E56583DB0C72';
wwv_flow_imp.g_varchar2_table(168) := '74D4C449C8BAE61AC42451700D8267D043B6C6465C6C6B1B344D1E54F99B92767CF727C03DCF0428003C33A2859704E2440F80A7C94AE5AFFD0E4E375D9E1F54D975EC280AC549A864EF7BCA4BFAA6654DC1A295AB9070C3473F2886BFBD20E0ECEAC4B9';
wwv_flow_imp.g_varchar2_table(169) := '679EC2D1E79F45FBC58B4A39CD1191C89A3B0F93C4708BD96452CA432341C0E144735515BAECAEE7B2C85E3576FF0B56FCF139010A009F236581F28AC5D330C0C5CA4AB4E5B99F49DE22AF4037AC418DE222330618C4D5E77598BD691B2C3367B3218640';
wwv_flow_imp.g_varchar2_table(170) := 'C05E578BC2B50FA2E8AF7F815DB1B7253A36B6B7CB3F252B0BA209C0973A01474B0B6A850070BA1900903D6A9E04B57A8D7AB1649C2A0428005428D1C66B024991916E970676882FBCCABFBD016767C76565CB2FC5F38F6CC391E77E8276C5F17E93D188';
wwv_flow_imp.g_varchar2_table(171) := '8537FF10931E580D6302BB9F2F83AA7040DEE2977DCF1DA83A7942B48E4206613262DC38CCB8EE06C4A6A6883DFE784BA0ABBA0A6DDD5D2EB319444AA2F85B12BFF843023E2760F479892C9004040179CF72AC180A109B2E7FCEE71C4167DEF17EE93D25';
wwv_flow_imp.g_varchar2_table(172) := '4528DDBC1E856FBF0D871887EE97E86227795C3A566CDC8AE44F7FD685050FBB23E0ECE941EDAF5EC4919D0FA345F400B8B3FD20CD603060DCB419C85AB818111EE67C7C9087BFFB13707676A1F6DC39B7624B4EFE8B14E2B67F4EEE7922C07435021400';
wwv_flow_imp.g_varchar2_table(173) := '6A9C68E5250183B01F11E9FE6E00B9E279F5DBFF82A3B505B0DBD1B6FB1DE4EFD88633278E2B8FF78F9D3D07F3D6AE47F48245A246FE784BC0DE508FB38FEDC0F1577E03AB18FB57C96F32992197F41D3F6B26B8A4AF0AB1C16D5A4F15A3BEAD6DF04471';
wwv_flow_imp.g_varchar2_table(174) := '54FE0D2573FD0441823FFE224001E02FB22C1772E292595C29BA4371FE6836AA5F7B1517FFFC7AEF2D7EF58A8BCCC893D0ACCFFC1766AEDB04737A86BB2A98E682404F7919F2D7AD46C9EE5DCA4FF18B4F4EC1ECEB6F404A7ABA8B5279588540EF30D799';
wwv_flow_imp.g_varchar2_table(175) := '33B0BBE9E5321B8D48F4D08BA65297FE6C18B12A010A005552B4F39A805CB52C352ACA6DBEAE8E0E14FEFE151CFBD90BA213C0E6D6F683C498E8E8DE5BFCC6FEE0361862623F38CCDF5E1068113D2FD9F7DC8E0B65A56AB984904B1B9F8E29CB57202A21';
wwv_flow_imp.g_varchar2_table(176) := '5E2D0FAD0627E070A2F5EC19B4DADC7FDE532C16AEFC3738411EF511010A001F816431831348155D9811E24A66F0D4F78FCAA100775742EF5BBDFF7FEAE44C2CD9F118126FE42D7EEF13F1EE7F477B1BCEFFE449643FB613ED8A8B311944FB65CC9A8D09';
wwv_flow_imp.g_varchar2_table(177) := '4B962242B4A77735D27A20017B6303AA2A2ADCCE71B1984C900260605EEE7B26400B75021400EAAC6839040272F5B291BE3869882BD0C9CBAFC0DC8D5B1139396B089E308B555C759E7A780BF2BDB8C52F2A360E33AFBA0663A64E856802421C2E01A176';
wwv_flow_imp.g_varchar2_table(178) := '1B4B4FA1B5A7C76D49F26FC66C94B300DC9A319104864580026058F8985985C088C848C8C54C546C07B389B04461CE4D5FC2E4956B601A913C98098F7920D079E4104E6C5E8FB3D9EA4BFAC68F4CC3B42BAE441C6FF1F340573DB9A7F6026A2ED4BACD10';
wwv_flow_imp.g_varchar2_table(179) := '217A5CE4DF8C5B2326BA20C0C3DE10307A634C5B12180A01B3F8421BE5612E80AB72135252B0E49EFB31FA9BDF818113A25C61727BBCE18FAFE1C0BAD568A83CEBD6AE6FE2D8AC29987EE595888A8FEB7B98DBC320E01463FEE74EE4A1C3EE7AEC5F5EF3';
wwv_flow_imp.g_varchar2_table(180) := 'A74547C1C8EE966190665655021400AAA468372C0249964878733FB3FC221C3B6D0616ED781CB1575E3DACBAF59AD9D1DC84335B3722F785E7DCCE36EFCBC722845AD6C245183F672E8C46D90A7D53B93D1C02AD2525A86F69755B84BC738657FF6E11B9';
wwv_flow_imp.g_varchar2_table(181) := '4D64A277042800BCE345EB211290A792D1D1D130426E792E64F20D3762E6B69D308F1EE3D998169711E83E9987C2F56B50B267B7F29A0A318949C85ABA0C2913278217A097211DD681EEAA73A8282D8553FC7357909C346B247C778898E64302461F96C5';
wwv_flow_imp.g_varchar2_table(182) := 'A248C02D81A4C808C44798DDDAC844A3E8EA4F5EBC0C068B45EEF2ED2581E67FBC899CED5B70BEA85039E7C8F1E99879ED7562BC3F55390F0DD508F476FD17E4A3D366759B21CE6C867C90965B2326BA21C0246F0918BDCD407B12182A0183C100B92E80';
wwv_flow_imp.g_varchar2_table(183) := 'A73E0087D58AFA23EA93D586EA8FE6F2D9EDB8F0D28B38FAF4E368AFAF570ACF6034225D74F74F5CB41826B349290F8DBC20E0042E1614A0B1B5DD6D2693F8DB1813130D4F7F1B6E0B61220978498002C04B60341F1E8138D103204580A7524EEF7A0BF5';
wwv_flow_imp.g_varchar2_table(184) := 'FFF8BB2733A6FF9B805CD2B768E53DC87BE5D7B00921F0EFC36E7F992323317DF90A8C9D32054613BF0ADCC21A62624F5D2DCACB4A3D0EC3248BDEAE18B3E7DEB121BAA18B6C0CD27B02FCABF79E19730C93C0E8E828A87CD9E53EFD043A728F0EB336ED';
wwv_flow_imp.g_varchar2_table(185) := '67EFCC3E84BC95F7A2F2E409E56093468EC2CCEB6E40C2E8D1CA7968E81D017B7B072AF28E7B9C80192B4EFCF2BE7FEF4AA735090C9F0005C0F019B2042F09C8494E5204C86E4F77599DE24A36FFF967613D5FE5CE4CB7694E31A6DCF8FAABC8D9B91DF5';
wwv_flow_imp.g_varchar2_table(186) := 'E72A9538C82EFFB4499391B56C39A2E36295F2D0C87B024EBB0355B9C770B1A5C56D66D9E53F5674FDCB7BFFDD1A32D10301260F850005C050A831CFB009C4474440656D80A68A7294BDFC4B38BBBB875DA7960A70B434E3AC18EB3FFAF39FA2536CABC4';
wwv_flow_imp.g_varchar2_table(187) := '668A88C4E4B9733161FE0298222354B2D06628041C4E341415A2FA428DC7DC23A3D47AC33C164403121802010A8021406316DF1090B73C459B4C1E0BAB7CF71DD4FCE1F71EEDF46260ABAA44C19A9528F9E73FE0743A94C28E4E48C4F4ABAF46EAE44C18';
wwv_flow_imp.g_varchar2_table(188) := 'E465A7522E1A0D85C0C5F25294151779CC2A9FF42717FDF16848038F0468303402140043E3C65C3E20208702C6C6C4C0D35080ACAAE037BF42EBC17D7253D7EF3621860EDD7D07AA4F95287318316E3C665C7D2DE2929294F3D07068043AABAA5096EFF9';
wwv_flow_imp.g_varchar2_table(189) := 'F64BF9991F1B1B03F93730B49A988B04864F800260F80C59C23008C8BB024647477B2CC161B723F791EDBA9D0FE0EC6847CDCF9EC391C777A243B1CB5F5EE88FCB9A02B9B84F84855DFE1E3F64C334E86E6A42F1B1A3B0DBDDDFEF2FDB458EFB7BB332E6';
wwv_flow_imp.g_varchar2_table(190) := '305DD378768637540214004325C77C3E2390126541ACD9ECB1BCAEF6769C7CEA31D8EAEB3CDA6AC9C05E538DF24777E0C4EBBF87CDC353E43E88DB146941E6D265182FC6FC8DF28CF341027FFB8580ADA50515470EA35BA17DE4FC1779DB9F5F1C61A124';
wwv_flow_imp.g_varchar2_table(191) := 'E00501A317B6342501BF1090E7A78971B14A4F0CAC3F9E8BC2A79F80AD416DA11BBF381CC042BB0AF391B7691DCAF7EF55AE353E390533575C8194F1E395F3D070E8041CED1D281757FE4DADEED7F99735C8392FE345D7BFDCE6DB370458CAD00950000C';
wwv_flow_imp.g_varchar2_table(192) := '9D1D73FA9080D968C4B89818A8748BD61C3E88E39BD7C37EF1A20F3D08BDA22EFEE58F38F2C03DA82F2F53766ED4F874642D5F81989464E53C341C3A01477737CE661FC6C586068F85180D066408A11B213EEB1E8D6940020120600C401DAC82049408C8';
wwv_flow_imp.g_varchar2_table(193) := 'F900E9B1B13042F609B8CFD2585488EC55F7C1D6E8F98BD77D49A197EA1063C9953BB721E7D91FA3CBEA7E3CF943EFC5C965C2DC7998B4642922C590CA87C7B9E137028EB636541C38800B2A277FF1999E1417A7D4CBE53787355930831A0E01E3703233';
wwv_flow_imp.g_varchar2_table(194) := '2F09F89A801401B28B54CE92F654764BC5691C5FBF16D60B173C99864D7ACFA962146DDB88A277DEF2F0DCB84B2159A26331E3CAAB303A2B0BE23C03BEFC4FA0A7B919A7C4987F9D820095727682B8F2979F6DFF7BC61A48409D0005803A2B5A0688C008';
wwv_flow_imp.g_varchar2_table(195) := '4B24E402292AD5358A13E6C9C7B6C35A53AD621ED236ED7B77E3F8B6CDA8CA3BAEEC677CEA48CCB8EE3A248C1AA59C8786C3232067FB971ED88F2685212883A86A8C18DA4AE0C24B8284EF7F58E2F00850000C8F1F73FB89805C20252D2A4AA9F47A71C2';
wwv_flow_imp.g_varchar2_table(196) := '94274E6BF57925FB9033723870E1572FE29038F93729C6603018316EDA744C5B71252CD16A9C422EEE3074A8F3420D0AF7EF476B478792F752C8729D7F2554340A02010A80204067956A0446C74423293252C9F86249117256AF44B889007B7D1DCAD6AF';
wwv_flow_imp.g_varchar2_table(197) := 'C689DFFE1A7621045482B5444763F2FC05183763264C1126952CB4F10181D6EA1A14E5E4A0BBAB53A9B4548B0552C82A19D36808049865B8042800864B90F9FD4A40CE9A964BA6AA54D25A5D8583F7DF8DCEA20215F3A0DB74E51EC58975AB512EC6929D';
wwv_flow_imp.g_varchar2_table(198) := '8ADEC4242662AAB8EA4F9D341106A3413117CD864BA0E9EC59141D3C809EAE2EA5A2E432D7E362B9D29F122C1A058D000540D0D0B3621502F21437213E0E72E114B9ED294F97B8A23EB276359A0EA8DF37EFA94C9FA73B9D68FAEB5F90B37D1BEABCB9C5';
wwv_flow_imp.g_varchar2_table(199) := '2F6302665E7B1D6292127DEE120B1C9C80D3EE40CD891328CEC98643F1B90B6344CF95BCA575F01279D4570458CEF00950000C9F214BF0330179E24F17575369A2EB5B6E7BAAAEBBAD054736AEC3853FBD0E8893AD27FB40A63BBBBB51FDF31770F4D9A7';
wwv_flow_imp.g_varchar2_table(200) := 'D1D1D4A85CB51CEF9FB060214C0A2B262A174A43B7041C3D3D38237A67CEC8E72E287C8EE467539EF84729CE5D715B391349200004280002009955F886405A7414D215D7099035E63DFF0C8A1FD90EA7CD267783FEB6D554A360E53D38F9FAABCAE3FD91';
wwv_flow_imp.g_varchar2_table(201) := '621C79FA955763FCAC59309AF8E71AA846ECEEE844D19E3DB870BE4AA94A79F297C355B2EB5F29038D864980D97D4180DF28BEA0C832024640DE2228C756CD06B58FEED977FE8563F7DC8E9E331501F371B08ADAF7BE8763F7DF8DF3459E9F14877FBF46';
wwv_flow_imp.g_varchar2_table(202) := '8C198BE9575F8BC434DEE2F76F2401F9D55A578FE2DDEFA2B5B949A93EA3C1808962984A75C2AA52A1342281001050FB160D8023AC82045409245B2221175651592C4896D950528CECF56BD07670BFDC0DE8DBD9D58586DFFD06D98FEF44535DAD5ADDE2';
wwv_flow_imp.g_varchar2_table(203) := '8492363913998B16233A215E2D0FAD864FC00934559E43D1FE7DE8EC54BBCD4F0AD14C71F24F8888187EFD2C4199000D7D438002C0371C594A8009C855D532C5C9314E714CBC5D74BF1FD9B115F57FFE43C03CB58B13FEE9271FC5B1977E811EC5FBC64D';
wwv_flow_imp.g_varchar2_table(204) := '4613B2162DC184F9F361E2E231016B2B39C45F71220FC5470EC161571B328A32999099108718C5CF60C082614524A0488002401114CD428F807CB25A7A5C2C546F13B47576E2D8733F41F52F7EE6F7C9813DA7CB912F7A1DCADE7D074EC5D9E3D1F1F198';
wwv_flow_imp.g_varchar2_table(205) := '71DDF548C948871C530E3DE2DAF4C8D6D9D57B2BE685D253CA01CA87564D1257FE52042867A2A18F08B0185F11A000F0154996131402F28B588EBFCA4557541D38F9EA6F51B0EA3ED815D671572DB3AF5DD39F5FC7C1BB7E840B5EDCE237222D0D33C478';
wwv_flow_imp.g_varchar2_table(206) := '7F2C6FF1EB8BD2EFDB3D2DAD28397C18F5E72A95EB92ABFB4D4B4C80FCEC2967A221098420010A80106C14BAE43D013931303D36465C39AB5D3B57E51E43DE43ABD079427D421D53490000100049444154DD7D7878399A9B51F5D46338FAC273E8EE565B';
wwv_flow_imp.g_varchar2_table(207) := '30467A3B6EFA0C64ADB812117C8A9F07C2BE4DEEACAB43E19EDD686DA8532A58CE3991F7F8CBB79CF8A79489463E27C0027D478002C0772C59529009245B2C98181F0BF945ADE24A7D59298EEE7C182DA29B5EC5DE9D8D555CED97EED8828237FFA67C8B';
wwv_flow_imp.g_varchar2_table(208) := '9F393A1659CB5660FC8C99301AA514705703D37C49A0B1BC1C27F7ED435777B752B1668301F22995F21E7FB69412321A8501010A80306824BAA84E40CEC6CE4A88579E98D551578BECC71F41ED6BBF03EC76F58AFA58B61FDA8FDC0D6B71E6684E9FA3EE';
wwv_flow_imp.g_varchar2_table(209) := '371392933173F932248F1B0BD16D01BE0243C0E104CE1714A0F4782E1C0EB5F69693FCB21212C0DBFC02D346EE6B61AA2F095000F89226CB0A09027262D6C4B858A8DE2160EFE946DECF5F40F9E33BE1B45ABD8AA1FE77BF46F6C67568AABDA09C2F6DE2';
wwv_flow_imp.g_varchar2_table(210) := '44645D7535A2478C50CE43C3E113B0F5F4E0ECE183A82C2A84534EFB572832313212F2B364E1224C0AB468126E042800C2ADC5E8AF128108A31193454F80ECB255C9202E0C51F6F6BF9077DF9DB055799E10269FE257B165038EFDF245F4283EC5CF6032';
wwv_flow_imp.g_varchar2_table(211) := '61D2DCB998B860112278EB984AB3F8CCA6BBA505A70E1EC085AA2AE532E5643F79F2979F25E54C34F42B0116EE5B021400BEE5C9D24288801CAB1D1D138DF131319063B82AAED51617E1E8BA35E83A99E7D2BC3B2F1705E2E47F6AEF7B2E6D062644582C';
wwv_flow_imp.g_varchar2_table(212) := '9826C6FB47654D01BBFC11D0576B5D3D8AF6EF474B7DBD52BD468301724DFFB1E2B3A39481462410A6042800C2B4E1E8B61A0183304B89B240DE25A02A029AABCEE1C8A67568D9F53630605198967FFC1D47B76F458DE84616452BFD248E198BD937DC88';
wwv_flow_imp.g_varchar2_table(213) := 'C4D1694AF634F21D81C6B23214EFDF87AE8E76A542E5045279D5CF35FD957005D888D5F99A000580AF89B2BC9024202770793339B04B74191FD9F930AA7FFD12EC0DF570B4B7A1FAC59F22FBC9C7D0A6B87E80510C43A44F9F81298B1723323A3A24B968';
wwv_flow_imp.g_varchar2_table(214) := 'D52987DD8ECABC3C949EC8837D80887315B39C33223F23F15CD6D715221ED718010A008D3528C3714DC022C7E0E3E29467733B9C0EE4BFF21BE4DDFD23E4DF7717F27FFF0AEC8A93C722C44964D28285183373264C62DBB5574CF1350187D586B3B9B938';
wwv_flow_imp.g_varchar2_table(215) := '5F7A0A4EC5F919723549F9343F3981D4D7FEB03CDF106029BE274001E07BA62C318409988D86DE0709A58A31791537E5E4C0FADA5AD49C2E87DC56C9133B22B97749DFD4091338DCAF02CC87365D6DED287877172E78F1F4C7DEC97EF17188103D363E74';
wwv_flow_imp.g_varchar2_table(216) := '85459140C813A00008F926A283FE2020E7048C8D8981D1206709F8A80651D6C8F1E99871E55590EBFAFBA85416A348A0ADA111C57B76A3BDB54529871CEF97AB47CA95FD9432D028880458B53F085000F8832ACB0C0B0223A32CBDBD01AA9303DD06254E';
wwv_flow_imp.g_varchar2_table(217) := 'FEE9336761D292A530F1297E6E51F923F1E2D9B3287C6F37BA3A3B958A9757FB13E26221578FF4A10454AA9B4624102A048CA1E208FD20816010902B076626C42B2F1A34988F51F1F1987ED5D5183B6D1A840E18CC84C7FC44C0617B7FB2DFA99C6CC839';
wwv_flow_imp.g_varchar2_table(218) := '1B2AD5C8A7484E49880727FBA9D00A0D1B7AE11F021400FEE1CA52C388809CF8952EAE06E544306FDD36464460FCB4E9481C39D2DBACB41F26819E8E0E941F3BFAFE643FC5C99952F0C905A2640FC030AB677612087B02140061DF840CC01704228D46C8';
wwv_flow_imp.g_varchar2_table(219) := 'C70ACB0961DE9417939088C4549EFCBD61E60BDB6E39D9EFC07E34549E552E2E2D2A0A93E2E3941785522E98867E26C0E2FD458002C05F64596E581290ABBF65C4C6424E105309A0ADA11E257B76A3BBF1A28A396D7C40A0A5BA1A2777BD83EEE666A5D2';
wwv_flow_imp.g_varchar2_table(220) := 'CC0623C6C5C440AE0AA994814624A0130214003A696886A94E608425B2777260843871A8E46A6D6F47B1B81AEDACAB5331A7CD3008349495A2F8F021D8AC3D4AA5C8369433FDB9B29F12AE9034A253FE234001E03FB62C398C09C809625312E31163362B';
wwv_flow_imp.g_varchar2_table(221) := '45D1D9DD85FCBD7B505F7A4AC99E46DE1170388173C78FA354BCE52A7F2AB97B57F6136D98C0BB325470D1468704280074D8E80C598D809C2836598C194B31A09243AE12783AEF04AAF3F2E0E851BB42552957EF36B6EE6E9C39721855E2EA5F9545B2E8';
wwv_flow_imp.g_varchar2_table(222) := 'C5C9888B859CDBA19A8776A148803EF9930005803FE9B2ECB02720E702C88963A3A2A2946271C089B3A217A0E2D851D83BD4EE49572A58A74672A67FF18103A83D57A94C40B6557A6C2C57F653264643BD12A000D06BCB336E650272A118B95A9C9C4826';
wwv_flow_imp.g_varchar2_table(223) := '2794A964ACABAA42E1DEF7201F2AA4624F9BCB09345FA845C1AE5DCA0F5F92624D2EEE23DBEAF2D278241C09D067FF12A000F02F5F96AE21027222D9F8D818E52BCBF6B63614EF790F6D95EA57AF1AC235F450C4787F5D69294A0F1F4277779752396683';
wwv_flow_imp.g_varchar2_table(224) := '0113BD78D09352A13422018D13A000D07803333CDF12488C8C805C452E567172609718BF2ECCC9466D5111C4E8806F9DD160694EBB039505F9283F91A73CD35FB6857C8C6F5C84DA844D0D62D368480CCBDF042800FC4D98E56B8E809C1C28BB9A474446';
wwv_flow_imp.g_varchar2_table(225) := '2AC5E67038705A9CD4AA8410902738A54C3A34B2F7585126AEFACF174BB124BA013C3090433372F546D9161693C98335934980040612A000184884FB24A040408A0039CB5C3E5048C1BCD7E4DCD93328DBBF0FF6F68EDE7DFE7789805CD4A7E09DB7D050';
wwv_flow_imp.g_varchar2_table(226) := '7DFED2410F5B72D546B97AA36C0B0FA64C0E430274D9FF042800FCCF98356898C0D89898DE4583E4043495301BEA6A51B46F2FDA9B9A54CC7561D35ADF8082BD7BD1D1A1268CE444CC8971B1E0643F5D7C3C18A41F095000F8112E8BD6078124311420BB';
wwv_flow_imp.g_varchar2_table(227) := 'A1E5894925E2B6B65694ECD983E6336754CC356DD3585E8EC23DEFA14771B29FC568447A5C0C1205734D83D17D7004100802140081A0CC3A344F402E1624570E94ABCFA904DB63ED41F1B163A829C887D36E57C9A2291BBBD58ACABC1338753C174EA743';
wwv_flow_imp.g_varchar2_table(228) := '2936B92A6366423CE413FD9432D0880448C02D010A00B778984802EA04E4AA73B227405E9DCA096A9E723A1D769C2D2AC2597112D4D3CA813DDDDD3823C4CFF9D21288B3BF274CBDE972C265667C9CF22D98BD99F85FD812A0E3812140011018CEAC4527';
wwv_flow_imp.g_varchar2_table(229) := '04CCA28B5A8E4FCB096A2A21CBB9EE35151528DEBB07361DAC1CD8D5DC8292F7F6A0CE8B95FDD2A2A320275C1A0D2AB24A853A6D48800424010A0049816F12F0310139414DF606A8CE0B68696A42FEAEB7D1A1E1270A365555A160FF3EB4B7AA3DC637C2';
wwv_flow_imp.g_varchar2_table(230) := '60847C34F3E8E8681FB70E8B0B6D02F42E5004280002459AF5E88EC0079303A314EF51978B0615ECDB8B260DAE1C5857568ED2234760ED549BE92F6FED9393FD4658D4D65AD0DD878B0193800F085000F800228B20015704E4EA7472EC3A5A5104D81D0E';
wwv_flow_imp.g_varchar2_table(231) := '94C827DF9DC883536CBB2A375C8E3B9D4E9CC9C941F9F163B03BD4263BCA899472B54539B1325CE2A49FBE23C092024780022070AC59934E09C8790172A95AD923A08240CE0B3877EA54EF44B99E4EB5B5F055CA0DB48DDD66C7E9C3875173A642A96A39';
wwv_flow_imp.g_varchar2_table(232) := 'C29F62B1F48EF7CB1E00A54C342201121832010A8021A363461250272027B0C93901F251B5AAB92E881367EF03711417C8512D371076DD6DED28DCFD2EEAAACE2955274FFE6962ACDF9B872D29154CA330234077034980022090B45997EE09C8C981E9B1';
wwv_flow_imp.g_varchar2_table(233) := 'B1509D1CD8DA508F93EFBC83E62AF52572830DB9B1F21C0ADE7B17EDCD4D4AAEC85514E592BE69D1514AF634220112F00D010A00DF70642924A04C20D912D9BB9A9DAA08B0F574E3544E36EAC5B08072254130743A9CA83F5D81D3C78EA2A74B6DE842AE';
wwv_flow_imp.g_varchar2_table(234) := '9D30293E8E8BFB04A1BD42B14AFA145802140081E5CDDA48A097805CCD6E6A623CE484B7DE031EFEB3DBAC283B918773050570CA49021EEC039DECB0DB5159908FB26339B0095F55EA972BFBC9C97EB166B38A396D4880047C4C8002C0C740591C09A812';
wwv_flow_imp.g_varchar2_table(235) := '9013DDE4BC0039F14D8E81ABE4AB2A2A44E97BBBD1D37851C53C2036EDF50D28163E5597142BD72705D06471E52F27482A67A2A1C60930BC4013A000083471D647027D08C813A09CF896161D0D83F8D727C9E566A39C1770601FEA4A4E21984B083BAD36';
wwv_flow_imp.g_varchar2_table(236) := 'D489618942E14BCB4575419226C6FA65B7BF1CFB77192413488004FC4E8002C0EF885901097826204F8A590971503D295ABBBB517E320FF9FBF6A2E3A2DA643BCF5EA85BC847F816EFD98D72312C211FECA39253F678C86592B9B29F0A2DFDD930E2C013';
wwv_flow_imp.g_varchar2_table(237) := 'A000083C73D6480283129063E2B25B5C4E8C1BD46090831DE2CABB60F72E9CCDCE46677DBD7FE707389CE816759CDEB70F45E2E4DFDCD4348847831F920B21A5C7C6403E2869700B1E2501120834010A804013677D24E086801401531212207FBB31EB97';
wwv_flow_imp.g_varchar2_table(238) := '24570FAC3E7B0627F7EF43D991C3686DBC08A7CD01F862B2A028C36977A0BDAE0E65D9477042D4517BA1060E2F6622CA898E93E3E3C195FDFA351B77FA11E04E3008500004833AEB24013704CC460326C7C7F59E300D6EEC0626396C36349CAB44E1BBEF';
wwv_flow_imp.g_varchar2_table(239) := 'E0E4AEB77B67E5375FA8455757376CE2EA5DFC0CCCD26F5F9CEB6117FF49DBAEAE2E5C3C5F8D33B9C770F29DB790BF670FEA45D9765147BF4C1E76C644472333211E32260FA64C2601120830010A800003677524A04240CE05902260744C348C5E3E0657';
wwv_flow_imp.g_varchar2_table(240) := '9CC3D1D1DA82F3C545283EB00FF9FFFA274AC449FCECC1FD389793839AE3C7D15054888B25256812EFFAC202D4E4E5A14A0C239CD9BB07256FBD859332CFA103A8395D2ECA6A159D09B25415CFDFB791C2655C4C0C464547BD7F80FF93801B024C0A0E01';
wwv_flow_imp.g_varchar2_table(241) := '0A80E07067AD24A044402E1D3C550C090CB5FBDCE970C066ED416B4B0B2E5457A3EA4C05CE9495A2ACA000A74E9E408978971716E24CE92954896184BABA5AB4B6B5C06EB58A2104EF4EFA1F0424BBFCE530466A94E58343FC4D0224108204280042B051';
wwv_flow_imp.g_varchar2_table(242) := 'E81209F42560311921D70B488B8A52BC51B06FEEC1B7E5A9BDEF7B702BEF8ECA5E8B91C2C709717188369BBCCB4C6B1D1360E8C1224001102CF2AC9704BC20204FAE7238408EA75B8CA177728D301A31519CF8C78A210BB3D1E04564342501120816010A';
wwv_flow_imp.g_varchar2_table(243) := '80609167BD2430040272D9DCCC8438C87BE9434108C85B16A52FD313131017C1257DC197D70498217804280082C79E3593C090084488AB6DB970909C2428E70898BD9C2438A44A07649275CA2189C9F1F190BE1883E0C30097B84B0224E025010A002F81';
wwv_flow_imp.g_varchar2_table(244) := 'D19C04428540A4C908F978E1E94989488F8D859C7C27870AFCE59F0186DE5B13D363633043D4298724E4FC047FD5C772F5408031069300054030E9B36E12F0010179D24FB64462427C1CE41AFBB24B5E0E15C8EE7999264FDCDE546310C60671B2977965';
wwv_flow_imp.g_varchar2_table(245) := '19F2C13D63636220871EE464C4648BC5EB5B134591FC210112083102140021D620748704864A4076CBCB13BFEC92CF4A8887EC19982C44C1B8D868C8D9F9499191BD57F03166332C26132C622841BEE532BDB2F720313202F2E42E6D659EC9A27B5F9621';
wwv_flow_imp.g_varchar2_table(246) := '45C5C8280B64D95214802F12F0110116135C02C6E056CFDA498004FC45C0200A9627FB1471C52E870A64D7BDBC829F2C44419638B9670A9120DF93C5F644712C430C238C8F8986ECDA977962CC26D10F200AE10F0990802609500068B259191409F42720';
wwv_flow_imp.g_varchar2_table(247) := 'C5809CA827AFE0E5DB6C342042F400C8B7596CCB63468301068378F7CFCA3D12F01301161B6C021400C16E01D64F02244002244002412040011004E8AC9204488004F44E80F1079F000540F0DBC4655B770000081449444154801E9000099000099040C0';
wwv_flow_imp.g_varchar2_table(248) := '095000041C392B2401122001BD1360FCA140800220145A813E900009900009904080095000041838AB2301122001BD1360FCA14180022034DA815E9000099000099040400950000414372B2301122001BD1360FCA142800220545A827E90000990000990';
wwv_flow_imp.g_varchar2_table(249) := '4000095000041036AB2201122001BD1360FCA14380022074DA829E9000099000099040C0085000040C352B2201122001BD1360FCA144800220945A83BE900009900009904080085000040834AB2101122001BD1360FCA145800220B4DA83DE9000099000';
wwv_flow_imp.g_varchar2_table(250) := '099040400850000404332B2101122001BD1360FCA146800220D45A84FE900009900009904000085000040032AB2001122001BD1360FCA147800220F4DA841E9100099000099080DF095000F81D312B2001122001BD1360FCA148800220145B853E910009';
wwv_flow_imp.g_varchar2_table(251) := '90000990809F095000F819308B2701122001BD1360FCA14980022034DB855E91000990000990805F095000F8152F0B2701122001BD1360FCA14A800220545B867E91000990000990801F095000F8112E8B2601122001BD1360FCA14B80022074DB869E91';
wwv_flow_imp.g_varchar2_table(252) := '00099000099080DF085000F80D2D0B2601122001BD1360FCA14C800220945B87BE91000990000990809F085000F8092C8B2501122001BD1360FCA14D800220B4DB87DE91000990000990805F085000F8052B0B2501122001BD1360FCA14E800220D45B88';
wwv_flow_imp.g_varchar2_table(253) := 'FE91000990000990801F085000F8012A8B2401122001BD1360FCA14F800220F4DB881E9200099000099080CF095000F81C290B2401122001BD1360FCE1408002201C5A893E92000990000990808F095000F818288B2301122001BD1360FCE1418002203C';
wwv_flow_imp.g_varchar2_table(254) := 'DA895E92000990000990804F095000F814270B2301122001BD1360FCE1428002205C5A8A7E92000990000990800F095000F810268B2201122001BD1360FCE1438002207CDA8A9E9200099000099080CF085000F80C250B2201122001BD1360FCE1448002';
wwv_flow_imp.g_varchar2_table(255) := '209C5A8BBE92000990000990808F085000F808248B2101122001BD1360FCE145800220BCDA8BDE92000990000990804F085000F804230B2101122001BD1360FCE146800220DC5A8CFE92000990000990800F085000F800228B2001122001BD1360FCE147';
wwv_flow_imp.g_varchar2_table(256) := '800220FCDA8C1E93000990000990C0B00950000C1B210B2001122001BD1360FCE1488002201C5B8D3E93000990000990C0300950000C1320B39300099080DE0930FEF0244001109EED46AF49800448800448605804280086858F994980044840EF04187F';
wwv_flow_imp.g_varchar2_table(257) := 'B812A00008D796A3DF24400224400224300C021400C380C7AC24400224A077028C3F7C095000846FDBD173122001122001121832010A8021A3634612200112D03B01C61FCE042800C2B9F5E83B099000099000090C910005C010C1311B09900009E89D00';
wwv_flow_imp.g_varchar2_table(258) := 'E30F6F021400E1DD7EF49E04488004488004864480026048D8988904488004F44E80F1873B010A80706F41FA4F0224400224400243204001300468CC42022440027A27C0F8C39F000540F8B721232001122001122001AF095000788D8C194880044840EF';
wwv_flow_imp.g_varchar2_table(259) := '0418BF1608500068A11519030990000990000978498002C04B60342701122001BD1360FCDA204001A08D76641424400224400224E015010A00AF70D19804488004F44E80F16B85000580565A9271900009900009908017042800BC80455312200112D03B';
wwv_flow_imp.g_varchar2_table(260) := '01C6AF1D021400DA694B464202244002244002CA0428009451D19004488004F44E80F16B89000580965A93B1900009900009908022010A004550342301122001BD1360FCDA224001A0ADF6643424400224400224A04480024009138D4880044840EF0418';
wwv_flow_imp.g_varchar2_table(261) := 'BFD608500068AD45190F099000099000092810A0005080441312200112D03B01C6AF3D021400DA6B534644022440022440021E0950007844440312200112D03B01C6AF450214005A6C55C644022440022440021E0850007800C46412200112D03B01C6AF';
wwv_flow_imp.g_varchar2_table(262) := '4D021400DA6C574645022440022440026E095000B8C5C34412200112D03B01C6AF550214005A6D59C645022440022440026E085000B881C32412200112D03B01C6AF5D021400DA6D5B4646022440022440022E095000B844C30412200112D03B01C6AF65';
wwv_flow_imp.g_varchar2_table(263) := '0214005A6E5DC646022440022440022E085000B800C3C324400224A077028C5FDB042800B4DDBE8C8E04488004488004062540013028161E2401122001BD1360FC5A274001A0F516667C244002244002243008010A8041A0F01009900009E89D00E3D73E';
wwv_flow_imp.g_varchar2_table(264) := '010A00EDB731232401122001122081CB0850005C8684074880044840EF0418BF1E085000E8A1951923099000099000090C204001300008774980044840EF0418BF3E085000E8A39D192509900009900009F4234001D00F07774880044840EF0418BF5E08';
wwv_flow_imp.g_varchar2_table(265) := '5000E8A5A5192709900009900009F4214001D00706374980044840EF0418BF7E085000E8A7AD1929099000099000097C488002E04314DC2001122001BD1360FC7A224001A0A7D666AC24400224400224F06F021400FF06C15F24400224A077028C5F5F04';
wwv_flow_imp.g_varchar2_table(266) := '2800F4D5DE8C96044880044880047A095000F462E07F24400224A077028C5F6F042800F4D6E28C970448800448800404010A0001813F24400224A077028C5F7F042800F4D7E68C98044880044880044001C00F0109900009E89E0001E8910005801E5B9D';
wwv_flow_imp.g_varchar2_table(267) := '31930009900009E89E000580EE3F0204400224A077028C5F9F042800F4D9EE8C9A044880044840E704280074FE0160F82440027A27C0F8F54A800240AF2DCFB8498004488004744D800240D7CDCFE0498004F44E80F1EB970005807EDB9E919300099000';
wwv_flow_imp.g_varchar2_table(268) := '09E8980005808E1B9FA1930009E89D00E3D733010A003DB73E63270112200112D02D010A00DD363D03270112D03B01C6AF6F02FF1F0000FFFF297FD491000000064944415403001D3474FF5122FA1F0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10565616788533329)
,p_file_name=>'icons/app-icon-512.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
prompt --application/plugin_settings
begin
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10556929772533322)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>46218173546769
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10557209136533322)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>46218173546775
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10557517391533322)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'show_on', 'FOCUS',
  'time_increment', '15')).to_clob
,p_version_scn=>46218173546781
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10557841288533323)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>46218173546784
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10558127638533323)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_values_as', 'separated')).to_clob
,p_version_scn=>46218173546789
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10558438619533323)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>46218173546795
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10558704701533323)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N')).to_clob
,p_version_scn=>46218173546798
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10559048866533323)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'mode', 'FULL')).to_clob
,p_version_scn=>46218173546801
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10559338828533323)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'default_icon', 'fa-star',
  'tooltip', '#VALUE#')).to_clob
,p_version_scn=>46218173546805
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10559676548533323)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>46218173546813
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10559922478533323)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'background', 'default',
  'display_as', 'LIST',
  'map_preview', 'POPUP:ITEM',
  'match_mode', 'RELAX_HOUSE_NUMBER',
  'show_coordinates', 'N')).to_clob
,p_version_scn=>46218173546819
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10560226785533323)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>46218173546822
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10560564419533324)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_BOSS'
,p_version_scn=>46218173546831
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(10560856813533324)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_style', 'SWITCH_CB',
  'off_value', 'N',
  'on_value', 'Y')).to_clob
,p_version_scn=>46218173546836
);
end;
/
prompt --application/shared_components/security/authorizations/administration_rights
begin
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(10568107730533330)
,p_name=>'Administration Rights'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrator'
,p_attribute_02=>'A'
,p_error_message=>'Insufficient privileges, user is not an Administrator'
,p_version_scn=>46218173546906
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
end;
/
prompt --application/shared_components/security/authorizations/reader_rights
begin
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(10568241230533330)
,p_name=>'Reader Rights'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if nvl(apex_app_setting.get_value(',
'   p_name => ''ACCESS_CONTROL_SCOPE''),''x'') = ''ALL_USERS'' then',
'    -- allow user not in the ACL to access the application',
'    return true;',
'else',
'    -- require user to have at least one role',
'    return apex_acl.has_user_any_roles (',
'        p_application_id => :APP_ID, ',
'        p_user_name      => :APP_USER);',
'end if;'))
,p_error_message=>'You are not authorized to view this application, either because you have not been granted access, or your account has been locked. Please contact the application administrator.'
,p_version_scn=>46218173546906
,p_caching=>'BY_USER_BY_SESSION'
);
end;
/
prompt --application/shared_components/security/authorizations/contribution_rights
begin
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(10568353221533330)
,p_name=>'Contribution Rights'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrator,Contributor'
,p_attribute_02=>'A'
,p_error_message=>'Insufficient privileges, user is not a Contributor'
,p_version_scn=>46218173546906
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
end;
/
prompt --application/shared_components/security/app_access_control/administrator
begin
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(10567795104533330)
,p_static_id=>'ADMINISTRATOR'
,p_name=>'Administrator'
,p_description=>'Role assigned to application administrators.'
,p_version_scn=>46218173546903
);
end;
/
prompt --application/shared_components/security/app_access_control/contributor
begin
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(10567938349533330)
,p_static_id=>'CONTRIBUTOR'
,p_name=>'Contributor'
,p_description=>'Role assigned to application contributors.'
,p_version_scn=>46218173546903
);
end;
/
prompt --application/shared_components/security/app_access_control/reader
begin
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(10568028501533330)
,p_static_id=>'READER'
,p_name=>'Reader'
,p_description=>'Role assigned to application readers.'
,p_version_scn=>46218173546903
);
end;
/
prompt --application/shared_components/navigation/navigation_bar
begin
null;
end;
/
prompt --application/shared_components/logic/application_settings
begin
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(10569118014533330)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_comments=>'The default access level given to authenticated users who are not in the access control list'
,p_version_scn=>46218173546909
);
end;
/
prompt --application/shared_components/navigation/tabs/standard
begin
null;
end;
/
prompt --application/shared_components/navigation/tabs/parent
begin
null;
end;
/
prompt --application/shared_components/user_interface/lovs/access_roles
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10897233476535137)
,p_lov_name=>'ACCESS_ROLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>46218173568153
);
end;
/
prompt --application/shared_components/user_interface/lovs/asins_by_sku
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(12127054875198498)
,p_lov_name=>'ASINS_BY_SKU'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    asin || '' (Stock: '' || SUM(qty_available) OVER (PARTITION BY asin) || '')'' as display_value,',
'    asin as return_value',
'FROM amazon_fba_inbound_items',
'WHERE sku = :SKU  -- This bind variable links it to the SKU column',
'  AND qty_available > 0',
'  AND asin IS NOT NULL',
'ORDER BY asin;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_version_scn=>46365816585215
);
end;
/
prompt --application/shared_components/user_interface/lovs/desktop_theme_styles
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10796837195534619)
,p_lov_name=>'DESKTOP THEME STYLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.name d,',
'       s.theme_style_id r',
'  from apex_application_theme_styles s,',
'       apex_application_themes t',
' where s.application_id = :app_id',
'   and t.application_id = s.application_id',
'   and t.theme_number   = s.theme_number',
'   and t.is_current     = ''Yes''',
' order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>46218173560165
);
end;
/
prompt --application/shared_components/user_interface/lovs/email_username_format
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10904721215535140)
,p_lov_name=>'EMAIL_USERNAME_FORMAT'
,p_lov_query=>'.'||wwv_flow_imp.id(10904721215535140)||'.'
,p_location=>'STATIC'
,p_version_scn=>46218173568201
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10905079424535140)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Email Addresses'
,p_lov_return_value=>'EMAIL'
);
end;
/
prompt --application/shared_components/user_interface/lovs/inbound_shipments_order_name
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11606325613517520)
,p_lov_name=>'INBOUND_SHIPMENTS.ORDER_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'INBOUND_SHIPMENTS'
,p_return_column_name=>'ORDER_NO'
,p_display_column_name=>'ORDER_NAME'
,p_default_sort_column_name=>'ORDER_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46287251481429
);
end;
/
prompt --application/shared_components/user_interface/lovs/ordg_products_asin
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11607042356517522)
,p_lov_name=>'ORDG_PRODUCTS.ASIN'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'ORDG_PRODUCTS'
,p_return_column_name=>'SKU'
,p_display_column_name=>'ASIN'
,p_default_sort_column_name=>'ASIN'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46287251481430
);
end;
/
prompt --application/shared_components/user_interface/lovs/skus_with_fba_stock
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(12126313355172268)
,p_lov_name=>'SKUS_WITH_FBA_STOCK'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    sku || '' (Available: '' || SUM(qty_available) OVER (PARTITION BY sku) || '')'' as display_value,',
'    sku as return_value',
'FROM amazon_fba_inbound_items',
'WHERE qty_available > 0',
'ORDER BY sku;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_version_scn=>46365816385696
);
end;
/
prompt --application/shared_components/user_interface/lovs/timeframe_4_weeks
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10816374977535085)
,p_lov_name=>'TIMEFRAME (4 WEEKS)'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val as seconds',
'  from table( apex_util.get_timeframe_lov_data )',
' order by insert_order'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'SECONDS'
,p_display_column_name=>'DISP'
,p_version_scn=>46218173567654
);
end;
/
prompt --application/shared_components/user_interface/lovs/user_theme_preference
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10797535628534620)
,p_lov_name=>'USER_THEME_PREFERENCE'
,p_lov_query=>'.'||wwv_flow_imp.id(10797535628534620)||'.'
,p_location=>'STATIC'
,p_version_scn=>46218173560165
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10797812003534620)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Allow End Users to choose Theme Style'
,p_lov_return_value=>'Yes'
);
end;
/
prompt --application/shared_components/user_interface/lovs/view_as_report_chart
begin
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10863904742535119)
,p_lov_name=>'VIEW_AS_REPORT_CHART'
,p_lov_query=>'.'||wwv_flow_imp.id(10863904742535119)||'.'
,p_location=>'STATIC'
,p_version_scn=>46218173567886
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10864265141535119)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Add Report Page'
,p_lov_return_value=>'REPORT'
,p_lov_template=>'<span class="fa fa-table" aria-hidden="true"></span><span class="u-VisuallyHidden">#DISPLAY_VALUE#</span>'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10864660599535119)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Add Chart Page'
,p_lov_return_value=>'CHART'
,p_lov_template=>'<span class="fa fa-pie-chart" aria-hidden="true"></span><span class="u-VisuallyHidden">#DISPLAY_VALUE#</span>'
);
end;
/
prompt --application/pages/page_groups
begin
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10569463023533331)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10932448636535606)
,p_group_name=>'User Settings'
);
end;
/
prompt --application/comments
begin
null;
end;
/
prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(10561716944533324)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10602877594533465)
,p_short_name=>'Products'
,p_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10918999384535374)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11002184174711323)
,p_short_name=>'Dashboard'
,p_link=>'f?p=&APP_ID.:12:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11594987050517507)
,p_short_name=>'Inbound Costs'
,p_link=>'f?p=&APP_ID.:13:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11657543838899549)
,p_short_name=>'Cost Management'
,p_link=>'f?p=&APP_ID.:16:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12012322450452147)
,p_short_name=>'Sub Accounts Setup'
,p_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12110966967149528)
,p_short_name=>'FBA Sales'
,p_link=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12790366885964129)
,p_short_name=>'AMAZON_ASIN_MASTER'
,p_link=>'f?p=&APP_ID.:24:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12827530504945161)
,p_short_name=>'FBA Arrivals Inbox'
,p_link=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12844831492049973)
,p_short_name=>'ASIN Inventory Dashboard'
,p_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5
);
end;
/
prompt --application/shared_components/navigation/breadcrumbentry
begin
null;
end;
/
prompt --application/shared_components/user_interface/templates/popuplov
begin
null;
end;
/
prompt --application/shared_components/user_interface/themes
begin
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(10562695147533325)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.2'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4072363937200175119
,p_is_locked=>false
,p_current_theme_style_id=>3293430150770310735
,p_default_page_template=>4072355960268175073
,p_default_dialog_template=>2100407606326202693
,p_error_template=>2101157952850466385
,p_printer_friendly_template=>4072355960268175073
,p_login_template=>2101157952850466385
,p_default_button_template=>4072362960822175091
,p_default_region_template=>4072358936313175081
,p_default_chart_template=>4072358936313175081
,p_default_form_template=>4072358936313175081
,p_default_reportr_template=>4072358936313175081
,p_default_tabform_template=>4072358936313175081
,p_default_wizard_template=>4072358936313175081
,p_default_menur_template=>2531463326621247859
,p_default_listr_template=>4072358936313175081
,p_default_irr_template=>2100526641005906379
,p_default_report_template=>2538654340625403440
,p_default_label_template=>1609121967514267634
,p_default_menu_template=>4072363345357175094
,p_default_calendar_template=>4072363550766175095
,p_default_list_template=>4072361143931175087
,p_default_nav_list_template=>2526754704087354841
,p_default_top_nav_list_temp=>2526754704087354841
,p_default_side_nav_list_temp=>2467739217141810545
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>2126429139436695430
,p_default_dialogr_template=>4501440665235496320
,p_default_option_label=>1609121967514267634
,p_default_required_label=>1609122147107268652
,p_default_navbar_list_template=>2847543055748234966
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
end;
/
prompt --application/shared_components/user_interface/theme_style
begin
null;
end;
/
prompt --application/shared_components/user_interface/theme_files
begin
null;
end;
/
prompt --application/shared_components/user_interface/template_opt_groups
begin
null;
end;
/
prompt --application/shared_components/user_interface/template_options
begin
null;
end;
/
prompt --application/shared_components/globalization/language
begin
null;
end;
/
prompt --application/shared_components/globalization/translations
begin
null;
end;
/
prompt --application/shared_components/logic/build_options
begin
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10561116437533324)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>46218173546839
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10565814818533329)
,p_build_option_name=>'Feature: Access Control'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173546900
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>'Incorporate role based user authentication within your application and manage username mappings to application roles.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10565911813533329)
,p_build_option_name=>'Feature: Activity Reporting'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173546900
,p_feature_identifier=>'APPLICATION_ACTIVITY_REPORTING'
,p_build_option_comment=>'Include numerous reports and charts on end user activity.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10566240772533329)
,p_build_option_name=>'Feature: Configuration Options'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173546900
,p_feature_identifier=>'APPLICATION_CONFIGURATION'
,p_build_option_comment=>'Allow application administrators to enable or disable specific functionality, associated with an Oracle APEX build option, from within the application.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10566610449533329)
,p_build_option_name=>'Feature: Theme Style Selection'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173546900
,p_feature_identifier=>'APPLICATION_THEME_STYLE_SELECTION'
,p_build_option_comment=>'Allow administrators to select a default color scheme (theme style) for the application. Administrators can also choose to allow end users to choose their own theme style. '
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10932656006535606)
,p_build_option_name=>'Feature: Push Notifications'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173572406
,p_feature_identifier=>'APPLICATION_PUSH_NOTIFICATIONS'
,p_build_option_comment=>'Allow users to subscribe to push notifications on their devices.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10932927889535606)
,p_build_option_name=>'Feature: User Settings'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>46218173572409
,p_feature_identifier=>'APPLICATION_USER_SETTINGS'
,p_build_option_comment=>'The user settings page is a drawer that links to all user settings pages.'
);
end;
/
prompt --application/shared_components/globalization/messages
begin
null;
end;
/
prompt --application/shared_components/globalization/dyntranslations
begin
null;
end;
/
prompt --application/shared_components/security/authentications/oracle_apex_accounts
begin
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(10561491675533324)
,p_name=>'Oracle APEX Accounts'
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>46218173546850
);
end;
/
prompt --application/user_interfaces/combined_files
begin
null;
end;
/
prompt --application/pages/page_00000
begin
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
end;
/
prompt --application/pages/page_00002
begin
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Products'
,p_alias=>'PRODUCTS'
,p_step_title=>'Products'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>To find data enter a search term into the search dialog, or click on the column headings to limit the records returned.</p>',
'',
'<p>You can perform numerous functions by clicking the <strong>Actions</strong> button. This includes selecting the columns that are displayed / hidden and their display sequence, plus numerous data and format functions.  You can also define additiona'
||'l views of the data using the chart, group by, and pivot options.</p>',
'',
'<p>If you want to save your customizations select report, or click download to unload the data. Enter you email address and time frame under subscription to be sent the data on a regular basis.<p>',
'',
'<p>For additional information click Help at the bottom of the Actions menu.</p> ',
'',
'<p>Click the <strong>Reset</strong> button to reset the interactive report back to the default settings.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10596230415533462)
,p_plug_name=>'Ordg Products'
,p_region_name=>'products_report'
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'ORDG_PRODUCTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Products'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10596393121533462)
,p_name=>'Products'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_chart=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_download=>'N'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:RP:P3_SKU:\#SKU#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(10568353221533330)
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10596393121533462
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10597066655533462)
,p_db_column_name=>'SKU'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Sku'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10597421180533463)
,p_db_column_name=>'ASIN'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'SKU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10598208220533463)
,p_db_column_name=>'IMAGE_URL'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Image URL'
,p_column_html_expression=>'<img src="#IMAGE_URL#" alt="#PRODUCT_NAME#" style="width:100px;height:auto;border-radius:4px;">'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10597860170533463)
,p_db_column_name=>'PRODUCT_NAME'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Product Name'
,p_column_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::P13_FILTER_SKU:#SKU#'
,p_column_linktext=>'#PRODUCT_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10598634694533463)
,p_db_column_name=>'PRODUCT_CONDITION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Product Condition'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10600290987533464)
,p_db_column_name=>'TOTAL_AVAILABLE_QTY'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Total Available Qty'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10600695540533464)
,p_db_column_name=>'LAST_UPDATED'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10711725840534572)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107118'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IMAGE_URL:ASIN:PRODUCT_NAME:PRODUCT_CONDITION:TOTAL_AVAILABLE_QTY:'
,p_sort_column_1=>'SKU'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10602370343533465)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10601456707533464)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10596230415533462)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10601966551533465)
,p_event_id=>wwv_flow_imp.id(10601456707533464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10596230415533462)
);
end;
/
prompt --application/pages/page_00003
begin
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Sub Accounts Setup'
,p_alias=>'SUB-ACCOUNTS-SETUP'
,p_step_title=>'Sub Accounts Setup'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12011862515452144)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12012548766452148)
,p_plug_name=>'Sub Accounts Setup'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'PLATFORM_SUB_ACCOUNTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Sub Accounts Setup'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12013892934452152)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12014388134452152)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12015329804452154)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12016346751452156)
,p_name=>'PLATFORM_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PLATFORM_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Platform Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT selling_platform as d, selling_platform as r',
'FROM shipping_orders',
'WHERE selling_platform IS NOT NULL',
'ORDER BY 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12017366048452156)
,p_name=>'SUB_ACCOUNT_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUB_ACCOUNT_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Sub Account Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12013045593452149)
,p_internal_uid=>12013045593452149
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12013437438452150)
,p_interactive_grid_id=>wwv_flow_imp.id(12013045593452149)
,p_static_id=>'120135'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12013626920452150)
,p_report_id=>wwv_flow_imp.id(12013437438452150)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12014791486452152)
,p_view_id=>wwv_flow_imp.id(12013626920452150)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(12014388134452152)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12015790063452154)
,p_view_id=>wwv_flow_imp.id(12013626920452150)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12015329804452154)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12016720268452156)
,p_view_id=>wwv_flow_imp.id(12013626920452150)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12016346751452156)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12017759155452156)
,p_view_id=>wwv_flow_imp.id(12013626920452150)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12017366048452156)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12018330036452159)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12012548766452148)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Sub Accounts Setup - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12018330036452159
);
end;
/
prompt --application/pages/page_00004
begin
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'FBA Inbox'
,p_alias=>'FBA-INBOX'
,p_step_title=>'FBA Inbox'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12188812432452830)
,p_plug_name=>'Pending ASIN Assignment'
,p_title=>'Pending ASIN Assignment'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    id, ',
'    order_no, ',
'    sku, ',
'    qty_shipped as qty_received, ',
'    per_unit_cost, ',
'    asin,',
'    TOTAL_LINE_COST',
'FROM amazon_fba_inbound_items ',
'WHERE asin IS NULL;'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Pending ASIN Assignment'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189072845452832)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189176780452833)
,p_name=>'ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Order No'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189239803452834)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189397250452835)
,p_name=>'QTY_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_RECEIVED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189482704452836)
,p_name=>'PER_UNIT_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PER_UNIT_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Per Unit Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189533939452837)
,p_name=>'ASIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASIN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Asin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''('' || asin || '')'' || product_name AS d, ',
'       asin AS r ',
'FROM amazon_asin_master ',
'WHERE sku = :SKU'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_null_text=>'- Select ASIN -'
,p_lov_cascade_parent_items=>'SKU'
,p_ajax_items_to_submit=>'SKU'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189661480452838)
,p_name=>'TOTAL_LINE_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_LINE_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Line Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189755111452839)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12189861369452840)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12188984850452831)
,p_internal_uid=>12188984850452831
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12829310193997041)
,p_interactive_grid_id=>wwv_flow_imp.id(12188984850452831)
,p_static_id=>'128294'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12829592134997042)
,p_report_id=>wwv_flow_imp.id(12829310193997041)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12830072455997043)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12189072845452832)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12830985794997046)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12189176780452833)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12831828521997048)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12189239803452834)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12832728221997049)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12189397250452835)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12833661666997051)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12189482704452836)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12834552408997052)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(12189533939452837)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12836164840009525)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(12189661480452838)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12840179961035154)
,p_view_id=>wwv_flow_imp.id(12829592134997042)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(12189755111452839)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12827029275945158)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12855746950150806)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12827029275945158)
,p_button_name=>'FETCH_ARRIVALS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Fetch New Arrivals'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12189970791452841)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12188812432452830)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'New - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12189970791452841
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12855834090150807)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sync New Prep Orders'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    FOR rec IN (',
'        SELECT order_no ',
'        FROM shipping_orders ',
'        WHERE service_type = ''FBA'' ',
'          AND order_no NOT IN (SELECT order_no FROM amazon_fba_inbounds)',
'    ) LOOP',
'        sync_order_to_fba(p_order_no => rec.order_no);',
'    END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(12855746950150806)
,p_internal_uid=>12855834090150807
);
end;
/
prompt --application/pages/page_00005
begin
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'ASIN Inventory Dashboard'
,p_alias=>'ASIN-INVENTORY-DASHBOARD'
,p_step_title=>'ASIN Inventory Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12190022250452842)
,p_plug_name=>'Available FBA Inventory'
,p_title=>'Available FBA Inventory'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    m.asin,',
'    m.sku,',
'    m.product_name,',
'    MAX(TO_CHAR(p.image_url)) AS image_url,',
'    SUM(i.qty_available) AS total_available_qty,',
'    SUM(i.qty_available * i.per_unit_cost) AS total_available_value,',
'    COUNT(i.id) AS total_inbound_batches',
'FROM amazon_fba_inbound_items i',
'JOIN amazon_asin_master m ON i.asin = m.asin',
'LEFT JOIN ordg_products p ON m.sku = p.sku',
'WHERE i.qty_available > 0',
'GROUP BY ',
'    m.asin, ',
'    m.sku, ',
'    m.product_name'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Available FBA Inventory'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190280880452844)
,p_name=>'ASIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASIN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Asin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190326424452845)
,p_name=>'PRODUCT_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRODUCT_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Product Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190438926452846)
,p_name=>'TOTAL_AVAILABLE_QTY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_AVAILABLE_QTY'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Available Qty'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190556682452847)
,p_name=>'TOTAL_INBOUND_BATCHES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_INBOUND_BATCHES'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Inbound Batches'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12855906735150808)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856024509150809)
,p_name=>'IMAGE_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_URL'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'IMAGE'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'html_expression', '<img src="&IMAGE_URL." alt="Product" style="height: 50px; border-radius: 4px; object-fit: contain;">')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857955552150828)
,p_name=>'TOTAL_AVAILABLE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_AVAILABLE_VALUE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Available Value'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12190146086452843)
,p_internal_uid=>12190146086452843
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12845956113125773)
,p_interactive_grid_id=>wwv_flow_imp.id(12190146086452843)
,p_static_id=>'128460'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12846132962125773)
,p_report_id=>wwv_flow_imp.id(12845956113125773)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12846668754125774)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12190280880452844)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12847547679125775)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12190326424452845)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>286.27099999999996
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12848460143125777)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12190438926452846)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12849397608125778)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(12190556682452847)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12892196119874056)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12855906735150808)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12893010922874058)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12856024509150809)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>87.27099999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13071107918239603)
,p_view_id=>wwv_flow_imp.id(12846132962125773)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(12857955552150828)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12844325240049973)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12856236566150811)
,p_plug_name=>'Inbound Batch Details'
,p_title=>'Inbound Batch Details'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    i.id,',
'    i.asin,',
'    i.order_no, ',
'    i.sku, ',
'    i.qty_received, ',
'    i.qty_available, ',
'    i.per_unit_cost,',
'    (i.qty_available * i.per_unit_cost) as total_asset_value,',
'    (i.qty_received * i.per_unit_cost) as received_value,',
'    s.date_shipped AS date_received -- Pulling the date from the prep table',
'FROM amazon_fba_inbound_items i',
'JOIN shipping_orders s ON i.order_no = s.order_no',
'WHERE i.qty_received > 0'))
,p_plug_source_type=>'NATIVE_IG'
,p_master_region_id=>wwv_flow_imp.id(12190022250452842)
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Inbound Batch Details'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856402254150813)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856504417150814)
,p_name=>'ASIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_parent_column_id=>wwv_flow_imp.id(12190280880452844)
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856697045150815)
,p_name=>'ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Order No'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856783209150816)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856844048150817)
,p_name=>'QTY_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_RECEIVED'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qty Received'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856932256150818)
,p_name=>'QTY_AVAILABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_AVAILABLE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qty Available'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857049184150819)
,p_name=>'PER_UNIT_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PER_UNIT_COST'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Per Unit Cost'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857159976150820)
,p_name=>'TOTAL_ASSET_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_ASSET_VALUE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Available Value'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857772419150826)
,p_name=>'DATE_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_RECEIVED'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Date Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857865854150827)
,p_name=>'RECEIVED_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RECEIVED_VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Received Value'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12856372259150812)
,p_internal_uid=>12856372259150812
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12903313022836287)
,p_interactive_grid_id=>wwv_flow_imp.id(12856372259150812)
,p_static_id=>'129034'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12903531083836287)
,p_report_id=>wwv_flow_imp.id(12903313022836287)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12904001618836288)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12856402254150813)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12904932366836290)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12856504417150814)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12905842733836292)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12856697045150815)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>87.05199999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12906732733836294)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12856783209150816)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>81.05199999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12907667185836295)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(12856844048150817)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>109.05199999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12908597676836297)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(12856932256150818)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>112.042
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12909469924836298)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(12857049184150819)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>74.7188
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12910344377836299)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(12857159976150820)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>109.6663332538605
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12935476619044494)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12857772419150826)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>123.042
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13069359397206802)
,p_view_id=>wwv_flow_imp.id(12903531083836287)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(12857865854150827)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>108.36500000000001
);
end;
/
prompt --application/pages/page_00007
begin
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Shipping Order'
,p_alias=>'SHIPPING-ORDER'
,p_page_mode=>'MODAL'
,p_step_title=>'Shipping Order'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(10568353221533330)
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10623776335534387)
,p_plug_name=>'Shipping Order'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SHIPPING_ORDERS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10635092651534392)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10635464680534393)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10635092651534392)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10636831299534393)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10635092651534392)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10637278854534393)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10635092651534392)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10637664243534394)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10635092651534392)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10624084680534387)
,p_name=>'P7_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ID'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10624451977534388)
,p_name=>'P7_ORDER_NO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Order No'
,p_source=>'ORDER_NO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_label_alignment=>'RIGHT'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10624894480534388)
,p_name=>'P7_ORDER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Order Name'
,p_source=>'ORDER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10625243580534388)
,p_name=>'P7_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10625657264534388)
,p_name=>'P7_TOTAL_QUANTITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Total Quantity'
,p_source=>'TOTAL_QUANTITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10626024311534388)
,p_name=>'P7_TOTAL_SKU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Total Sku'
,p_source=>'TOTAL_SKU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10626447663534389)
,p_name=>'P7_SELLING_PLATFORM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Selling Platform'
,p_source=>'SELLING_PLATFORM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10626827672534389)
,p_name=>'P7_CLIENT_COMMENT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Client Comment'
,p_source=>'CLIENT_COMMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10627252116534389)
,p_name=>'P7_DATE_CREATED'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Date Created'
,p_source=>'DATE_CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10628027722534389)
,p_name=>'P7_DATE_SHIPPED'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Date Shipped'
,p_source=>'DATE_SHIPPED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10628818355534390)
,p_name=>'P7_INBOUND_NUMBER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Inbound Number'
,p_source=>'INBOUND_NUMBER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10629268840534390)
,p_name=>'P7_COST_PRICE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cost Price'
,p_source=>'COST_PRICE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10629694665534390)
,p_name=>'P7_DETAILS_FETCHED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Details Fetched'
,p_source=>'DETAILS_FETCHED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10630030549534390)
,p_name=>'P7_CREATED_AT'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_item_source_plug_id=>wwv_flow_imp.id(10623776335534387)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10627797992534389)
,p_validation_name=>'P7_DATE_CREATED must be timestamp'
,p_validation_sequence=>80
,p_validation=>'P7_DATE_CREATED'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(10627252116534389)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10628548173534390)
,p_validation_name=>'P7_DATE_SHIPPED must be timestamp'
,p_validation_sequence=>90
,p_validation=>'P7_DATE_SHIPPED'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(10628027722534389)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10630570260534391)
,p_validation_name=>'P7_CREATED_AT must be timestamp'
,p_validation_sequence=>130
,p_validation=>'P7_CREATED_AT'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(10630030549534390)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10635538102534393)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10635464680534393)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10636383384534393)
,p_event_id=>wwv_flow_imp.id(10635538102534393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10638479104534394)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10623776335534387)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Shipping Order'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10638479104534394
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10638833581534394)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>10638833581534394
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10638062391534394)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(10623776335534387)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Shipping Order'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10638062391534394
);
end;
/
prompt --application/pages/page_00008
begin
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Inbound Management'
,p_alias=>'INBOUND-MANAGEMENT'
,p_step_title=>'Inbound Management'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10649512738534400)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10650392859534400)
,p_plug_name=>'Inbound Shipments'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ORDER_NO,',
'       ORDER_NAME,',
'       STATUS,',
'       DATE_CREATED,',
'       DATE_RECEIVED,',
'       CLIENT_COMMENT,',
'       DETAILS_FETCHED,',
'       CREATED_AT,',
'(SELECT sum(NVL(QTY_RECEIVED, 0) * NVL(COST_PRICE, 0))',
'FROM INBOUND_STOCK s',
'where s.INBOUND_ORDER_NO = ORDER_NO ) as total_cost,',
'(SELECT sum(NVL(QTY_AVAILABLE, 0) * NVL(COST_PRICE, 0))',
'FROM INBOUND_STOCK s',
'where s.INBOUND_ORDER_NO = ORDER_NO ) as Available_cost',
'  FROM INBOUND_SHIPMENTS',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'INBOUND_SHIPMENTS'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10653055695534402)
,p_name=>'ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'Order No'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10654064704534403)
,p_name=>'ORDER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Order Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10655007698534403)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10656089641534404)
,p_name=>'DATE_CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_CREATED'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Date Created'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'FUTURE'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'SEQUENCE'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10657052454534404)
,p_name=>'DATE_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_RECEIVED'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Date Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10658058700534405)
,p_name=>'CLIENT_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CLIENT_COMMENT'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Client Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10964378457911120)
,p_name=>'DETAILS_FETCHED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETAILS_FETCHED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10964462841911121)
,p_name=>'CREATED_AT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_AT'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10964726410911124)
,p_name=>'TOTAL_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10964816743911125)
,p_name=>'AVAILABLE_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVAILABLE_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Available Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(10650813117534401)
,p_internal_uid=>10650813117534401
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(10651243191534401)
,p_interactive_grid_id=>wwv_flow_imp.id(10650813117534401)
,p_static_id=>'106513'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>10
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(10651487269534401)
,p_report_id=>wwv_flow_imp.id(10651243191534401)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10653483475534403)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(10653055695534402)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10654476818534403)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(10654064704534403)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10655467579534404)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(10655007698534403)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10656455829534404)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(10656089641534404)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10657432655534404)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(10657052454534404)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10658417914534405)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(10658058700534405)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11421345280562301)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(10964378457911120)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11422269399562304)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(10964462841911121)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11436833052873363)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(10964726410911124)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11439538875891998)
,p_view_id=>wwv_flow_imp.id(10651487269534401)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(10964816743911125)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11836969167230824)
,p_plug_name=>'Inbound Stock'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT s.ID,',
'       s.INBOUND_ORDER_NO,',
'       s.SKU,',
'       s.PRODUCT_NAME,',
'       s.QTY_RECEIVED,',
'       s.QTY_AVAILABLE,',
'       s.COST_PRICE,',
'       s.THIRD_PARTY_COSTS,',
'       s.TOTAL_COST,',
'       p.IMAGE_URL,',
'       (NVL(s.QTY_RECEIVED, 0) * NVL(s.TOTAL_COST, 0)) AS Received_cost,',
'       (NVL(s.qty_available, 0) * NVL(s.TOTAL_COST, 0)) AS available_cost',
'FROM INBOUND_STOCK s',
'JOIN ORDG_PRODUCTS p ON s.SKU = p.SKU'))
,p_plug_source_type=>'NATIVE_IG'
,p_master_region_id=>wwv_flow_imp.id(10650392859534400)
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837148804230826)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837279262230827)
,p_name=>'INBOUND_ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INBOUND_ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_parent_column_id=>wwv_flow_imp.id(10653055695534402)
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837319799230828)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837417697230829)
,p_name=>'PRODUCT_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRODUCT_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Product Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837510341230830)
,p_name=>'QTY_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_RECEIVED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837663292230831)
,p_name=>'QTY_AVAILABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_AVAILABLE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Available'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837784110230832)
,p_name=>'COST_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COST_PRICE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cost Price'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_stretch=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837809193230833)
,p_name=>'THIRD_PARTY_COSTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'THIRD_PARTY_COSTS'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Other Costs'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>110
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11837968981230834)
,p_name=>'TOTAL_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11838078306230835)
,p_name=>'IMAGE_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_URL'
,p_data_type=>'CLOB'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'Image Url'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'html_expression', '<img src="&IMAGE_URL." alt="Product" style="height: 50px; border-radius: 4px; object-fit: contain;">')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11838249920230837)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'N',
  'hide_control', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11838855882230843)
,p_name=>'RECEIVED_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RECEIVED_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Received Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11838960204230844)
,p_name=>'AVAILABLE_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVAILABLE_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Available Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(11837061085230825)
,p_internal_uid=>11837061085230825
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(11963085331742377)
,p_interactive_grid_id=>wwv_flow_imp.id(11837061085230825)
,p_static_id=>'119631'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(11963239118742378)
,p_report_id=>wwv_flow_imp.id(11963085331742377)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11963785324742379)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(11837148804230826)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11964633881742380)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(11837279262230827)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11965525447742382)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(11837319799230828)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>67.135
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11966435697742383)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(11837417697230829)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>224.135
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11967316237742384)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(11837510341230830)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>95.1354
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11968235353742385)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(11837663292230831)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>96.1354
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11969113718742387)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(11837784110230832)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11970099470742388)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(11837809193230833)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>84.1354
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11970903764742389)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(11837968981230834)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11971881074742391)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(11838078306230835)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>72.135
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12000750437179679)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(11838855882230843)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>101.1354
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12001625446179680)
,p_view_id=>wwv_flow_imp.id(11963239118742378)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(11838960204230844)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10649942697534400)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10649512738534400)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11838306217230838)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(11836969167230824)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Inbound Stock - Save Interactive Grid Data'
,p_attribute_01=>'TABLE'
,p_attribute_03=>'INBOUND_STOCK'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11838306217230838
);
end;
/
prompt --application/pages/page_00009
begin
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Outbound Management'
,p_alias=>'OUTBOUND-MANAGEMENT'
,p_step_title=>'Outbound Management'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10679252350534547)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10680064890534547)
,p_plug_name=>'Shipping Orders'
,p_title=>'Orders Shipped'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc:t-Form--labelsAbove'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    main.*,',
'    -- Profit Calculation: Sale Price minus the calculated Total Order Cost',
'    (NVL(main.SALE_PRICE, 0) - main.total_order_cost) AS profit',
'FROM (',
'    SELECT ',
'        o.id,',
'        o.order_no,',
'        o.order_name,      ',
'        o.status,',
'        o.CLIENT_COMMENT,',
'        o.date_shipped,      ',
'        o.TOTAL_QUANTITY,',
'        o.TOTAL_SKU,',
'        o.SELLING_PLATFORM,',
'        o.SALE_PRICE,',
'        o.service_type,',
'        o.sub_account,',
'',
'        -- Corrected Total Order Cost',
'        -- Notice the Order-level costs are now added OUTSIDE the SUM()',
'        (',
'            (',
'                SELECT NVL(SUM((i.qty_shipped * NVL(stk.cost_price, 0)) + NVL(i.prep_cost, 0)), 0)',
'                FROM shipping_order_items i',
'                LEFT JOIN inbound_stock stk ',
'                    ON i.sku = stk.sku ',
'                    AND i.inbound_source_number LIKE ''%'' || stk.inbound_order_no',
'                WHERE i.shipping_order_no = o.order_no',
'            ) ',
'            + NVL(o.SHIPPING_COST, 0) ',
'            + NVL(o.PACKAGING_COST, 0) ',
'            + NVL(o.OTHER_COST, 0)',
'            + CASE ',
'                WHEN o.service_type = ''FBM'' THEN (NVL(o.SALE_PRICE, 0) * 0.18)',
'                ELSE 0 ',
'              END',
'        ) AS total_order_cost',
'',
'    FROM shipping_orders o',
'    -- WHERE NVL(o.service_type, ''Standard'') != ''FBA''',
') main'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Orders Shipped'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10681348971534548)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'N',
  'hide_control', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10682849618534549)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10683836530534549)
,p_name=>'ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10684807479534550)
,p_name=>'ORDER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Order Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10685803654534550)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10686834970534551)
,p_name=>'TOTAL_QUANTITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_QUANTITY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Quantity'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10687803471534551)
,p_name=>'TOTAL_SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_SKU'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10691816837534553)
,p_name=>'DATE_SHIPPED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_SHIPPED'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Date Shipped'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10965249762911129)
,p_name=>'TOTAL_ORDER_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_ORDER_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11450353412479714)
,p_name=>'SERVICE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SERVICE_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Order Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT service_type as d, service_type as r ',
'FROM prep_rate_history ',
'ORDER BY 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'- SELECT -'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11453429527479745)
,p_name=>'SELLING_PLATFORM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SELLING_PLATFORM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Platform'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11835778125230812)
,p_name=>'SALE_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SALE_PRICE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Sale Price'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11836031063230815)
,p_name=>'PROFIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROFIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Profit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11839076195230845)
,p_name=>'SUB_ACCOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUB_ACCOUNT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Sub Account'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_is_required=>false
,p_max_length=>50
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT sub_account_name as d, sub_account_name as r',
'FROM platform_sub_accounts',
'WHERE platform_name = :SELLING_PLATFORM'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'SELLING_PLATFORM'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12858047929150829)
,p_name=>'CLIENT_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CLIENT_COMMENT'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'CLOB'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Client Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(10680590796534548)
,p_internal_uid=>10680590796534548
,p_is_editable=>true
,p_edit_operations=>'u'
,p_update_authorization_scheme=>wwv_flow_imp.id(10568353221533330)
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(10680986322534548)
,p_interactive_grid_id=>wwv_flow_imp.id(10680590796534548)
,p_static_id=>'106810'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>10
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(10681129767534548)
,p_report_id=>wwv_flow_imp.id(10680986322534548)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10683291990534549)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(10682849618534549)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10684282993534550)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(10683836530534549)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10685279651534550)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(10684807479534550)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118.125
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10686296006534550)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(10685803654534550)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10687224362534551)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(10686834970534551)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10688283535534551)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(10687803471534551)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70.7292
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10692293280534553)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(10691816837534553)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11440803831005278)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(10965249762911129)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>74.385
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11790513807410972)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(11450353412479714)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>82.385
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11825661636807628)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(11453429527479745)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>66.385
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11897430136255440)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(11835778125230812)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>74.385
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11931596257646720)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(11836031063230815)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12009822877103230)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(11839076195230845)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13075163635195938)
,p_view_id=>wwv_flow_imp.id(10681129767534548)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(12858047929150829)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10697149573534564)
,p_plug_name=>'Shipping Order Items'
,p_region_name=>'items_grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    i.id,',
'    i.shipping_order_no,',
'    i.sku,',
'    p.product_name,',
'    i.prep_cost, ',
'    i.inbound_source_number,',
'    i.qty_shipped,',
'    ',
'    -- Fetch Unit Cost (Dynamic from Inbound Stock)',
'    s.cost_price as unit_cost,',
'    ',
'    -- Calculate Total Line Cost (Updated Logic)',
'    -- Formula: (Qty * Cost) + Prep Fee',
'    ((i.qty_shipped * NVL(s.cost_price, 0)) + NVL(i.prep_cost, 0)) as total_line_cost',
'',
'FROM shipping_order_items i',
'LEFT JOIN ordg_products p ON i.sku = p.sku',
'-- The Fix: Use LIKE to match ''2697'' inside ''PREPME-P65-2697''',
'LEFT JOIN inbound_stock s ',
'    ON i.sku = s.sku ',
'    AND i.inbound_source_number LIKE ''%'' || s.inbound_order_no'))
,p_plug_source_type=>'NATIVE_IG'
,p_master_region_id=>wwv_flow_imp.id(10680064890534547)
,p_prn_page_header=>'SHIPPING_ORDER_ITEMS'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10698411301534565)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'N',
  'hide_control', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10699967660534566)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10700972601534566)
,p_name=>'SHIPPING_ORDER_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SHIPPING_ORDER_NO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'Shipping Order No'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_parent_column_id=>wwv_flow_imp.id(10683836530534549)
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10701949704534567)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10703921864534568)
,p_name=>'PRODUCT_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRODUCT_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Product Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10704923440534568)
,p_name=>'QTY_SHIPPED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_SHIPPED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Shipped'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10705902885534568)
,p_name=>'INBOUND_SOURCE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INBOUND_SOURCE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Inbound Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10965327475911130)
,p_name=>'UNIT_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIT_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Unit Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10965429503911131)
,p_name=>'TOTAL_LINE_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_LINE_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Line Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11450170497479712)
,p_name=>'PREP_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PREP_COST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Prep Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(10697651207534565)
,p_internal_uid=>10697651207534565
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(10698070461534565)
,p_interactive_grid_id=>wwv_flow_imp.id(10697651207534565)
,p_static_id=>'106981'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>10
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(10698262963534565)
,p_report_id=>wwv_flow_imp.id(10698070461534565)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10700366491534566)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(10699967660534566)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10701328451534566)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(10700972601534566)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10702310330534567)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(10701949704534567)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120.5208
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10704396600534568)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(10703921864534568)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>288.521
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10705360345534568)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(10704923440534568)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>104.52099999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10706387348534569)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(10705902885534568)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150.073
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11446005758028915)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(10965327475911130)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88.5208
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11446960211028917)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(10965429503911131)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100.0416669845581
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11676350929204082)
,p_view_id=>wwv_flow_imp.id(10698262963534565)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(11450170497479712)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>85.4688
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11450403902479715)
,p_plug_name=>'Order Totals'
,p_title=>'Order Totals'
,p_parent_plug_id=>wwv_flow_imp.id(10697149573534564)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11836426491230819)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_button_name=>'SAVE_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(10568353221533330)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10679685627534547)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10679252350534547)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'EDIT'
,p_security_scheme=>wwv_flow_imp.id(10568353221533330)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10966213283911139)
,p_name=>'P9_PREP_RATE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10680064890534547)
,p_use_cache_before_default=>'NO'
,p_source=>'PREP_RATE_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11450542342479716)
,p_name=>'P9_SUBTOTAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_prompt=>'Subtotal'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_read_only_when_type=>'NEVER'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11450676225479717)
,p_name=>'P9_SHIPPING_COST'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_prompt=>'Shipping Cost'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11450749706479718)
,p_name=>'P9_PACKAGING_COST'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_prompt=>'Packaging Cost'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11450819420479719)
,p_name=>'P9_OTHER_COST'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_prompt=>'Other Cost'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11450903933479720)
,p_name=>'P9_GRAND_TOTAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_prompt=>'Grand Total'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'NEVER'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11451207974479723)
,p_name=>'P9_SELECTED_ORDER_NO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(11450403902479715)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10966076768911137)
,p_name=>'Set Rate ID on Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_SERVICE_TYPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10966120295911138)
,p_event_id=>wwv_flow_imp.id(10966076768911137)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'action'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P9_PREP_RATE_ID := get_prep_rate(:P9_SERVICE_TYPE, NVL(:P9_DATE_CREATED, SYSDATE));'
,p_attribute_02=>'P9_SERVICE_TYPE'
,p_attribute_03=>'P9_PREP_RATE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11451788765479728)
,p_name=>'Recalculate Totals'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_SHIPPING_COST,P9_PACKAGING_COST,P9_OTHER_COST'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11451820523479729)
,p_event_id=>wwv_flow_imp.id(11451788765479728)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Get values (default to 0 if empty)',
'var sub   = parseFloat($v("P9_SUBTOTAL")) || 0;',
'var ship  = parseFloat($v("P9_SHIPPING_COST")) || 0;',
'var pack  = parseFloat($v("P9_PACKAGING_COST")) || 0;',
'var other = parseFloat($v("P9_OTHER_COST")) || 0;',
'',
'// Sum',
'var total = sub + ship + pack + other;',
'',
'// Set Grand Total (Fixed to 2 decimals)',
'$s("P9_GRAND_TOTAL", total.toFixed(2));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11451951320479730)
,p_name=>'Save Costs to DB'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_SHIPPING_COST,P9_PACKAGING_COST,P9_OTHER_COST'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11452058246479731)
,p_event_id=>wwv_flow_imp.id(11451951320479730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE shipping_orders',
'    SET shipping_cost  = :P9_SHIPPING_COST,',
'        packaging_cost = :P9_PACKAGING_COST,',
'        other_cost     = :P9_OTHER_COST',
'    WHERE order_no = :P9_SELECTED_ORDER_NO;',
'',
'    COMMIT; -- Optional in APEX, but good for certainty here',
'END;'))
,p_attribute_02=>'P9_SELECTED_ORDER_NO, P9_SHIPPING_COST, P9_PACKAGING_COST, P9_OTHER_COST'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11452497159479735)
,p_name=>'Auto-Refresh on Save'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10680064890534547)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11452515673479736)
,p_event_id=>wwv_flow_imp.id(11452497159479735)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11450403902479715)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11452616172479737)
,p_event_id=>wwv_flow_imp.id(11452497159479735)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Force the grid to re-select the current row so the totals reload',
'var grid = apex.region("shipping_orders").widget().interactiveGrid("getViews", "grid");',
'grid.setSelectedRecords(grid.getSelectedRecords());'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11453102781479742)
,p_name=>'Load Order Totals (Server)'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10680064890534547)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11453277819479743)
,p_event_id=>wwv_flow_imp.id(11453102781479742)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_SELECTED_ORDER_NO'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Get the ORDER_NO from the selected row',
'// Make sure your grid column is named ORDER_NO (check the column name in the tree if unsure)',
'this.data.model.getValue(this.data.selectedRecords[0], "ORDER_NO")'))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11453357524479744)
,p_event_id=>wwv_flow_imp.id(11453102781479742)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_subtotal NUMBER := 0;',
'BEGIN',
'    -- 1. Calculate Subtotal',
'    -- We use the exact same JOIN logic as your report to ensure the math matches',
'    SELECT SUM(',
'        (NVL(i.qty_shipped, 0) * NVL(s.cost_price, 0)) + NVL(i.prep_cost, 0)',
'    )',
'    INTO l_subtotal',
'    FROM shipping_order_items i',
'    -- Join to Stock using your custom "LIKE" logic',
'    LEFT JOIN inbound_stock s ',
'        ON i.sku = s.sku ',
'        AND i.inbound_source_number LIKE ''%'' || s.inbound_order_no',
'    WHERE i.shipping_order_no = :P9_SELECTED_ORDER_NO;',
'',
'    :P9_SUBTOTAL := NVL(l_subtotal, 0);',
'',
'    -- 2. Fetch Extra Costs (Shipping, Packaging, Other)',
'    SELECT NVL(shipping_cost, 0), NVL(packaging_cost, 0), NVL(other_cost, 0)',
'    INTO :P9_SHIPPING_COST, :P9_PACKAGING_COST, :P9_OTHER_COST',
'    FROM shipping_orders',
'    WHERE order_no = :P9_SELECTED_ORDER_NO;',
'',
'    -- 3. Calculate Grand Total',
'    :P9_GRAND_TOTAL := :P9_SUBTOTAL + :P9_SHIPPING_COST + :P9_PACKAGING_COST + :P9_OTHER_COST;',
'',
'EXCEPTION WHEN NO_DATA_FOUND THEN',
'    -- Fallback for empty orders',
'    :P9_SUBTOTAL := 0;',
'    :P9_GRAND_TOTAL := 0;',
'END;'))
,p_attribute_02=>'P9_SELECTED_ORDER_NO'
,p_attribute_03=>'P9_SUBTOTAL, P9_SHIPPING_COST, P9_PACKAGING_COST, P9_OTHER_COST, P9_GRAND_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10696884924534555)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10680064890534547)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'SHIPPING_ORDERS - Save Interactive Grid Data'
,p_attribute_01=>'TABLE'
,p_attribute_03=>'SHIPPING_ORDERS'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10679685627534547)
,p_internal_uid=>10696884924534555
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10706959141534569)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10697149573534564)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'SHIPPING_ORDER_ITEMS - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10679685627534547)
,p_internal_uid=>10706959141534569
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11839284036230847)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10680064890534547)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sync FBA Transfer'
,p_process_sql_clob=>'sync_order_to_fba(:ORDER_NO);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11839284036230847
);
end;
/
prompt --application/pages/page_00010
begin
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Financial Overview'
,p_alias=>'FINANCIAL-OVERVIEW'
,p_step_title=>'Financial Overview'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10940692922574625)
,p_plug_name=>'Chart 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10941071401574626)
,p_region_id=>wwv_flow_imp.id(10940692922574625)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10942754022574626)
,p_chart_id=>wwv_flow_imp.id(10941071401574626)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TRUNC(DATE_CREATED, ''MM'') as label,',
'       SUM(COST_PRICE) as value',
'FROM SHIPPING_ORDERS',
'GROUP BY TRUNC(DATE_CREATED, ''MM'')',
'ORDER BY 1;'))
,p_max_row_count=>20
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10941527771574626)
,p_chart_id=>wwv_flow_imp.id(10941071401574626)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10942156360574626)
,p_chart_id=>wwv_flow_imp.id(10941071401574626)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10943354440574627)
,p_plug_name=>'Chart 2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10943796384574627)
,p_region_id=>wwv_flow_imp.id(10943354440574627)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10944270942574627)
,p_chart_id=>wwv_flow_imp.id(10943796384574627)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PRODUCT_NAME as label,',
'       SUM(QTY_AVAILABLE) as value',
'FROM INBOUND_STOCK',
'GROUP BY PRODUCT_NAME',
'HAVING SUM(QTY_AVAILABLE) > 0;'))
,p_max_row_count=>20
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10963127715911108)
,p_plug_name=>'New'
,p_title=>'System Status'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''Active Shipments'' as title, COUNT(*) as measure, ''fa-truck'' as icon',
'FROM INBOUND_SHIPMENTS WHERE STATUS = ''Pending''',
'UNION ALL',
'SELECT ''Orders Today'' as title, COUNT(*) as measure, ''fa-shopping-cart'' as icon',
'FROM SHIPPING_ORDERS WHERE TRUNC(CREATED_AT) = TRUNC(SYSDATE)'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10963252483911109)
,p_region_id=>wwv_flow_imp.id(10963127715911108)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'MEASURE'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ICON'
,p_media_adv_formatting=>false
);
end;
/
prompt --application/pages/page_00011
begin
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Financial Overview'
,p_alias=>'FINANCIAL-OVERVIEW1'
,p_step_title=>'Financial Overview'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10952856485889721)
,p_plug_name=>'Chart 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10953208342889723)
,p_region_id=>wwv_flow_imp.id(10952856485889721)
,p_chart_type=>'area'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10954942114889725)
,p_chart_id=>wwv_flow_imp.id(10953208342889723)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Label 1'' label, 30 value from sys.dual',
'union all',
'select ''Label 2'' label, 20 value from sys.dual',
'union all',
'select ''Label 3'' label, 34 value from sys.dual',
'union all',
'select ''Label 4'' label, 6  value from sys.dual',
'union all',
'select ''Label 5'' label, 10 value from sys.dual'))
,p_max_row_count=>20
,p_series_type=>'area'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>false
,p_items_label_position=>'auto'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10953707071889724)
,p_chart_id=>wwv_flow_imp.id(10953208342889723)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10954360934889724)
,p_chart_id=>wwv_flow_imp.id(10953208342889723)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10955574755889725)
,p_plug_name=>'Chart 2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10955950819889725)
,p_region_id=>wwv_flow_imp.id(10955574755889725)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10956486501889726)
,p_chart_id=>wwv_flow_imp.id(10955950819889725)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Label 1'' label, 30 value from sys.dual',
'union all',
'select ''Label 2'' label, 20 value from sys.dual',
'union all',
'select ''Label 3'' label, 34 value from sys.dual',
'union all',
'select ''Label 4'' label, 6  value from sys.dual',
'union all',
'select ''Label 5'' label, 10 value from sys.dual'))
,p_max_row_count=>20
,p_series_type=>'pie'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10957062086889726)
,p_plug_name=>'Chart 3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10957411303889726)
,p_region_id=>wwv_flow_imp.id(10957062086889726)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10959191252889727)
,p_chart_id=>wwv_flow_imp.id(10957411303889726)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Label 1'' label, 30 value from sys.dual',
'union all',
'select ''Label 2'' label, 20 value from sys.dual',
'union all',
'select ''Label 3'' label, 34 value from sys.dual',
'union all',
'select ''Label 4'' label, 6  value from sys.dual',
'union all',
'select ''Label 5'' label, 10 value from sys.dual'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>false
,p_items_label_position=>'auto'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10957906928889726)
,p_chart_id=>wwv_flow_imp.id(10957411303889726)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10958581234889726)
,p_chart_id=>wwv_flow_imp.id(10957411303889726)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10959706350889727)
,p_plug_name=>'Chart 4'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10960187931889727)
,p_region_id=>wwv_flow_imp.id(10959706350889727)
,p_chart_type=>'line'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10961836546889728)
,p_chart_id=>wwv_flow_imp.id(10960187931889727)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Label 1'' label, 30 value from sys.dual',
'union all',
'select ''Label 2'' label, 20 value from sys.dual',
'union all',
'select ''Label 3'' label, 34 value from sys.dual',
'union all',
'select ''Label 4'' label, 6  value from sys.dual',
'union all',
'select ''Label 5'' label, 10 value from sys.dual'))
,p_max_row_count=>20
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>false
,p_items_label_position=>'auto'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10960617907889727)
,p_chart_id=>wwv_flow_imp.id(10960187931889727)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10961219053889727)
,p_chart_id=>wwv_flow_imp.id(10960187931889727)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
end;
/
prompt --application/pages/page_00012
begin
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Dashboard'
,p_alias=>'DASHBOARD'
,p_step_title=>'Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10966694404911143)
,p_plug_name=>'Total_Inventory_Value'
,p_title=>'Total Inventory Value'
,p_region_template_options=>'u-colors:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleA'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1. Inventory Value',
'SELECT ''Total Inventory Value'' as CARD_TITLE,',
unistr('       ''\00A3'' || TRIM(TO_CHAR(SUM(NVL(QTY_AVAILABLE,0) * NVL(COST_PRICE,0)), ''999G999G999G990D00'')) as CARD_VALUE,'),
'       ''fa-box'' as CARD_ICON,',
'       ''u-color-1'' as CARD_COLOR,',
'       1 as DISPLAY_ORDER',
'  FROM INBOUND_STOCK',
'',
'UNION ALL',
'',
'-- 2. Active Orders',
'SELECT ''Total Active Orders'' as CARD_TITLE,',
'       TO_CHAR(COUNT(*)) as CARD_VALUE,',
'       ''fa-clipboard-list'' as CARD_ICON,',
'       ''u-color-2'' as CARD_COLOR,',
'       2 as DISPLAY_ORDER',
'  FROM SHIPPING_ORDERS',
' WHERE STATUS IN (''received'', ''processing'')',
'',
'UNION ALL',
'',
'-- 3. Total Expenses (Failsafe Cost Calculation)',
'SELECT ''Total Expenses'' as CARD_TITLE,',
unistr('       ''\00A3'' || TRIM(TO_CHAR(SUM('),
'           NVL((SELECT SUM(',
'                       (NVL(i.QTY_SHIPPED, 0) * NVL(i.UNIT_COST, ',
'                           COALESCE(',
'                               -- 1. Pehle exact shipment match karne ki koshish karega',
'                               (SELECT MAX(COST_PRICE) FROM INBOUND_STOCK WHERE SKU = i.SKU AND TRIM(INBOUND_ORDER_NO) = TRIM(i.INBOUND_SOURCE_NUMBER)),',
'                               -- 2. Agar exact na mile (ya NULL ho), toh us SKU ki cost utha lega',
'                               (SELECT MIN(COST_PRICE) FROM INBOUND_STOCK WHERE SKU = i.SKU),',
'                               -- 3. Akhir mein 0',
'                               0',
'                           )',
'                       )) ',
'                       + NVL(i.PREP_COST, 0)',
'                     ) ',
'                  FROM SHIPPING_ORDER_ITEMS i ',
'                 WHERE i.SHIPPING_ORDER_NO = s.ORDER_NO), 0) ',
'           + NVL(s.SHIPPING_COST, 0) + NVL(s.PACKAGING_COST, 0) + NVL(s.OTHER_COST, 0)',
'       ), ''999G999G999G990D00'')) as CARD_VALUE,',
'       ''fa-money-bill-wave'' as CARD_ICON,',
'       ''u-color-3'' as CARD_COLOR,',
'       3 as DISPLAY_ORDER',
'  FROM SHIPPING_ORDERS s',
'',
'UNION ALL',
'',
'-- 4. Net Profit (100% Guaranteed Correct)',
'SELECT ''Net Profit'' as CARD_TITLE,',
unistr('       ''\00A3'' || TRIM(TO_CHAR(SUM('),
'           NVL(s.SALE_PRICE, 0) - (',
'               NVL((SELECT SUM(',
'                           (NVL(i.QTY_SHIPPED, 0) * NVL(i.UNIT_COST, ',
'                               COALESCE(',
'                                   -- Failsafe logic repeated for Profit',
'                                   (SELECT MAX(COST_PRICE) FROM INBOUND_STOCK WHERE SKU = i.SKU AND TRIM(INBOUND_ORDER_NO) = TRIM(i.INBOUND_SOURCE_NUMBER)),',
'                                   (SELECT MIN(COST_PRICE) FROM INBOUND_STOCK WHERE SKU = i.SKU),',
'                                   0',
'                               )',
'                           )) ',
'                           + NVL(i.PREP_COST, 0)',
'                         ) ',
'                      FROM SHIPPING_ORDER_ITEMS i ',
'                     WHERE i.SHIPPING_ORDER_NO = s.ORDER_NO), 0) ',
'               + NVL(s.SHIPPING_COST, 0) + NVL(s.PACKAGING_COST, 0) + NVL(s.OTHER_COST, 0)',
'           )',
'       ), ''999G999G999G990D00'')) as CARD_VALUE,',
'       ''fa-chart-line'' as CARD_ICON,',
'       ''u-color-4'' as CARD_COLOR,',
'       4 as DISPLAY_ORDER',
'  FROM SHIPPING_ORDERS s',
' WHERE s.SALE_PRICE > 0'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10966752642911144)
,p_region_id=>wwv_flow_imp.id(10966694404911143)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'CARD_VALUE'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'CARD_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'DISPLAY_ORDER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10967262689911149)
,p_plug_name=>'New'
,p_title=>'Orders'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TRUNC(DATE_CREATED, ''MM'') as MONTH,',
'       SUM(COST_PRICE - TOTAL_PREP_COST) as NET_PROFIT',
'FROM SHIPPING_ORDERS',
'GROUP BY TRUNC(DATE_CREATED, ''MM'')'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10967331519911150)
,p_region_id=>wwv_flow_imp.id(10967262689911149)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(11863915354650601)
,p_chart_id=>wwv_flow_imp.id(10967331519911150)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(DATE_CREATED, ''Mon-YYYY'') as MONTH_LABEL,',
'       COUNT(*) as TOTAL_ORDERS,',
'       TRUNC(DATE_CREATED, ''MM'') as SORT_DATE -- Sorting ke liye',
'  FROM SHIPPING_ORDERS',
' GROUP BY TO_CHAR(DATE_CREATED, ''Mon-YYYY''), TRUNC(DATE_CREATED, ''MM'')',
' ORDER BY SORT_DATE ASC'))
,p_items_value_column_name=>'TOTAL_ORDERS'
,p_items_label_column_name=>'MONTH_LABEL'
,p_color=>'#34aadc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11864254124650604)
,p_chart_id=>wwv_flow_imp.id(10967331519911150)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11864302356650605)
,p_chart_id=>wwv_flow_imp.id(10967331519911150)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11005015950711325)
,p_plug_name=>'Chart 2'
,p_title=>'Products'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(11005477060711325)
,p_region_id=>wwv_flow_imp.id(11005015950711325)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(11005969624711325)
,p_chart_id=>wwv_flow_imp.id(11005477060711325)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PRODUCT_NAME as label,',
'       SUM(QTY_AVAILABLE) as value',
'FROM INBOUND_STOCK',
'GROUP BY PRODUCT_NAME',
'HAVING SUM(QTY_AVAILABLE) > 0;'))
,p_max_row_count=>20
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
end;
/
prompt --application/pages/page_00013
begin
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Inbound Costs'
,p_alias=>'INBOUND-COSTS'
,p_step_title=>'Inbound Costs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11594477540517505)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11595167453517508)
,p_plug_name=>'Inbound Costs'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    s.id,',
'    s.inbound_name,',
'    h.date_received,',
'    s.qty_received,',
'    s.qty_available,',
'    s.cost_price,',
'    s.third_party_costs,',
'    -- Calculate Total Value automatically',
'    ((NVL(s.cost_price,0) + NVL(s.third_party_costs,0)) * s.qty_available) as total_batch_value',
'FROM inbound_stock s',
'LEFT JOIN inbound_shipments h ON s.inbound_order_no = h.order_no',
'WHERE s.sku = :P13_FILTER_SKU'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P13_FILTER_SKU'
,p_prn_page_header=>'Inbound Costs'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11449262785479703)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11449324102479704)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11449822002479709)
,p_name=>'DATE_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_RECEIVED'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Date Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11449917022479710)
,p_name=>'TOTAL_BATCH_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_BATCH_VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Batch Value'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11596467403517511)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11598487878517515)
,p_name=>'INBOUND_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INBOUND_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Inbound Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11601468860517516)
,p_name=>'QTY_RECEIVED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_RECEIVED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Received'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11602459211517516)
,p_name=>'QTY_AVAILABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_AVAILABLE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Qty Available'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11603478299517517)
,p_name=>'COST_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COST_PRICE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cost Price'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11604411406517517)
,p_name=>'THIRD_PARTY_COSTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'THIRD_PARTY_COSTS'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Third Party Costs'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>110
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(11595626549517509)
,p_internal_uid=>11595626549517509
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(11596077784517509)
,p_interactive_grid_id=>wwv_flow_imp.id(11595626549517509)
,p_static_id=>'115961'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(11596216585517509)
,p_report_id=>wwv_flow_imp.id(11596077784517509)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11596896257517511)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(11596467403517511)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11598817486517515)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(11598487878517515)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11601869206517516)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(11601468860517516)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11602811330517517)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(11602459211517516)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11603843623517517)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(11603478299517517)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11604813944517517)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(11604411406517517)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11609316048547424)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(11449262785479703)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11616595877697372)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(11449822002479709)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11617496667697374)
,p_view_id=>wwv_flow_imp.id(11596216585517509)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(11449917022479710)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11834806314230803)
,p_plug_name=>'Product Details'
,p_title=>'Product Details'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody:margin-top-none:margin-bottom-none'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11835028163230805)
,p_plug_name=>'Image Container'
,p_parent_plug_id=>wwv_flow_imp.id(11834806314230803)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11835151377230806)
,p_plug_name=>'Info Container'
,p_parent_plug_id=>wwv_flow_imp.id(11834806314230803)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11449582193479706)
,p_name=>'P13_FILTER_SKU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11595167453517508)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11834920848230804)
,p_name=>'P13_PREVIEW_IMG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11835028163230805)
,p_use_cache_before_default=>'NO'
,p_source=>'SELECT image_url FROM ordg_products WHERE sku = :P13_FILTER_SKU'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="max-height: 120px; width: auto; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'URL')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11835250379230807)
,p_name=>'P13_PREVIEW_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11835151377230806)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Product Name'
,p_source=>'SELECT product_name FROM ordg_products WHERE sku = :P13_FILTER_SKU'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_css_classes=>'u-h2'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11835326830230808)
,p_name=>'P13_PREVIEW_STOCK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11835151377230806)
,p_prompt=>'Total Stock'
,p_source=>'SELECT total_available_qty FROM ordg_products WHERE sku = :P13_FILTER_SKU'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11449433167479705)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(11595167453517508)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Inbound Costs - Save Interactive Grid Data'
,p_attribute_01=>'TABLE'
,p_attribute_03=>'INBOUND_STOCK'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11449433167479705
);
end;
/
prompt --application/pages/page_00016
begin
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Cost Management'
,p_alias=>'COST-MANAGEMENT'
,p_step_title=>'Cost Management'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657033396899546)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657747562899550)
,p_plug_name=>'Cost Management'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'PREP_RATE_HISTORY'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Cost Management'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10965540277911132)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10965619049911133)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11659026544899552)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11660016759899554)
,p_name=>'SERVICE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SERVICE_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Service Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11661065519899555)
,p_name=>'EFFECTIVE_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EFFECTIVE_DATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Effective Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'EXPRESSION'
,p_default_language=>'PLSQL'
,p_default_expression=>'TRUNC(SYSDATE)'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11662009984899555)
,p_name=>'FIRST_UNIT_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FIRST_UNIT_COST'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'First Unit Cost'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'FML999G999G990D00'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11663009916899556)
,p_name=>'ADDITIONAL_UNIT_COST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ADDITIONAL_UNIT_COST'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Additional Unit Cost'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'FML999G999G990D00'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11664082039899556)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11665045131899556)
,p_name=>'CREATED_AT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_AT'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(11658206825899551)
,p_internal_uid=>11658206825899551
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(11658635975899551)
,p_interactive_grid_id=>wwv_flow_imp.id(11658206825899551)
,p_static_id=>'116587'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(11658854470899551)
,p_report_id=>wwv_flow_imp.id(11658635975899551)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11659438084899553)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(11659026544899552)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11660490120899554)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(11660016759899554)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11661431754899555)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(11661065519899555)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11662466912899555)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(11662009984899555)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11663499897899556)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(11663009916899556)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11664498522899556)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(11664082039899556)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11665401879899557)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(11665045131899556)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(11669391675946895)
,p_view_id=>wwv_flow_imp.id(11658854470899551)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(10965540277911132)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10965805564911135)
,p_validation_name=>'Protect Used Rates'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_usage_count NUMBER;',
'BEGIN',
'    -- 1. Check if we are Deleting or Updating an existing record',
'    IF :APEX$ROW_STATUS IN (''U'', ''D'') THEN',
'',
'        -- 2. Count how many orders are using THIS specific rate ID',
'        SELECT count(*)',
'        INTO l_usage_count',
'        FROM shipping_orders',
'        WHERE prep_rate_id = :ID; -- :ID is the primary key of the row being edited',
'',
'        -- 3. If used, block the action',
'        IF l_usage_count > 0 THEN',
unistr('            RETURN ''\26D4 Cannot Edit/Delete: This rate is used by '' || l_usage_count || '' past orders. To change prices, please Add a NEW Row with a new Date instead.'';'),
'        END IF;',
'',
'    END IF;',
'',
'    RETURN NULL; -- NULL means "No Error, Proceed"',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10965793720911134)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(11657747562899550)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Cost Management - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10965793720911134
);
end;
/
prompt --application/pages/page_00018
begin
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Record Amazon Sales'
,p_alias=>'FBA-SALES'
,p_step_title=>'FBA Sales'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12110455243149527)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12111142228149528)
,p_plug_name=>'Enter Sales'
,p_title=>'Enter Sales'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'id,',
'amazon_order_id,',
'sale_date,',
'asin,',
'qty_sold,',
'sale_price,',
'amazon_fees,',
'total_cogs,',
'net_profit',
'FROM amazon_fba_sales'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'FBA Sales'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12112440511149528)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12112935173149529)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12113924453149529)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12114937268149530)
,p_name=>'SALE_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SALE_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Sale Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12116966654149531)
,p_name=>'ASIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASIN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Asin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_is_required=>true
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''('' || m.asin || '') '' || m.product_name || '' - Qty: '' || SUM(i.qty_available) AS d,',
'    m.asin AS r',
'FROM amazon_asin_master m',
'JOIN amazon_fba_inbound_items i ON m.asin = i.asin',
'WHERE i.qty_available > 0',
'GROUP BY m.product_name, m.asin'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_null_text=>'- Select ASIN -'
,p_lov_cascade_parent_items=>'SKU'
,p_ajax_items_to_submit=>'SKU'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12117957673149531)
,p_name=>'QTY_SOLD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY_SOLD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qty Sold'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12118935315149531)
,p_name=>'SALE_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SALE_PRICE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Sale Price'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12121989248149533)
,p_name=>'TOTAL_COGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_COGS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Unit Cost'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12122987885149533)
,p_name=>'NET_PROFIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NET_PROFIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Net Profit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857346096150822)
,p_name=>'AMAZON_ORDER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AMAZON_ORDER_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Amazon Order Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12857485425150823)
,p_name=>'AMAZON_FEES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AMAZON_FEES'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Amazon Fees'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>140
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12111680889149528)
,p_internal_uid=>12111680889149528
,p_is_editable=>true
,p_edit_operations=>'i:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12112054970149528)
,p_interactive_grid_id=>wwv_flow_imp.id(12111680889149528)
,p_static_id=>'121121'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12112236569149528)
,p_report_id=>wwv_flow_imp.id(12112054970149528)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12113322150149529)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12112935173149529)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12114358700149529)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12113924453149529)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12115357387149530)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12114937268149530)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12117310349149531)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12116966654149531)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>204.781
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12118341759149531)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(12117957673149531)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12119303436149532)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(12118935315149531)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12122353453149533)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(12121989248149533)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12123373836149533)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(12122987885149533)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12916652886518024)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12857346096150822)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>126.781
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12917542553518026)
,p_view_id=>wwv_flow_imp.id(12112236569149528)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(12857485425150823)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12123994493149533)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12111142228149528)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'FBA Sales - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_remaining_qty NUMBER;',
'    v_restore_qty NUMBER;',
'BEGIN',
'    CASE :APEX$ROW_STATUS',
'        WHEN ''C'' THEN ',
'            -- === NEW SALE ===',
'            process_fba_sale(',
'                p_amazon_order_id => :AMAZON_ORDER_ID,',
'                p_asin            => :ASIN,',
'                p_qty_sold        => :QTY_SOLD,',
'                p_sale_price      => :SALE_PRICE,',
'                p_amazon_fees     => NVL(:AMAZON_FEES, 0)',
'            );',
'',
'        WHEN ''D'' THEN ',
'            -- === SALE DELETED (REVERSAL) ===',
'            v_remaining_qty := :QTY_SOLD;',
'            ',
'            FOR batch IN (',
'                SELECT i.id, i.qty_received, i.qty_available',
'                FROM amazon_fba_inbound_items i',
'                JOIN shipping_orders s ON i.order_no = s.order_no',
'                WHERE i.asin = :ASIN',
'                  AND i.qty_available < i.qty_received',
'                ORDER BY s.created_at DESC -- Refills the newest prep shipments first',
'                FOR UPDATE',
'            ) LOOP',
'                EXIT WHEN v_remaining_qty <= 0;',
'                ',
'                IF (batch.qty_received - batch.qty_available) >= v_remaining_qty THEN',
'                    v_restore_qty := v_remaining_qty;',
'                ELSE',
'                    v_restore_qty := (batch.qty_received - batch.qty_available);',
'                END IF;',
'                ',
'                UPDATE amazon_fba_inbound_items',
'                SET qty_available = qty_available + v_restore_qty',
'                WHERE id = batch.id;',
'                ',
'                v_remaining_qty := v_remaining_qty - v_restore_qty;',
'            END LOOP;',
'            ',
'            DELETE FROM amazon_fba_sales WHERE id = :ID;',
'            ',
'    END CASE;',
'END;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12123994493149533
);
end;
/
prompt --application/pages/page_00019
begin
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Monthly Profit Analysis'
,p_alias=>'MONTHLY-PROFIT-ANALYSIS'
,p_step_title=>'Monthly Profit Analysis'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12858331933150832)
,p_plug_name=>'Dashboard Filters'
,p_title=>'Dashboard Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12858799971150836)
,p_plug_name=>'Profit Breakdown'
,p_title=>'Profit Breakdown'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH fba_data AS (',
'    SELECT ',
'        CASE WHEN :P19_TIME_VIEW = ''YEAR'' THEN TO_CHAR(sale_date, ''YYYY'') ',
'             ELSE TO_CHAR(sale_date, ''YYYY-MM'') END AS period_val,',
'        ',
'        -- FBA QUANTITY',
'        SUM(NVL(qty_sold, 0)) AS fba_qty_sold,',
'             ',
'        -- FBA SALES & COSTS',
'        SUM(NVL(sale_price, 0)) AS fba_sales,',
'        SUM(NVL(amazon_fees, 0) + NVL(total_cogs, 0)) AS fba_costs,',
'        SUM(NVL(net_profit, 0)) AS fba_profit',
'        ',
'    FROM amazon_fba_sales',
'    WHERE (:P19_YEAR IS NULL OR TO_CHAR(sale_date, ''YYYY'') = :P19_YEAR)',
'      AND (:P19_MONTH IS NULL OR TO_CHAR(sale_date, ''MM'') = :P19_MONTH)',
'    GROUP BY CASE WHEN :P19_TIME_VIEW = ''YEAR'' THEN TO_CHAR(sale_date, ''YYYY'') ',
'                  ELSE TO_CHAR(sale_date, ''YYYY-MM'') END',
'),',
'prep_data AS (',
'    SELECT ',
'        CASE WHEN :P19_TIME_VIEW = ''YEAR'' THEN TO_CHAR(o.date_shipped, ''YYYY'') ',
'             ELSE TO_CHAR(o.date_shipped, ''YYYY-MM'') END AS period_val,',
'        ',
'        -- PREP QUANTITY (Excludes FBA inbound shipments)',
'        SUM(NVL(o.TOTAL_QUANTITY, 0)) AS prep_qty_sold,',
'',
'        -- PREP SALES',
'        SUM(NVL(o.SALE_PRICE, 0)) AS prep_sales,',
'',
'        -- ISOLATED PREP CENTER FEES',
'        SUM(',
'            (',
'                SELECT NVL(SUM(NVL(i.prep_cost, 0)), 0)',
'                FROM shipping_order_items i',
'                WHERE i.shipping_order_no = o.order_no',
'            )',
'        ) AS isolated_prep_fees,',
'',
'        -- PREP TOTAL COSTS',
'        SUM(',
'            (',
'                SELECT NVL(SUM((i.qty_shipped * NVL(stk.cost_price, 0)) + NVL(i.prep_cost, 0)), 0)',
'                FROM shipping_order_items i',
'                LEFT JOIN inbound_stock stk ',
'                    ON i.sku = stk.sku ',
'                    AND i.inbound_source_number LIKE ''%'' || stk.inbound_order_no',
'                WHERE i.shipping_order_no = o.order_no',
'            ) ',
'            + NVL(o.SHIPPING_COST, 0) ',
'            + NVL(o.PACKAGING_COST, 0) ',
'            + NVL(o.OTHER_COST, 0)',
'            + CASE ',
'                WHEN o.service_type = ''FBM'' THEN (NVL(o.SALE_PRICE, 0) * 0.18)',
'                ELSE 0 ',
'              END',
'        ) AS prep_costs',
'',
'    FROM shipping_orders o',
'    WHERE NVL(o.service_type, ''Standard'') != ''FBA'' ',
'      AND (:P19_YEAR IS NULL OR TO_CHAR(o.date_shipped, ''YYYY'') = :P19_YEAR)',
'      AND (:P19_MONTH IS NULL OR TO_CHAR(o.date_shipped, ''MM'') = :P19_MONTH)',
'    GROUP BY CASE WHEN :P19_TIME_VIEW = ''YEAR'' THEN TO_CHAR(o.date_shipped, ''YYYY'') ',
'                  ELSE TO_CHAR(o.date_shipped, ''YYYY-MM'') END',
')',
'SELECT ',
'    COALESCE(f.period_val, p.period_val) AS time_period,',
'    ',
'    -- QUANTITY BREAKDOWN',
'    NVL(f.fba_qty_sold, 0) AS fba_qty_sold,',
'    NVL(p.prep_qty_sold, 0) AS prep_qty_sold,',
'    (NVL(f.fba_qty_sold, 0) + NVL(p.prep_qty_sold, 0)) AS total_combined_qty,',
'    ',
'    -- FBA BREAKDOWN',
'    NVL(f.fba_sales, 0) AS fba_sales,',
'    NVL(f.fba_costs, 0) AS fba_costs,',
'    NVL(f.fba_profit, 0) AS fba_profit,',
'    ',
'    -- PREP BREAKDOWN',
'    NVL(p.prep_sales, 0) AS prep_sales,',
'    NVL(p.isolated_prep_fees, 0) AS prep_center_fees, ',
'    NVL(p.prep_costs, 0) AS prep_total_costs,',
'    (NVL(p.prep_sales, 0) - NVL(p.prep_costs, 0)) AS prep_profit,',
'    ',
'    -- COMBINED GRAND TOTALS',
'    (NVL(f.fba_sales, 0) + NVL(p.prep_sales, 0)) AS total_combined_sales,',
'    (NVL(f.fba_costs, 0) + NVL(p.prep_costs, 0)) AS total_combined_costs,',
'    (NVL(f.fba_profit, 0) + (NVL(p.prep_sales, 0) - NVL(p.prep_costs, 0))) AS total_combined_profit',
'',
'FROM fba_data f',
'FULL OUTER JOIN prep_data p ON f.period_val = p.period_val',
'ORDER BY time_period DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P19_TIME_VIEW,P19_YEAR,P19_MONTH'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Profit Breakdown'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(12858938608150838)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>12858938608150838
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859011400150839)
,p_db_column_name=>'TIME_PERIOD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Time Period'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859103675150840)
,p_db_column_name=>'FBA_QTY_SOLD'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fba Qty Sold'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859238270150841)
,p_db_column_name=>'PREP_QTY_SOLD'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Prep Qty Sold'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859333893150842)
,p_db_column_name=>'TOTAL_COMBINED_QTY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Total Combined Qty'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859477373150843)
,p_db_column_name=>'FBA_SALES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fba Sales'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859550310150844)
,p_db_column_name=>'FBA_COSTS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fba Costs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859696573150845)
,p_db_column_name=>'FBA_PROFIT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fba Profit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859746043150846)
,p_db_column_name=>'PREP_SALES'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Prep Sales'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859826933150847)
,p_db_column_name=>'PREP_CENTER_FEES'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Prep Center Fees'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12859995031150848)
,p_db_column_name=>'PREP_TOTAL_COSTS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Prep Total Costs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12860006133150849)
,p_db_column_name=>'PREP_PROFIT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Prep Profit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12860165335150850)
,p_db_column_name=>'TOTAL_COMBINED_SALES'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Total Combined Sales'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13393310180242301)
,p_db_column_name=>'TOTAL_COMBINED_COSTS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total Combined Costs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13393495304242302)
,p_db_column_name=>'TOTAL_COMBINED_PROFIT'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Total Combined Profit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(13403984077245910)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134040'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIME_PERIOD:FBA_QTY_SOLD:PREP_QTY_SOLD:TOTAL_COMBINED_QTY:FBA_SALES:FBA_COSTS:FBA_PROFIT:PREP_SALES:PREP_CENTER_FEES:PREP_TOTAL_COSTS:PREP_PROFIT:TOTAL_COMBINED_SALES:TOTAL_COMBINED_COSTS:TOTAL_COMBINED_PROFIT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12858439080150833)
,p_name=>'P19_TIME_VIEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12858331933150832)
,p_prompt=>'Time View'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Monthly;MONTH,Yearly;YEAR'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12858652279150835)
,p_name=>'P19_YEAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12858331933150832)
,p_prompt=>'Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT year_val AS d, year_val AS r',
'FROM (',
'    SELECT TO_CHAR(date_shipped, ''YYYY'') AS year_val ',
'    FROM shipping_orders ',
'    WHERE date_shipped IS NOT NULL',
'    ',
'    UNION',
'    ',
'    SELECT TO_CHAR(sale_date, ''YYYY'') AS year_val ',
'    FROM amazon_fba_sales ',
'    WHERE sale_date IS NOT NULL',
')',
'WHERE year_val IS NOT NULL',
'ORDER BY 1 DESC'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All Years -'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13393535150242303)
,p_name=>'P19_MONTH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12858331933150832)
,p_prompt=>'Month'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Junuary;01,Feburary;02,March;03,April;04,May;05,June;06,July;07,August;08,September;09,October;10,November;11,December;12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All Months -'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
end;
/
prompt --application/pages/page_00024
begin
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'ADD AMAZON ASIN'
,p_alias=>'ADD_AMAZON_ASIN'
,p_step_title=>'ADD AMAZON ASIN'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12789894562964125)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12790552601964130)
,p_plug_name=>'ADD AMAZON ASIN'
,p_title=>'ADD AMAZON ASIN'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'AMAZON_ASIN_MASTER'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'AMAZON_ASIN_MASTER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190675756452848)
,p_name=>'SKU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SKU'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Sku'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_is_required=>true
,p_max_length=>100
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''('' || sku || '')'' || product_name  AS d,  ',
'       sku AS r ',
'FROM ordg_products'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_null_text=>'- Select SKU -'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12190764733452849)
,p_name=>'PRODUCT_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRODUCT_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Product Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12791864968964134)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12792398069964134)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12793378096964137)
,p_name=>'ASIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASIN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ASIN'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12794310952964139)
,p_name=>'CREATED_AT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_AT'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Created At'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12856193681150810)
,p_name=>'IMAGE_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12791087798964130)
,p_internal_uid=>12791087798964130
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12791426739964131)
,p_interactive_grid_id=>wwv_flow_imp.id(12791087798964130)
,p_static_id=>'127915'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12791606393964132)
,p_report_id=>wwv_flow_imp.id(12791426739964131)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12792752446964135)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(12792398069964134)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12793719604964137)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(12793378096964137)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12794711873964140)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12794310952964139)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12851194473131585)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(12190675756452848)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12852035756131586)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12190764733452849)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12897879602577057)
,p_view_id=>wwv_flow_imp.id(12791606393964132)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12856193681150810)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12855518453150804)
,p_name=>'Fetch Product Details'
,p_event_sequence=>10
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(12790552601964130)
,p_triggering_element=>'SKU'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12855684749150805)
,p_event_id=>wwv_flow_imp.id(12855518453150804)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'TRUE'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'PRODUCT_NAME'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT product_name',
'FROM ordg_products ',
'WHERE sku = :SKU'))
,p_attribute_07=>'SKU'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12795358264964143)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12790552601964130)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'AMAZON_ASIN_MASTER - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12795358264964143
);
end;
/
prompt --application/pages/page_09999
begin
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'Elevate - Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101157952850466385
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10575455373533336)
,p_plug_name=>'Elevate'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674157997338192145
,p_plug_display_sequence=>10
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10577532262533337)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10575455373533336)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sign In'
,p_button_position=>'NEXT'
,p_button_alignment=>'LEFT'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10575926106533336)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10575455373533336)
,p_prompt=>'Username'
,p_placeholder=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="username"'
,p_label_alignment=>'RIGHT'
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10576385784533337)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10575455373533336)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="current-password"'
,p_label_alignment=>'RIGHT'
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10576722853533337)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10575455373533336)
,p_prompt=>'Remember username'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_label_alignment=>'RIGHT'
,p_display_when=>'apex_authentication.persistent_cookies_enabled and not apex_authentication.persistent_auth_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '',
  'unchecked_value', '',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10577182310533337)
,p_name=>'P9999_PERSISTENT_AUTH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10575455373533336)
,p_prompt=>'Remember me'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_label_alignment=>'RIGHT'
,p_display_when=>'apex_authentication.persistent_auth_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '',
  'unchecked_value', '',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10579790117533338)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10579790117533338
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10580289351533338)
,p_page_process_id=>wwv_flow_imp.id(10579790117533338)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10580723235533338)
,p_page_process_id=>wwv_flow_imp.id(10579790117533338)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10577847498533337)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10577847498533337
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10578315786533337)
,p_page_process_id=>wwv_flow_imp.id(10577847498533337)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10578831876533338)
,p_page_process_id=>wwv_flow_imp.id(10577847498533337)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10579309054533338)
,p_page_process_id=>wwv_flow_imp.id(10577847498533337)
,p_page_id=>9999
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>3
,p_value_type=>'ITEM'
,p_value=>'P9999_PERSISTENT_AUTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10581667739533339)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10581667739533339
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10581288532533338)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10581288532533338
);
end;
/
prompt --application/pages/page_10000
begin
wwv_flow_imp_page.create_page(
 p_id=>10000
,p_name=>'Administration'
,p_alias=>'ADMINISTRATION'
,p_step_title=>'Administration'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The administration page allows application owners (Administrators) to configure the application and maintain common data used across the application.',
'By selecting one of the available settings, administrators can potentially change how the application is displayed and/or features available to the end users.</p>',
'<p>Access to this page should be limited to Administrators only.</p>'))
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10918408465535374)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10561716944533324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10924335155535376)
,p_plug_name=>'Column 1'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10924707495535376)
,p_plug_name=>'Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(10924335155535376)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_list_id=>wwv_flow_imp.id(10919190354535374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(10566240772533329)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10925172463535376)
,p_plug_name=>'User Interface'
,p_parent_plug_id=>wwv_flow_imp.id(10924335155535376)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_list_id=>wwv_flow_imp.id(10919825844535374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(10566610449533329)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10925598590535376)
,p_plug_name=>'Activity Reports'
,p_parent_plug_id=>wwv_flow_imp.id(10924335155535376)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_list_id=>wwv_flow_imp.id(10920572950535375)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10925940335535377)
,p_plug_name=>'Column 2'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10926367808535377)
,p_plug_name=>'Access Control'
,p_parent_plug_id=>wwv_flow_imp.id(10925940335535377)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10927185664535377)
,p_plug_name=>'ACL Information'
,p_parent_plug_id=>wwv_flow_imp.id(10926367808535377)
,p_region_css_classes=>'margin-sm'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--warning:t-Alert--accessibleHeading'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_acl_scope varchar2(45);',
'begin',
'    l_acl_scope := apex_app_setting.get_value( p_name => ''ACCESS_CONTROL_SCOPE'' );',
'',
'    if l_acl_scope = ''ALL_USERS'' then',
'        return apex_lang.message(''APEX.FEATURE.ACL.INFO.ALL_USERS'');',
'    elsif l_acl_scope = ''ACL_ONLY'' then',
'        return apex_lang.message(''APEX.FEATURE.ACL.INFO.ACL_ONLY'');',
'    else',
'        return apex_lang.message(''APEX.FEATURE.ACL.INFO.ACL_VALUE_INVALID'', l_acl_scope);',
'    end if;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10927519664535377)
,p_name=>'User Counts Report'
,p_parent_plug_id=>wwv_flow_imp.id(10926367808535377)
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--stacked:t-Region--scrollBody:t-Region--noPadding'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.role_name, (select count(*) from apex_appl_acl_user_roles ur where r.role_id = ur.role_id) user_count, r.role_id',
'from apex_appl_acl_roles r',
'where r.application_id = :APP_ID',
'group by r.role_name, r.role_id',
'order by 2 desc, 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515124465797522
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10928242108535378)
,p_query_column_id=>1
,p_column_alias=>'ROLE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'Role Name'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10928646465535378)
,p_query_column_id=>2
,p_column_alias=>'USER_COUNT'
,p_column_display_sequence=>2
,p_column_heading=>'User Count'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10929085104535379)
,p_query_column_id=>3
,p_column_alias=>'ROLE_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Role Id'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10932030438535606)
,p_plug_name=>'Access Control Actions'
,p_parent_plug_id=>wwv_flow_imp.id(10926367808535377)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(10923240106535375)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10926753399535377)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10926367808535377)
,p_button_name=>'ADD_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Add User'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10042:&APP_SESSION.::&DEBUG.:RP,10042::'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10931119599535605)
,p_name=>'Refresh Report'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10926753399535377)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10931690611535606)
,p_event_id=>wwv_flow_imp.id(10931119599535605)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10927519664535377)
);
end;
/
prompt --application/pages/page_10010
begin
wwv_flow_imp_page.create_page(
 p_id=>10010
,p_name=>'Configuration Options'
,p_alias=>'CONFIGURATION-OPTIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Configuration Options'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10566240772533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Configuration settings allow you to make specific functionality either available (enabled) or unavailable (disabled) to end users.</p>',
'<p>If a specific function is not 100% ready, or needs to be temporarily removed, click <strong>Disabled</strong>. ',
'Once it should be made available, simply click <strong>Enabled</strong>.</p>',
'<p><em><strong>Note:</strong> Changes made here will not be reflected for individual end users currently running the application. Once the end user signs out and then signs back in the revised feature settings will be invoked.</em></p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10784116321534611)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10784317127534611)
,p_plug_name=>'Configuration Options'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    build_option_id     ID, ',
'    build_option_name   application_option,',
'    apex_item.hidden(1, build_option_id) ||',
'    apex_item.hidden(2, build_option_status) ||',
'    apex_item.switch ( ',
'         p_idx        => 3,',
'         p_value      => build_option_status,',
'         p_on_value   => ''Include'',',
'         p_on_label   => m.enabled,',
'         p_off_value  => ''Exclude'',',
'         p_off_label  => m.disabled,',
'         p_item_id    => ''BO_OPT_'' || rownum,',
'         p_item_label => ( case when build_option_status = ''Include'' then',
'                               apex_lang.message( ''APEX.FEATURE.CONFIG.IS_ENABLED'', apex_escape.html(build_option_name) )',
'                           when build_option_status = ''Exclude'' then',
'                               apex_lang.message( ''APEX.FEATURE.CONFIG.IS_DISABLED'', apex_escape.html(build_option_name) )',
'                           end )) "STATUS",',
'    component_comment   description,',
'    last_updated_on        updated,',
'    lower(last_updated_by) updated_by,',
'    build_option_status current_status',
'  from apex_application_build_options,',
'  (select apex_lang.message(''APEX.FEATURE.CONFIG.ENABLED'') enabled, apex_lang.message(''APEX.FEATURE.CONFIG.DISABLED'') disabled from dual) m',
' where application_id = :APP_ID ',
' and (feature_identifier not in ( ''APPLICATION_ACCESS_CONTROL'',''APPLICATION_CONFIGURATION'') or feature_identifier is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Configuration Options'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10784960014534612)
,p_name=>'Configuration Options'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10784960014534612
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10785640517534613)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10786037393534613)
,p_db_column_name=>'APPLICATION_OPTION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Feature'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10786420799534613)
,p_db_column_name=>'STATUS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_allow_filtering=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10786832506534613)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10787255621534614)
,p_db_column_name=>'UPDATED'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10787621239534614)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10788044599534614)
,p_db_column_name=>'CURRENT_STATUS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Current Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10790809387534616)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107909'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APPLICATION_OPTION:STATUS:DESCRIPTION:UPDATED:UPDATED_BY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10792434153534617)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10784116321534611)
,p_button_name=>'APPLY_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10791722785534617)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10784317127534611)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10793228763534617)
,p_branch_name=>'Branch to Admin Page'
,p_branch_action=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10792825127534617)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for i in 1..apex_application.g_f01.count loop',
'    for c1 in ( select application_id, build_option_name, build_option_status',
'                from apex_application_build_options',
'                where apex_application.g_f01(i) = build_option_id',
'                   and application_Id = :APP_ID) loop',
'        if c1.build_option_status != apex_application.g_f03(i) then',
'            apex_util.set_build_option_status(  p_application_id => :APP_ID,',
'                                                p_id => apex_application.g_f01(i),',
'                                                p_build_status => upper(apex_application.g_f03(i)) );',
'        end if;',
'    end loop;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Configuration Options updated. '
,p_internal_uid=>10792825127534617
);
end;
/
prompt --application/pages/page_10020
begin
wwv_flow_imp_page.create_page(
 p_id=>10020
,p_name=>'Application Appearance'
,p_alias=>'APPLICATION-APPEARANCE'
,p_page_mode=>'MODAL'
,p_step_title=>'Application Appearance'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10566610449533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Select the default color scheme used to display the application.</p>',
'<p>If <strong>Allow End Users to choose Theme Style</strong> is checked, then each end user can select from the available theme styles by clicking the <em>Customize</em> link in the bottom left corner of the Home page.</p>'))
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10793563009534617)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10793623215534617)
,p_plug_name=>'Configure Appearance'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10796022725534619)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10793563009534617)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10794674193534618)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10793563009534617)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10796456739534619)
,p_branch_name=>'Branch to Admin Page'
,p_branch_action=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10796741155534619)
,p_name=>'P10020_DESKTOP_THEME_STYLE_ID'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10793623215534617)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Desktop Theme Style'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.theme_style_id',
'from apex_application_theme_styles s,',
'    apex_application_themes t',
'where s.application_id = t.application_id',
'    and s.theme_number = t.theme_number',
'    and s.application_id = :app_id',
'    and s.is_current = ''Yes'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'DESKTOP THEME STYLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.name d,',
'       s.theme_style_id r',
'  from apex_application_theme_styles s,',
'       apex_application_themes t',
' where s.application_id = :app_id',
'   and t.application_id = s.application_id',
'   and t.theme_number   = s.theme_number',
'   and t.is_current     = ''Yes''',
' order by 1'))
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from apex_application_theme_styles s,',
'       apex_application_themes t',
' where s.application_id = t.application_id',
'   and s.theme_number   = t.theme_number',
'   and s.application_id = :app_id'))
,p_display_when_type=>'EXISTS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_restricted_characters=>'WEB_SAFE'
,p_inline_help_text=>'The default Theme Style applies to all users.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10797434763534620)
,p_name=>'P10020_END_USER_STYLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10793623215534617)
,p_use_cache_before_default=>'NO'
,p_prompt=>'End User Theme Preference'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.theme_style_by_user_pref',
'  from apex_applications a',
' where a.application_id  = :app_id'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'USER_THEME_PREFERENCE'
,p_lov=>'.'||wwv_flow_imp.id(10797535628534620)||'.'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>'If checked, end users may choose their own Theme Style using the Customize link.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10794780564534618)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10794674193534618)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10795455016534619)
,p_event_id=>wwv_flow_imp.id(10794780564534618)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10798679989534620)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Theme Style'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10020_DESKTOP_THEME_STYLE_ID is not null then',
'    for l_theme in (select theme_number',
'                      from apex_application_themes',
'                     where application_id = :app_id',
'                       and is_current     = ''Yes'')',
'    loop',
'        apex_util.set_current_theme_style (',
'            p_theme_number   => l_theme.theme_number,',
'            p_theme_style_id => :P10020_DESKTOP_THEME_STYLE_ID',
'            );',
'    end loop;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Application Appearance Settings Saved.'
,p_internal_uid=>10798679989534620
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10799075784534621)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save End User Style Preference'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_enabled boolean := case when :P10020_END_USER_STYLE = ''Yes'' then true else false end;',
'begin',
'    for l_theme in ( select theme_number',
'                       from apex_applications',
'                      where application_id  = :APP_ID )',
'    loop',
'        if l_enabled then',
'            apex_theme.enable_user_style (',
'                p_application_id => :APP_ID,',
'                p_theme_number   => l_theme.theme_number );',
'        else',
'            apex_theme.disable_user_style (',
'                p_application_id => :APP_ID,',
'                p_theme_number   => l_theme.theme_number );',
'            apex_theme.clear_all_users_style(:APP_ID);',
'        end if;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Application Appearance Settings Saved.'
,p_internal_uid=>10799075784534621
);
end;
/
prompt --application/pages/page_10030
begin
wwv_flow_imp_page.create_page(
 p_id=>10030
,p_name=>'Activity Dashboard'
,p_alias=>'ACTIVITY-DASHBOARD'
,p_step_title=>'Activity Dashboard'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10799326647534621)
,p_plug_name=>'Hourly Page Events'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10799494777534621)
,p_region_id=>wwv_flow_imp.id(10799326647534621)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10801599952534622)
,p_chart_id=>wwv_flow_imp.id(10799494777534621)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with nw as (',
'    -- APEX_ACTIVITY_LOG uses dates; convert system time to local time zone.',
'    select from_tz( cast( sysdate as timestamp ), to_char( systimestamp, ''TZR'' ) ) at local as tm from dual',
'),',
'window as (',
'    select',
'         trunc(nw.tm - ((level-1)/24),''HH'') start_tm,',
'         trunc(nw.tm - ((level-2)/24),''HH'') end_tm,',
'         trunc(sysdate-((level-1)/24),''HH'') log_start_tm,',
'         trunc(sysdate-((level-2)/24),''HH'') log_end_tm',
'    from nw',
'    connect by level <= round( 24 * ( 1/24/60/60 * nvl(:P10030_TIMEFRAME,1) ) )',
')',
'select w.start_tm log_time,',
'       ( select count(*)',
'           from apex_activity_log l',
'          where l.flow_id = :app_id',
'            and l.time_stamp between w.log_start_tm and w.log_end_tm ) as value',
'from window w',
'order by 1'))
,p_max_row_count=>350
,p_ajax_items_to_submit=>'P10030_TIMEFRAME'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LOG_TIME'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10802159885534622)
,p_chart_id=>wwv_flow_imp.id(10799494777534621)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10802777085534622)
,p_chart_id=>wwv_flow_imp.id(10799494777534621)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'datetime-short'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10799537579534621)
,p_plug_name=>'Most Active Pages'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10799640872534621)
,p_region_id=>wwv_flow_imp.id(10799537579534621)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10806541063534624)
,p_chart_id=>wwv_flow_imp.id(10799640872534621)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.step_id||''. ''||(select page_name from apex_application_pages p where p.application_id = :app_id and page_id = x.step_id) label, ',
'        value',
'from ( select step_id,',
'              count(*) as value',
'         from apex_activity_log',
'        where flow_id = :app_id',
'          and time_stamp >= sysdate - ( 1/24/60/60 * :P10030_TIMEFRAME )',
'          and step_id is not null',
'        group by step_id',
'        order by 2 desc',
'     ) x'))
,p_max_row_count=>10
,p_ajax_items_to_submit=>'P10030_TIMEFRAME'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10807151084534624)
,p_chart_id=>wwv_flow_imp.id(10799640872534621)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10807715745534624)
,p_chart_id=>wwv_flow_imp.id(10799640872534621)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10799747019534621)
,p_plug_name=>'Top Users'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10799837684534621)
,p_region_id=>wwv_flow_imp.id(10799747019534621)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10804016857534623)
,p_chart_id=>wwv_flow_imp.id(10799837684534621)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl( userid_lc, apex_lang.message(''APEX.FEATURE.TOP_USERS.USERNAME.NOT_IDENTIFIED'') ) as label,',
'       count(*) as value',
'from apex_activity_log',
'where flow_id = :app_id',
'and time_stamp >= sysdate - ( 1/24/60/60 * :P10030_TIMEFRAME )',
'group by nvl( userid_lc, apex_lang.message(''APEX.FEATURE.TOP_USERS.USERNAME.NOT_IDENTIFIED'') )',
'order by 2 desc'))
,p_max_row_count=>10
,p_ajax_items_to_submit=>'P10030_TIMEFRAME'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10804651287534623)
,p_chart_id=>wwv_flow_imp.id(10799837684534621)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10805263293534623)
,p_chart_id=>wwv_flow_imp.id(10799837684534621)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10799949544534621)
,p_name=>'Recent Errors'
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sqlerrm    label,',
'       time_stamp value',
'  from apex_activity_log',
' where flow_id    = :app_id',
'   and time_stamp >= sysdate - ( 1/24/60/60 * :P10030_TIMEFRAME )',
'   and sqlerrm    is not null',
' order by 2 desc, 1'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P10030_TIMEFRAME'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10808853574534625)
,p_query_column_id=>1
,p_column_alias=>'LABEL'
,p_column_display_sequence=>1
,p_column_heading=>'Label'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10809262588534625)
,p_query_column_id=>2
,p_column_alias=>'VALUE'
,p_column_display_sequence=>2
,p_column_heading=>'Value'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10800093206534621)
,p_name=>'Latest Activity'
,p_template=>4072358936313175081
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select userid_lc       as username,',
'       max(time_stamp) as last_activity',
'  from apex_activity_log',
' where flow_id     = :app_id',
'   and time_stamp >= sysdate - ( 1/24/60/60 * :P10030_TIMEFRAME )',
'   and userid_lc  is not null',
' group by userid_lc',
' order by 2 desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P10030_TIMEFRAME'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No activities found'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10811981376534855)
,p_query_column_id=>1
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Username'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10812378911534855)
,p_query_column_id=>2
,p_column_alias=>'LAST_ACTIVITY'
,p_column_display_sequence=>2
,p_column_heading=>'Last Activity'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10800151352534621)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI:t-Form--large'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10814578478535085)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10799326647534621)
,p_button_name=>'VIEW_ACTIVITY_BY_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP,10031::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10814999993535085)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10799537579534621)
,p_button_name=>'VIEW_ACTIVITY_DETAILS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10034:&APP_SESSION.::&DEBUG.:RP,10034::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10815341943535085)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10799747019534621)
,p_button_name=>'VIEW_ACTIVITY_BY_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP,10031::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10815797957535085)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10799949544534621)
,p_button_name=>'VIEW_RECENT_ERRORS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10032:&APP_SESSION.::&DEBUG.:RP,10032::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10800248915534621)
,p_name=>'P10030_TIMEFRAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10800151352534621)
,p_prompt=>'Timeframe'
,p_source=>'900'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIMEFRAME (4 WEEKS)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val as seconds',
'  from table( apex_util.get_timeframe_lov_data )',
' order by insert_order'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10800366868534621)
,p_name=>'Change Filters'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10030_TIMEFRAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10817362560535086)
,p_event_id=>wwv_flow_imp.id(10800366868534621)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10799326647534621)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10817859037535086)
,p_event_id=>wwv_flow_imp.id(10800366868534621)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10799747019534621)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10818303400535086)
,p_event_id=>wwv_flow_imp.id(10800366868534621)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10799537579534621)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10818844492535087)
,p_event_id=>wwv_flow_imp.id(10800366868534621)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10799949544534621)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10819359334535087)
,p_event_id=>wwv_flow_imp.id(10800366868534621)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10800093206534621)
);
end;
/
prompt --application/pages/page_10031
begin
wwv_flow_imp_page.create_page(
 p_id=>10031
,p_name=>'Top Users'
,p_alias=>'TOP-USERS'
,p_page_mode=>'MODAL'
,p_step_title=>'Top Users'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hour-graph { display: table; width: 100%; }',
'span.hour { display: table-cell; padding: 0; font-size: 11px; text-align: center; min-width: 32px; }',
'span.hour-label { opacity: 0.5; }',
'span.hour-value { display: block; }',
'span.hour { background-color: var(--ut-palette-success); color:  var(--ut-palette-success-contrast); }',
'span.hour.is-null { background-color: var(--ut-component-highlight-background-color); color: var(--ut-component-text-default-color); }',
'span.hour.is-over1k { background-color: var(--ut-palette-primary); color:  var(--ut-palette-primary-contrast); }'))
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use this report and chart to see the users with the most page views for the specified timeframe.</p>',
'<p>Select the reporting timeframe (Default = 1 day) and choose between the report and chart icons at the top of the page.</p>',
'<p>For the interactive report, use the search field, or select the <strong>User</strong> column heading, to select a specific user. You can perform numerous functions by clicking the <strong>Actions</strong> button, such as columns displayed / hidden'
||', rows per page, filter, and so forth. Click the <strong>Reset</strong> button to reset the interactive report back to the default settings.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10852169067535106)
,p_plug_name=>'Top Users'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select the_user,',
'    ''<div class="hour-graph">''||',
'        ''<span class="hour''|| case when h00 = 0 then '' is-null'' when h00 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 0</span> <span class="hour-value">''|| ',
'        case when h00 > 999 then to_char((h00/1000),''99999999D0'') ||''k'' else to_char(h00) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h01 = 0 then '' is-null'' when h01 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 1</span> <span class="hour-value">''|| ',
'        case when h01 > 999 then to_char((h01/1000),''99999999D0'') ||''k'' else to_char(h01) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h02 = 0 then '' is-null'' when h02 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 2</span> <span class="hour-value">''|| ',
'        case when h02 > 999 then to_char((h02/1000),''99999999D0'') ||''k'' else to_char(h02) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h03 = 0 then '' is-null'' when h03 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 3</span> <span class="hour-value">''|| ',
'        case when h03 > 999 then to_char((h03/1000),''99999999D0'') ||''k'' else to_char(h03) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h04 = 0 then '' is-null'' when h04 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 4</span> <span class="hour-value">''|| ',
'        case when h04 > 999 then to_char((h04/1000),''99999999D0'') ||''k'' else to_char(h04) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h05 = 0 then '' is-null'' when h05 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 5</span> <span class="hour-value">''|| ',
'        case when h05 > 999 then to_char((h05/1000),''99999999D0'') ||''k'' else to_char(h05) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h06 = 0 then '' is-null'' when h06 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 6</span> <span class="hour-value">''|| ',
'        case when h06 > 999 then to_char((h06/1000),''99999999D0'') ||''k'' else to_char(h06) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h07 = 0 then '' is-null'' when h07 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 7</span> <span class="hour-value">''|| ',
'        case when h07 > 999 then to_char((h07/1000),''99999999D0'') ||''k'' else to_char(h07) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h08 = 0 then '' is-null'' when h08 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 8</span> <span class="hour-value">''|| ',
'        case when h08 > 999 then to_char((h08/1000),''99999999D0'') ||''k'' else to_char(h08) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h09 = 0 then '' is-null'' when h09 > 999 then '' is-over1k'' end ||''"><span class="hour-label"> 9</span> <span class="hour-value">''|| ',
'        case when h09 > 999 then to_char((h09/1000),''99999999D0'') ||''k'' else to_char(h09) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h10 = 0 then '' is-null'' when h10 > 999 then '' is-over1k'' end ||''"><span class="hour-label">10</span> <span class="hour-value">''|| ',
'        case when h10 > 999 then to_char((h10/1000),''99999999D0'') ||''k'' else to_char(h10) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h11 = 0 then '' is-null'' when h11 > 999 then '' is-over1k'' end ||''"><span class="hour-label">11</span> <span class="hour-value">''|| ',
'        case when h11 > 999 then to_char((h11/1000),''99999999D0'') ||''k'' else to_char(h11) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h12 = 0 then '' is-null'' when h12 > 999 then '' is-over1k'' end ||''"><span class="hour-label">12</span> <span class="hour-value">''|| ',
'        case when h12 > 999 then to_char((h12/1000),''99999999D0'') ||''k'' else to_char(h12) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h13 = 0 then '' is-null'' when h13 > 999 then '' is-over1k'' end ||''"><span class="hour-label">13</span> <span class="hour-value">''|| ',
'        case when h13 > 999 then to_char((h13/1000),''99999999D0'') ||''k'' else to_char(h13) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h14 = 0 then '' is-null'' when h14 > 999 then '' is-over1k'' end ||''"><span class="hour-label">14</span> <span class="hour-value">''|| ',
'        case when h14 > 999 then to_char((h14/1000),''99999999D0'') ||''k'' else to_char(h14) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h15 = 0 then '' is-null'' when h15 > 999 then '' is-over1k'' end ||''"><span class="hour-label">15</span> <span class="hour-value">''|| ',
'        case when h15 > 999 then to_char((h15/1000),''99999999D0'') ||''k'' else to_char(h15) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h16 = 0 then '' is-null'' when h16 > 999 then '' is-over1k'' end ||''"><span class="hour-label">16</span> <span class="hour-value">''|| ',
'        case when h16 > 999 then to_char((h16/1000),''99999999D0'') ||''k'' else to_char(h16) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h17 = 0 then '' is-null'' when h17 > 999 then '' is-over1k'' end ||''"><span class="hour-label">17</span> <span class="hour-value">''|| ',
'        case when h17 > 999 then to_char((h17/1000),''99999999D0'') ||''k'' else to_char(h17) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h18 = 0 then '' is-null'' when h18 > 999 then '' is-over1k'' end ||''"><span class="hour-label">18</span> <span class="hour-value">''|| ',
'        case when h18 > 999 then to_char((h18/1000),''99999999D0'') ||''k'' else to_char(h18) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h19 = 0 then '' is-null'' when h19 > 999 then '' is-over1k'' end ||''"><span class="hour-label">19</span> <span class="hour-value">''|| ',
'        case when h19 > 999 then to_char((h19/1000),''99999999D0'') ||''k'' else to_char(h19) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h20 = 0 then '' is-null'' when h20 > 999 then '' is-over1k'' end ||''"><span class="hour-label">20</span> <span class="hour-value">''|| ',
'        case when h20 > 999 then to_char((h20/1000),''99999999D0'') ||''k'' else to_char(h20) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h21 = 0 then '' is-null'' when h21 > 999 then '' is-over1k'' end ||''"><span class="hour-label">21</span> <span class="hour-value">''|| ',
'        case when h21 > 999 then to_char((h21/1000),''99999999D0'') ||''k'' else to_char(h21) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h22 = 0 then '' is-null'' when h22 > 999 then '' is-over1k'' end ||''"><span class="hour-label">22</span> <span class="hour-value">''|| ',
'        case when h22 > 999 then to_char((h22/1000),''99999999D0'') ||''k'' else to_char(h22) end ||''</span></span>''||',
'        ''<span class="hour''|| case when h23 = 0 then '' is-null'' when h23 > 999 then '' is-over1k'' end ||''"><span class="hour-label">23</span> <span class="hour-value">''|| ',
'        case when h23 > 999 then to_char((h23/1000),''99999999D0'') ||''k'' else to_char(h23) end ||''</span></span>''||',
'        ''</div>'' hours,',
'        page_events,',
'    median_elapsed,',
'    rows_fetched,',
'    ir_searches,',
'    errors,',
'    most_recent',
'    from (  ',
'    select userid_lc                    as the_user,',
'        count(*)                        as page_events,',
'        median(elap)                    as median_elapsed,',
'        sum(num_rows)                   as rows_fetched,',
'        sum(decode(ir_search,null,0,1)) as ir_searches,',
'        sum(decode(sqlerrm,null,0,1))   as errors,',
'        max(time_stamp)                 as most_recent,',
'        sum(decode(to_char(time_stamp,''HH24''),0,1,0)) h00,',
'        sum(decode(to_char(time_stamp,''HH24''),1,1,0)) h01,',
'        sum(decode(to_char(time_stamp,''HH24''),2,1,0)) h02,',
'        sum(decode(to_char(time_stamp,''HH24''),3,1,0)) h03,',
'        sum(decode(to_char(time_stamp,''HH24''),4,1,0)) h04,',
'        sum(decode(to_char(time_stamp,''HH24''),5,1,0)) h05,',
'        sum(decode(to_char(time_stamp,''HH24''),6,1,0)) h06,',
'        sum(decode(to_char(time_stamp,''HH24''),7,1,0)) h07,',
'        sum(decode(to_char(time_stamp,''HH24''),8,1,0)) h08,',
'        sum(decode(to_char(time_stamp,''HH24''),9,1,0)) h09,',
'        sum(decode(to_char(time_stamp,''HH24''),10,1,0)) h10,',
'        sum(decode(to_char(time_stamp,''HH24''),11,1,0)) h11,',
'        sum(decode(to_char(time_stamp,''HH24''),12,1,0)) h12,',
'        sum(decode(to_char(time_stamp,''HH24''),13,1,0)) h13,',
'        sum(decode(to_char(time_stamp,''HH24''),14,1,0)) h14,',
'        sum(decode(to_char(time_stamp,''HH24''),15,1,0)) h15,',
'        sum(decode(to_char(time_stamp,''HH24''),16,1,0)) h16,',
'        sum(decode(to_char(time_stamp,''HH24''),17,1,0)) h17,',
'        sum(decode(to_char(time_stamp,''HH24''),18,1,0)) h18,',
'        sum(decode(to_char(time_stamp,''HH24''),19,1,0)) h19,',
'        sum(decode(to_char(time_stamp,''HH24''),20,1,0)) h20,',
'        sum(decode(to_char(time_stamp,''HH24''),21,1,0)) h21,',
'        sum(decode(to_char(time_stamp,''HH24''),22,1,0)) h22,',
'        sum(decode(to_char(time_stamp,''HH24''),23,1,0)) h23',
'    from apex_activity_log l',
'    where flow_id = :APP_ID',
'        and time_stamp >= sysdate - ( 1/24/60/60 * :P10031_TIMEFRAME )',
'        and userid is not null',
'    group by userid_lc) x'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P10031_TIMEFRAME'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P10031_VIEW_AS'
,p_plug_display_when_cond2=>'REPORT'
,p_prn_page_header=>'Top Users'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10853234371535106)
,p_name=>'Top Users'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10853234371535106
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10853985547535109)
,p_db_column_name=>'THE_USER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10854334484535110)
,p_db_column_name=>'HOURS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Activity by Hour'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10854710513535110)
,p_db_column_name=>'PAGE_EVENTS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Page Events'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10855121931535111)
,p_db_column_name=>'MEDIAN_ELAPSED'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Median Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D0000'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10855521679535111)
,p_db_column_name=>'ROWS_FETCHED'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Rows Fetched'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10855947964535112)
,p_db_column_name=>'IR_SEARCHES'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'IR Search'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10856395841535112)
,p_db_column_name=>'ERRORS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Errors'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10856797095535112)
,p_db_column_name=>'MOST_RECENT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Most_Recent'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10859893633535116)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108599'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'THE_USER:HOURS:PAGE_EVENTS'
,p_sort_column_1=>'PAGE_EVENTS'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'MOST_RECENT'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10852269834535106)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI:t-Form--large'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10852477035535106)
,p_plug_name=>'Top Users Chart'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P10031_VIEW_AS'
,p_plug_display_when_cond2=>'CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10852566586535106)
,p_region_id=>wwv_flow_imp.id(10852477035535106)
,p_chart_type=>'donut'
,p_height=>'600'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>.02
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'',
'    this.pieSliceLabel = function(dataContext) {',
'        var series_name,',
'            percent = Math.round(dataContext.value/dataContext.totalValue*100);',
'        ',
'        if ( dataContext.seriesData ) {',
'            series_name = dataContext.seriesData.name;',
'        } else {',
'            series_name = ''Other'';',
'        }',
'        return series_name + " " + percent + "% ( " + dataContext.value + " )";',
'    }',
'    ',
'    // Set chart initialization options ',
'    options.dataLabel = pieSliceLabel; ',
'    return options; ',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10863497024535119)
,p_chart_id=>wwv_flow_imp.id(10852566586535106)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select userid_lc as userid,',
'       count(*) as page_views',
'  from apex_activity_log',
' where flow_id     = :app_id',
'   and time_stamp >= sysdate - ( 1/24/60/60 * :P10031_TIMEFRAME )',
'   and userid     is not null',
' group by userid_lc',
' order by 2'))
,p_ajax_items_to_submit=>'P10031_TIMEFRAME'
,p_items_value_column_name=>'PAGE_VIEWS'
,p_items_label_column_name=>'USERID'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideSlice'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10860725761535117)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10852169067535106)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10852663594535106)
,p_name=>'P10031_VIEW_AS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10852269834535106)
,p_prompt=>'View As'
,p_source=>'REPORT'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'VIEW_AS_REPORT_CHART'
,p_lov=>'.'||wwv_flow_imp.id(10863904742535119)||'.'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'hide_radio_buttons', 'N',
  'number_of_columns', '2',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10852844042535106)
,p_name=>'P10031_TIMEFRAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10852269834535106)
,p_prompt=>'Timeframe'
,p_source=>'900'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIMEFRAME (4 WEEKS)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val as seconds',
'  from table( apex_util.get_timeframe_lov_data )',
' order by insert_order'))
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10852351012535106)
,p_name=>'Refresh Report'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10031_TIMEFRAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10862039482535118)
,p_event_id=>wwv_flow_imp.id(10852351012535106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10852169067535106)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10865443414535120)
,p_event_id=>wwv_flow_imp.id(10852351012535106)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10852169067535106)
);
end;
/
prompt --application/pages/page_10032
begin
wwv_flow_imp_page.create_page(
 p_id=>10032
,p_name=>'Application Error Log'
,p_alias=>'APPLICATION-ERROR-LOG'
,p_page_mode=>'MODAL'
,p_step_title=>'Application Error Log'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page provides an interactive report of all unexpected errors logged by this application.</p>',
'<p>Click on the column headings to sort and filter data, or click on the <strong>Actions</strong> button to customize column display and many additional advanced features. Click the <strong>Reset</strong> button to reset the interactive report back t'
||'o the default settings.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10845260374535102)
,p_plug_name=>'Application Error Log'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select step_id,',
'       userid,',
'       time_stamp err_time,',
'       sqlerrm,',
'       sqlerrm_component_type,',
'       sqlerrm_component_name',
'  from apex_activity_log',
' where flow_id = :app_id',
'   and sqlerrm is not null'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Application Error Log'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10845720020535102)
,p_name=>'Application Error Log'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10845720020535102
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846476215535102)
,p_db_column_name=>'STEP_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846828289535103)
,p_db_column_name=>'USERID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10847268174535103)
,p_db_column_name=>'ERR_TIME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Err Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10847681498535103)
,p_db_column_name=>'SQLERRM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10848010027535103)
,p_db_column_name=>'SQLERRM_COMPONENT_TYPE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Context'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10848493372535104)
,p_db_column_name=>'SQLERRM_COMPONENT_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Component Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10850968256535105)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STEP_ID:USERID:ERR_TIME:SQLERRM:SQLERRM_COMPONENT_TYPE:SQLERRM_COMPONENT_NAME:'
,p_sort_column_1=>'ERROR_TIME'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10851800734535106)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10845260374535102)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
end;
/
prompt --application/pages/page_10033
begin
wwv_flow_imp_page.create_page(
 p_id=>10033
,p_name=>'Page Performance'
,p_alias=>'PAGE-PERFORMANCE'
,p_page_mode=>'MODAL'
,p_step_title=>'Page Performance'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page provides an interactive report of the page performance and popularity. The report is ordered by <strong>Weighted Performance</strong> which is calculated by multiplying the Median Elapsed time and number of Page Views.</p>',
'<p>Select the reporting timeframe (Default = 1 day) at the top of the page as necessary.<br>',
'Click on the column headings to sort and filter data, or click on the <strong>Actions</strong> button to customize column display and many additional advanced features. Click the <strong>Reset</strong> button to reset the interactive report back to t'
||'he default settings.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10831190491535093)
,p_plug_name=>'Page Performance'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select step_id page,',
'    (   select page_name',
'        from apex_application_pages p',
'        where p.page_id = l.step_id',
'            and p.application_id = :app_id ) page_name,',
'    median(elap)                   median_elapsed,',
'    count(*) * median(elap)        weighted_performance,',
'    sum(decode(sqlerrm,null,0,1))  errors,',
'    count(distinct userid)         distinct_users,',
'    count(distinct session_id)     application_sessions,',
'    count(*)                       page_views,',
'    max(elap)                      max_elapsed,',
'    sum(nvl(num_rows,0))           total_rows,',
'    sum(decode(page_mode,''P'',1,0)) partial_page_views,',
'    sum(decode(page_mode,''D'',1,0)) full_page_views,',
'    min(elap)                      min_elapsed,',
'    avg(elap)                      avg_elapsed',
'from apex_activity_log l',
'where flow_id = :app_id',
'    and time_stamp >= sysdate - ( 1/24/60/60 * :P10033_TIMEFRAME )',
'    and userid is not null',
'group by step_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P10033_TIMEFRAME'
,p_prn_page_header=>'Page Performance'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10831728622535094)
,p_name=>'Page Performance'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10831728622535094
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10832403740535094)
,p_db_column_name=>'PAGE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10832805213535095)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10833245912535095)
,p_db_column_name=>'MEDIAN_ELAPSED'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Median Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D9999'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10833650151535095)
,p_db_column_name=>'WEIGHTED_PERFORMANCE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Weighted Performance'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D99'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10834007971535095)
,p_db_column_name=>'ERRORS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Errors'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10834408962535096)
,p_db_column_name=>'DISTINCT_USERS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Distinct Users'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10834877949535096)
,p_db_column_name=>'APPLICATION_SESSIONS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Application Sessions'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10835260094535096)
,p_db_column_name=>'PAGE_VIEWS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Page Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10835651679535096)
,p_db_column_name=>'MAX_ELAPSED'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Max Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D9999'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10836053582535096)
,p_db_column_name=>'TOTAL_ROWS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Total Rows'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10836426173535097)
,p_db_column_name=>'PARTIAL_PAGE_VIEWS'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Partial Page Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10836829659535097)
,p_db_column_name=>'FULL_PAGE_VIEWS'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Full Page Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10837236725535097)
,p_db_column_name=>'MIN_ELAPSED'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Min Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D9999'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10837638089535097)
,p_db_column_name=>'AVG_ELAPSED'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Avg Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D9999'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10842587016535100)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108426'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PAGE:PAGE_NAME:MEDIAN_ELAPSED:WEIGHTED_PERFORMANCE:ERRORS:DISTINCT_USERS:APPLICATION_SESSIONS:PAGE_VIEWS'
,p_sort_column_1=>'WEIGHTED_PERFORMANCE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PAGE_VIEWS'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10831293062535093)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI:t-Form--large'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10843461854535101)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10831190491535093)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10831094272535093)
,p_name=>'P10033_TIMEFRAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10831293062535093)
,p_prompt=>'Timeframe'
,p_source=>'900'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIMEFRAME (4 WEEKS)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val as seconds',
'  from table( apex_util.get_timeframe_lov_data )',
' order by insert_order'))
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10831398858535093)
,p_name=>'Refresh Report'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10033_TIMEFRAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10844709150535102)
,p_event_id=>wwv_flow_imp.id(10831398858535093)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10831190491535093)
);
end;
/
prompt --application/pages/page_10034
begin
wwv_flow_imp_page.create_page(
 p_id=>10034
,p_name=>'Page Views'
,p_alias=>'PAGE-VIEWS'
,p_page_mode=>'MODAL'
,p_step_title=>'Page Views'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page provides an interactive report of the most recent page views.</p>',
'<p>Select the reporting timeframe (Default = 1 day) at the top of the page as necessary.<br>',
'Click on the column headings to sort and filter data, or click on the <strong>Actions</strong> button to customize column display and many additional advanced features. Click the <strong>Reset</strong> button to reset the interactive report back to t'
||'he default settings.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10819874931535087)
,p_plug_name=>'Page Views'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    step_id||''. ''||(select page_name',
'                    from apex_application_pages p',
'                    where p.page_id = l.step_id',
'                        and p.application_id = :APP_ID) page_name,',
'    userid_lc     user_id,',
'    time_stamp    timestamp,',
'    elap          elapsed,',
'    step_id       page,',
'    decode(page_mode,''P'',''Partial'',''D'',''Full'',page_mode) page_mode,',
'    component_name,',
'    num_rows,',
'    ir_search,',
'    sqlerrm  error',
'from apex_activity_log l',
'where flow_id = :app_id',
'    and time_stamp >= sysdate - ( 1/24/60/60 * :P10034_TIMEFRAME )',
'    and userid is not null',
'    and step_id is not null',
'order by time_stamp desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P10034_TIMEFRAME'
,p_prn_page_header=>'Page Views'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10820450265535087)
,p_name=>'Page Views'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10820450265535087
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10821145624535088)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10821546309535088)
,p_db_column_name=>'USER_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10821948643535088)
,p_db_column_name=>'TIMESTAMP'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Timestamp'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10822351039535088)
,p_db_column_name=>'ELAPSED'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Elapsed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D0000'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10822778260535089)
,p_db_column_name=>'PAGE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10823172320535089)
,p_db_column_name=>'PAGE_MODE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Mode'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10823510941535089)
,p_db_column_name=>'COMPONENT_NAME'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Component Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10823909021535089)
,p_db_column_name=>'NUM_ROWS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Num Rows'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10824384930535089)
,p_db_column_name=>'IR_SEARCH'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'IR Search'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10824754003535090)
,p_db_column_name=>'ERROR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10828498849535092)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108285'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PAGE_NAME:USER_ID:TIMESTAMP:ELAPSED:PAGE_MODE'
,p_sort_column_1=>'TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10819942828535087)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI:t-Form--large'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10829398759535092)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10819874931535087)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10819781818535087)
,p_name=>'P10034_TIMEFRAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10819942828535087)
,p_prompt=>'Timeframe'
,p_source=>'900'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIMEFRAME (4 WEEKS)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val as seconds',
'  from table( apex_util.get_timeframe_lov_data )',
' order by insert_order'))
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10820037176535087)
,p_name=>'Refresh Report'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10034_TIMEFRAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10830633946535093)
,p_event_id=>wwv_flow_imp.id(10820037176535087)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10819874931535087)
);
end;
/
prompt --application/pages/page_10035
begin
wwv_flow_imp_page.create_page(
 p_id=>10035
,p_name=>'Automations Log'
,p_alias=>'AUTOMATIONS-LOG'
,p_page_mode=>'MODAL'
,p_step_title=>'Automations Log'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page provides an interactive report of the automations log.</p>',
'<p>Review logged information about previous automation executions. The log contains start and end timestamps as well as details about processed rows (successful and with errors). Drill down into Messages to see individual messages for processed rows.'
||'</p>',
''))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10865966819535120)
,p_plug_name=>'Automations Log'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id,',
'       l.start_timestamp,',
'       a.name automation_name,',
'       l.status,',
'       l.successful_row_count,',
'       l.error_row_count,',
'       (select count(1) from apex_automation_msg_log m where m.automation_log_id = l.id) msg_count,',
'       l.is_job,',
'       l.end_timestamp',
'  from apex_appl_automations a, apex_automation_log l',
' where a.automation_id = l.automation_id',
' and l.application_id = :APP_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Automations Log'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10866583061535120)
,p_name=>'Automations Log'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10866583061535120
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10867215131535121)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10867664732535121)
,p_db_column_name=>'START_TIMESTAMP'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Started'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10868026001535121)
,p_db_column_name=>'AUTOMATION_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Automation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10868423500535121)
,p_db_column_name=>'STATUS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10868858260535122)
,p_db_column_name=>'SUCCESSFUL_ROW_COUNT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Successful Rows'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10869284565535122)
,p_db_column_name=>'ERROR_ROW_COUNT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Error Rows'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10869650400535122)
,p_db_column_name=>'MSG_COUNT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Message'
,p_column_link=>'f?p=&APP_ID.:10036:&APP_SESSION.::&DEBUG.:RP,10036:P10036_LOG_ID:#ID#'
,p_column_linktext=>'#MSG_COUNT#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10870050462535122)
,p_db_column_name=>'IS_JOB'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Scheduled'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10870465060535123)
,p_db_column_name=>'END_TIMESTAMP'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Ended'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10873800112535125)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108739'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'START_TIMESTAMP:AUTOMATION_NAME:STATUS:SUCCESSFUL_ROW_COUNT:ERROR_ROW_COUNT:MSG_COUNT'
,p_sort_column_1=>'START_TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10874732801535125)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10865966819535120)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
end;
/
prompt --application/pages/page_10036
begin
wwv_flow_imp_page.create_page(
 p_id=>10036
,p_name=>'Log Messages'
,p_alias=>'LOG-MESSAGES'
,p_page_mode=>'MODAL'
,p_step_title=>'Log Messages'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565911813533329)
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10875390764535125)
,p_plug_name=>'Automation Execution'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10877792146535127)
,p_name=>'Messages'
,p_template=>2100526641005906379
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select message_timestamp,',
'       message,',
'       message_type,',
'       pk_value',
'  from apex_automation_msg_log',
' where automation_log_id = :P10036_LOG_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>50
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10878109373535127)
,p_query_column_id=>1
,p_column_alias=>'MESSAGE_TIMESTAMP'
,p_column_display_sequence=>1
,p_column_heading=>'Timestamp'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10878511620535127)
,p_query_column_id=>2
,p_column_alias=>'MESSAGE'
,p_column_display_sequence=>2
,p_column_heading=>'Message'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10878942024535128)
,p_query_column_id=>3
,p_column_alias=>'MESSAGE_TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Message Type'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10879303165535128)
,p_query_column_id=>4
,p_column_alias=>'PK_VALUE'
,p_column_display_sequence=>4
,p_column_heading=>'Primary Key Value'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10875780526535126)
,p_name=>'P10036_LOG_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10875390764535125)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10876188795535126)
,p_name=>'P10036_AUTOMATION_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10875390764535125)
,p_prompt=>'Automation'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10876553666535126)
,p_name=>'P10036_START_TIMESTAMP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10875390764535125)
,p_prompt=>'Started'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10876941184535126)
,p_name=>'P10036_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10875390764535125)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10877304721535126)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Log Detail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select automation_name,',
'       start_timestamp,',
'       status',
'  into :P10036_AUTOMATION_NAME,',
'       :P10036_START_TIMESTAMP,',
'       :P10036_STATUS',
'  from apex_automation_log',
' where id = :P10036_LOG_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10877304721535126
);
end;
/
prompt --application/pages/page_10040
begin
wwv_flow_imp_page.create_page(
 p_id=>10040
,p_name=>'Configure Access Control'
,p_alias=>'CONFIGURE-ACCESS-CONTROL'
,p_page_mode=>'MODAL'
,p_step_title=>'Configure Access Control'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'U'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Select the appropriate choice for any authenticated users.<br> ',
'Selecting <strong>No</strong> makes the application more secure as only specified users can access the application. ',
'However, if your application has a large user community then maintaining users may be onerous, and you may prefer to choose <strong>Yes</strong> and only enter application Administrators, and possibly Contributors.<br>',
'If you select <strong>Yes</strong> then you must also select how users not included in the users list are treated.</p>',
'<p>Select between requiring email addresses and any alphanumeric value for Usernames.<br>',
'Generally, you should set this setting to <strong>E-mail Address</strong> if your application uses (or will be configured to use) a centralized authentication scheme such as Oracle Access Manager, or SSO.</p>',
'<p><em><strong>Note:</strong> This application supports the following 3 access levels: Reader, Contributor, and Administrator.',
'<ul>',
'  <li><strong>Readers</strong> have read-only access to all information and can also view reports.</li>',
'  <li><strong>Contributors</strong> can create, edit and delete information and view reports.</li>',
'  <li><strong>Administrators</strong>, in addition to Contributors capability, can also perform configuration of the application by accessing the Administration section of the application.</li>',
'</ul>',
'</em></p>'))
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10881538525535129)
,p_plug_name=>'Access Control Configuration'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10881609009535129)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10882858792535130)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10881609009535129)
,p_button_name=>'APPLY_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10883128435535130)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10881609009535129)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10884589555535131)
,p_branch_name=>'Branch to Admin Page'
,p_branch_action=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10884836844535131)
,p_name=>'P10040_ALLOW_OTHER_USERS'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10881538525535129)
,p_prompt=>'Any authenticated user may access this application'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_app_setting.get_value( p_name => ''ACCESS_CONTROL_SCOPE'' ) = ''ACL_ONLY'' then',
'    return ''N'';',
'else',
'    return ''Y'';',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_cSize=>64
,p_cMaxlength=>4000
,p_cHeight=>4
,p_grid_label_column_span=>3
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>'Choose <strong>No</strong> if all users are defined in the access control list. Choose <strong>Yes</strong> if authenticated users not in the access control list may also use this application.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10883217044535130)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10883128435535130)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10883977500535130)
,p_event_id=>wwv_flow_imp.id(10883217044535130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10885247040535131)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Access Control'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P10040_ALLOW_OTHER_USERS = ''Y'' then',
'        apex_app_setting.set_value (',
'            p_name  => ''ACCESS_CONTROL_SCOPE'',',
'            p_value => ''ALL_USERS'');',
'    else',
'        apex_app_setting.set_value (',
'            p_name  => ''ACCESS_CONTROL_SCOPE'',',
'            p_value => ''ACL_ONLY'');',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Access Control settings saved.'
,p_internal_uid=>10885247040535131
);
end;
/
prompt --application/pages/page_10041
begin
wwv_flow_imp_page.create_page(
 p_id=>10041
,p_name=>'Manage User Access'
,p_alias=>'MANAGE-USER-ACCESS'
,p_page_mode=>'MODAL'
,p_step_title=>'Manage User Access'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows a report of the application users and the access level granted.</p>',
'<p>Click on the column headings to sort and filter data, or click on the <strong>Actions</strong> button to customize column display and many additional advanced features.<br>',
'Click the <strong>Reset</strong> button to reset the interactive report back to the default settings.</p>',
'<p>Click the edit icon (yellow pencil) to edit the user details and access level, or to delete the user.</p>',
'<p>Click <strong>Add User</strong>, at the top of the report, to add a new user and their access level.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10885644479535131)
,p_plug_name=>'Manage User Access'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'   user_name_lc USERNAME,',
'   role_names ACCESS_ROLE',
'from APEX_APPL_ACL_USERS',
'where APPLICATION_ID = :APP_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Manage User Access'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10886451875535131)
,p_name=>'Manage User Access'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:10042:&APP_SESSION.::&DEBUG.:RP:P10042_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'ELEVATEADMIN'
,p_internal_uid=>10886451875535131
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10887161832535132)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10887516149535132)
,p_db_column_name=>'USERNAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Username'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10887937456535132)
,p_db_column_name=>'ACCESS_ROLE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Roles'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10889571273535133)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108896'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USERNAME:ACCESS_ROLE'
,p_sort_column_2=>'USERNAME'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10890461365535134)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10885644479535131)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10890816367535134)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10885644479535131)
,p_button_name=>'ADD_MULTIPLE_USERS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Add Multiple Users'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:10043:&APP_SESSION.::&DEBUG.:10043::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10891241900535134)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10885644479535131)
,p_button_name=>'ADD_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:10042:&APP_SESSION.::&DEBUG.:10042::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10885766642535131)
,p_name=>'Refresh Report'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10885644479535131)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10891829575535134)
,p_event_id=>wwv_flow_imp.id(10885766642535131)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10885644479535131)
);
end;
/
prompt --application/pages/page_10042
begin
wwv_flow_imp_page.create_page(
 p_id=>10042
,p_name=>'Manage User Access'
,p_alias=>'MANAGE-USER-ACCESS1'
,p_page_mode=>'MODAL'
,p_step_title=>'Manage User Access'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use this form to enter users, their email address and set their access level. ',
'The settings defined under <em>Configure Access Control</em> will determine whether the username must be their email address or can be any alphanumeric entry.</p>',
'<p>This application supports the following 3 access levels: Reader, Contributor, and Administrator.</p>',
'<ul>',
'  <li><strong>Readers</strong> have read-only access to all information and can also view reports.</li>',
'  <li><strong>Contributors</strong> can create, edit and delete information and view reports.</li>',
'  <li><strong>Administrators</strong>, in addition to Contributors capability, can also perform configuration of the application by accessing the Administration section of the application.</li>',
'</ul>',
'<p>When editing an existing user you can lock their account which will prevent them from accessing the application.</p>',
'<p><em><strong>Note:</strong>   If using Oracle APEX accounts then users entered here must also be defined as end users by a Workspace Administrator, who can also set their password.</em></p>'))
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10892360292535135)
,p_plug_name=>'Form on Manage User Access'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'APEX_APPL_ACL_USERS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10892412435535135)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10895253749535136)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10892412435535135)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10895633371535136)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10892412435535135)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'NEXT'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10893485743535135)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10892412435535135)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10894898417535136)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10892412435535135)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10895911202535136)
,p_name=>'P10042_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_item_source_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10896331577535136)
,p_name=>'P10042_APPLICATION_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_item_source_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_use_cache_before_default=>'NO'
,p_item_default=>'&APP_ID.'
,p_source=>'APPLICATION_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10896732228535137)
,p_name=>'P10042_USER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_item_source_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Username'
,p_source=>'USER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_read_only_when=>'P10042_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609122147107268652
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10897126162535137)
,p_name=>'P10042_ROLE_IDS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_item_source_plug_id=>wwv_flow_imp.id(10892360292535135)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Roles'
,p_source=>'ROLE_IDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'ACCESS_ROLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'order by 1'))
,p_field_template=>1609122147107268652
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When Access Control is enabled, Administrators have the ability to restrict access to certain application features for authenticated users. This application supports the following 3 roles: Reader, Contributor, and Administrator.<p>',
'<ul>',
'  <li><strong>Readers</strong> have read-only access to all information and can also view reports.</li>',
'  <li><strong>Contributors</strong> can create,edit and delete information and view reports.</li>',
'  <li><strong>Administrators</strong>,in addition to Contributors capability,can also perform configuration of the application.</li>',
'</ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10898498400535137)
,p_validation_name=>'Cannot remove yourself from administrator'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10042_USER_NAME = :APP_USER and',
'    apex_acl.is_role_removed_from_user (',
'        p_application_id => :APP_ID,',
'        p_user_name      => :APP_USER,',
'        p_role_static_id => ''ADMINISTRATOR'',',
'        p_role_ids       => apex_string.split_numbers(',
'                                p_str => case when :REQUEST = ''DELETE'' then',
'                                             null',
'                                         else',
'                                             :P10042_ROLE_IDS',
'                                         end,',
'                                p_sep => '':'') ) then',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'You cannot remove administrator role from yourself.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10893544280535135)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10893485743535135)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10894219516535135)
,p_event_id=>wwv_flow_imp.id(10893544280535135)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10898757641535138)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(10892360292535135)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Manage User Access'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10898757641535138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10899160737535138)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10892360292535135)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Manage User Access'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'N'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10899160737535138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10899534253535138)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10899534253535138
);
end;
/
prompt --application/pages/page_10043
begin
wwv_flow_imp_page.create_page(
 p_id=>10043
,p_name=>'Add Multiple Users - Step 1'
,p_alias=>'ADD-MULTIPLE-USERS-STEP-1'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Multiple Users'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10899981105535138)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10900057370535138)
,p_plug_name=>'Wizard Container'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10900158831535138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10899981105535138)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10902142994535139)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10899981105535138)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10903489035535139)
,p_branch_action=>'f?p=&APP_ID.:10044:&APP_SESSION.::&DEBUG.:RP,10044::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10900158831535138)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10903813456535140)
,p_name=>'P10043_ROLE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10900057370535138)
,p_prompt=>'Roles'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'ACCESS_ROLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'order by 1'))
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10904238461535140)
,p_name=>'P10043_PRELIM_USERS'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10900057370535138)
,p_prompt=>'Usernames'
,p_placeholder=>'Enter usernames here'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'I'
,p_inline_help_text=>'Enter usernames separated by commas, semicolons, or whitespace. Existing or duplicate usernames will automatically be ignored.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10904655322535140)
,p_name=>'P10043_USERNAME_FORMAT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10900057370535138)
,p_prompt=>'Username Format'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'EMAIL_USERNAME_FORMAT'
,p_lov=>'.'||wwv_flow_imp.id(10904721215535140)||'.'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10902241366535139)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10902142994535139)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10902932647535139)
,p_event_id=>wwv_flow_imp.id(10902241366535139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10905710802535140)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Collections'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_line      varchar2(32767);',
'    l_emails    apex_t_varchar2;',
'    l_username  varchar2(4000);',
'    l_at        number;',
'    l_dot       number;',
'    l_valid     boolean := true;',
'    l_domain    varchar2(4000);',
'begin',
'    -- create collections',
'    apex_collection.create_or_truncate_collection(''ACL_BULK_USER_INVALID'');',
'    apex_collection.create_or_truncate_collection(''ACL_BULK_USER_VALID'');',
'',
'    -- replace delimiting characters with commas',
'    l_line := :P10043_PRELIM_USERS;',
'    l_line := replace(l_line, chr(10), '' '');',
'    l_line := replace(l_line, chr(13), '' '');',
'    l_line := replace(l_line, chr(9),  '' '');',
'    l_line := replace(l_line, ''<'', '' '');',
'    l_line := replace(l_line, ''>'', '' '');',
'    l_line := replace(l_line, '';'', '' '');',
'    l_line := replace(l_line, '':'', '' '');',
'    l_line := replace(l_line, ''('', '' '');',
'    l_line := replace(l_line, '')'', '' '');',
'    l_line := replace(l_line, '' '', '','');',
'',
'    -- get one comma separated line of emails',
'    for j in 1 .. 1000 loop',
'        if instr(l_line, '',,'') > 0 then',
'            l_line := replace(l_line, '',,'', '','');',
'        else',
'            exit;',
'        end if;',
'    end loop;',
'',
'    -- get an array of emails',
'    l_emails := apex_string.split(l_line, '','');',
'',
'    -- add emails to a collection',
'    l_username := null;',
'    l_domain   := null;',
'    l_at       := 0;',
'    l_dot      := 0;',
'    for j in 1..l_emails.count loop',
'        l_valid    := true;',
'        l_username := upper(trim(l_emails(j)));',
'        l_username := trim(both ''.'' from l_username);',
'        l_username := replace(l_username, '' '', null);',
'        l_username := replace(l_username, chr(10), null);',
'        l_username := replace(l_username, chr(9), null);',
'        l_username := replace(l_username, chr(13), null);',
'        l_username := replace(l_username, chr(49824), null);',
'',
'        if l_username is not null then',
'            if nvl(:P10043_USERNAME_FORMAT,''x'') = ''EMAIL'' then',
'              -- Validate',
'              l_at     := instr(nvl(l_username, ''x''), ''@'');',
'              l_domain := substr(l_username, l_at+1);',
'              l_dot    := instr(l_domain, ''.'');',
'              if l_at < 2 then',
'                  -- invalid email',
'                  apex_collection.add_member(',
'                      p_collection_name => ''ACL_BULK_USER_INVALID'',',
'                      p_c001            => l_username,',
'                      p_c002            => apex_lang.message(''APEX.FEATURE.ACL.BULK_USER.MISSING_AT_SIGN''));',
'                  commit;',
'                  l_valid := false;',
'              end if;',
'',
'              if l_dot = 0 and l_valid then',
'                  apex_collection.add_member(',
'                      p_collection_name => ''ACL_BULK_USER_INVALID'',',
'                      p_c001            => l_username,',
'                      p_c002            => apex_lang.message(''APEX.FEATURE.ACL.BULK_USER.MISSING_DOT''));',
'                  commit;',
'                  l_valid := false;',
'              end if;',
'            end if;',
'',
'            if l_valid and length(l_username) > 255 then',
'                apex_collection.add_member(',
'                    p_collection_name => ''ACL_BULK_USER_INVALID'',',
'                    p_c001            => l_username,',
'                    p_c002            => apex_lang.message(''APEX.FEATURE.ACL.BULK_USER.USERNAME_TOO_LONG''));',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select user_name username',
'                             from APEX_APPL_ACL_USERS',
'                            where user_name = l_username and application_id = :APP_ID)',
'                loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''ACL_BULK_USER_INVALID'',',
'                        p_c001            => l_username,',
'                        p_c002            => apex_lang.message(''APEX.FEATURE.ACL.BULK_USER.ALREADY_IN_ACL''));',
'                    commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select c001',
'                             from apex_collections',
'                            where collection_name = ''ACL_BULK_USER_VALID''',
'                              and c001            = l_username)',
'                loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''ACL_BULK_USER_INVALID'',',
'                        p_c001            => l_username,',
'                        p_c002            => apex_lang.message(''APEX.FEATURE.ACL.BULK_USER.DUPLICATE_USER''));',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''ACL_BULK_USER_VALID'',',
'                    p_c001            => l_username,',
'                    p_c002            => null,',
'                    p_c003            => :P10043_ROLE);',
'                    commit;',
'            end if;',
'',
'        end if;',
'        l_username := null;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10900158831535138)
,p_internal_uid=>10905710802535140
);
end;
/
prompt --application/pages/page_10044
begin
wwv_flow_imp_page.create_page(
 p_id=>10044
,p_name=>'Add Multiple Users - Step 2'
,p_alias=>'ADD-MULTIPLE-USERS-STEP-2'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Multiple Users'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10569463023533331)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-ListView-item .fa {',
'  color: var(--ut-component-text-muted-color);',
'}',
'',
'.a-ListView-item .u-success-text {',
'  color: var(--ut-palette-success) !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(10568107730533330)
,p_required_patch=>wwv_flow_imp.id(10565814818533329)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10900281005535138)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10900394580535138)
,p_plug_name=>'Wizard Container'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10900551419535138)
,p_name=>'Exceptions'
,p_parent_plug_id=>wwv_flow_imp.id(10900394580535138)
,p_template=>2664334895415463485
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c001 username, c002 reason',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_INVALID''',
'order by 1'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_INVALID'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907636996535142)
,p_query_column_id=>1
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Username'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10908087524535142)
,p_query_column_id=>2
,p_column_alias=>'REASON'
,p_column_display_sequence=>2
,p_column_heading=>'Reason'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10900608311535138)
,p_plug_name=>'&P10044_VALID_COUNT. Users to Add'
,p_parent_plug_id=>wwv_flow_imp.id(10900394580535138)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct c001 username',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID''',
'order by 1'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>10000
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'list_view_features', 'ADVANCED_FORMATTING',
  'text_formatting', '&USERNAME!HTML.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10900702093535138)
,p_plug_name=>'Hidden Items'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10911063212535370)
,p_plug_name=>'Valid Users Exist - Page Info'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return ''<p>'' ||',
'       apex_lang.message (',
'           ''APEX.FEATURE.ACL.BULK_USER.CREATE_CONFIRM'',',
'           apex_escape.html(:P10044_VALID_COUNT),',
'           apex_escape.html(:P10044_ROLE)',
'       ) ||',
'       ''</p>'';'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10911742192535370)
,p_plug_name=>'No Valid Users Exist - Page Info'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<p>No valid new users found</p>'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10900841443535138)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10900281005535138)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Users'
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10912495509535371)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10900281005535138)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'javascript:history.back();'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10912837906535371)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10900281005535138)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10914153384535371)
,p_name=>'P10044_ROLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10900702093535138)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LISTAGG( role_name, '', '')',
'         WITHIN GROUP (ORDER BY role_name) role_name',
'from APEX_APPL_ACL_ROLES',
'where application_id = :APP_ID',
'and instr(:P10043_ROLE, role_id, 1) > 0'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10914508501535372)
,p_name=>'P10044_VALID_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10900702093535138)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*)',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10914932384535372)
,p_name=>'P10044_INVALID_COUNT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10900702093535138)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*)',
'  from apex_collections',
' where collection_name = ''ACL_BULK_USER_VALID'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_field_template=>1609121967514267634
,p_lov_display_extra=>'NO'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10912904206535371)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10912837906535371)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10913635526535371)
,p_event_id=>wwv_flow_imp.id(10912904206535371)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10915317495535372)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Users to Access Control List'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_user_role_ids apex_application_global.vc_arr2;',
'begin',
'    for c in (  select distinct c001 as username, c003 as user_roles',
'                from   apex_collections',
'                where  collection_name = ''ACL_BULK_USER_VALID'' )',
'    loop',
'         l_user_role_ids := apex_util.string_to_table(c.user_roles);',
'         for i in 1..l_user_role_ids.count loop',
'             apex_acl.add_user_role(p_application_id => :APP_ID, p_user_name => c.username, p_role_id => l_user_role_ids(i));',
'         end loop;',
'    end loop;',
'',
'    apex_collection.delete_collection(''ACL_BULK_USER_INVALID'');',
'    apex_collection.delete_collection(''ACL_BULK_USER_VALID'');',
'    :P10043_PRELIM_USERS := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10900841443535138)
,p_process_success_message=>'User(s) added.'
,p_internal_uid=>10915317495535372
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10915731231535372)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10915731231535372
);
end;
/
prompt --application/pages/page_20000
begin
wwv_flow_imp_page.create_page(
 p_id=>20000
,p_name=>'Settings'
,p_alias=>'SETTINGS'
,p_page_mode=>'MODAL'
,p_step_title=>'Settings'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10932448636535606)
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_required_patch=>wwv_flow_imp.id(10932927889535606)
,p_protection_level=>'C'
,p_help_text=>'This page contains a list of settings applicable to the current application user.'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10937581962535609)
,p_plug_name=>'&APP_USER.'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_application_auth ',
' where application_id            = :APP_ID ',
'   and is_current_authentication = ''Y'' ',
'   and scheme_type_code          = ''NATIVE_APEX_ACCOUNTS'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10937924375535609)
,p_plug_name=>'&APP_USER.'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'APEX_WORKSPACE_APEX_USERS'
,p_query_where=>'user_name = :APP_USER'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from apex_application_auth ',
' where application_id            = :APP_ID ',
'   and is_current_authentication = ''Y'' ',
'   and scheme_type_code          = ''NATIVE_APEX_ACCOUNTS'''))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10938469569535609)
,p_region_id=>wwv_flow_imp.id(10937924375535609)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>false
,p_title_column_name=>'USER_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'EMAIL'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'EMAIL'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10938999050535609)
,p_plug_name=>'Settings'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-MediaList--showBadges:u-colors'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(10936526357535608)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
);
end;
/
prompt --application/pages/page_20010
begin
wwv_flow_imp_page.create_page(
 p_id=>20010
,p_name=>'Push Notifications'
,p_alias=>'PUSH-NOTIFICATIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Settings - Push Notifications'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10932448636535606)
,p_javascript_code_onload=>'apex.pwa.initPushSubscriptionPage();'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_patch=>wwv_flow_imp.id(10932656006535606)
,p_protection_level=>'C'
,p_help_text=>'This page contains the settings for controlling push notification subscription for the current user.'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10933968039535607)
,p_plug_name=>'Push Notifications Not Supported'
,p_region_css_classes=>'a-pwaPush--subscriptionRegion--not-supported'
,p_icon_css_classes=>'fa-bell-slash-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:t-Form--xlarge'
,p_region_attributes=>'#APEX_CSP_DISPLAY_NONE#'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Push notifications are not currently supported in your browser.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10934341537535607)
,p_plug_name=>'Push Notifications'
,p_region_css_classes=>'a-pwaPush--subscriptionRegion'
,p_icon_css_classes=>'fa-bell-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--xlarge'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Push notifications have to be enabled for each device you want to receive the notifications on. The first time you enable push notifications, you will have to grant permission to your browser. This setting can be changed at any time.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10933605355535607)
,p_button_sequence=>10
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Settings'
,p_button_redirect_url=>'f?p=&APP_ID.:20000:&APP_SESSION.::&DEBUG.:::'
,p_button_css_classes=>'t-Button--inlineLink'
,p_icon_css_classes=>'fa-chevron-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10934840997535607)
,p_name=>'P20010_ENABLE_PUSH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10934341537535607)
,p_prompt=>'Enable push notifications on this device'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10935114902535608)
,p_name=>'Change P20010_ENABLE_PUSH'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20010_ENABLE_PUSH'
,p_condition_element=>'P20010_ENABLE_PUSH'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10935610892535608)
,p_event_id=>wwv_flow_imp.id(10935114902535608)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Subscribe to push notifications'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.pwa.subscribePushNotifications();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10936114181535608)
,p_event_id=>wwv_flow_imp.id(10935114902535608)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Unsubscribe from push notifications'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.pwa.unsubscribePushNotifications();'
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
